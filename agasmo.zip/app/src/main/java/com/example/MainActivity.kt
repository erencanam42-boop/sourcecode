package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.alarm.NotificationHelper
import com.example.ui.AgasMoRoot
import com.example.ui.AgasMoViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AgasMoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.ensureChannels(this)
        enableEdgeToEdge()
        setContent {
            AgasMoRoot(viewModel = viewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemChecks()
    }
}
