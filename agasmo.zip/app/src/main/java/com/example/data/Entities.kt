package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val dosage: String,
    val type: String,
    val colorHex: Long,
    val photoUri: String? = null,
    val timesCsv: String,
    val frequency: String,
    val specificDaysCsv: String = "1,2,3,4,5,6,7",
    val durationDays: Int = -1,
    val startDateEpochDay: Long,
    val reminderOffsetMinutes: Int = 0,
    val maxShoutEnabled: Boolean = true,
    val soundStyle: String = "NORMAL",
    val voiceAlertEnabled: Boolean = true,
    val isActive: Boolean = true
)

@Entity(tableName = "medicine_logs")
data class MedicineLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val medicineId: Long,
    val medicineName: String,
    val dosage: String,
    val dateEpochDay: Long,
    val scheduledTime: String,
    val timeTakenMillis: Long? = null,
    val status: String,
    val snoozedUntilMillis: Long? = null
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Juan",
    val age: Int = 65,
    val photoUri: String? = null,
    val selectedLanguage: String = "TAGALOG",
    val selectedCompanionId: String = "LUMI",
    val onboardingCompleted: Boolean = false,
    val notificationsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val voiceAlertEnabled: Boolean = true,
    val themeMode: String = "PINK",
    val emergencyContactName: String = "",
    val emergencyContactNumber: String = ""
)

@Entity(tableName = "companions")
data class CompanionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val colorHex: Long,
    val voiceStyle: String
)

@Entity(tableName = "scheduled_alarms")
data class ScheduledAlarmEntity(
    @PrimaryKey val requestCode: Int,
    val medicineId: Long,
    val timeStr: String,
    val companionId: String,
    val language: String,
    val isActive: Boolean = true,
    val triggerAtMillis: Long = 0L,
    val isMaxShout: Boolean = false
)
