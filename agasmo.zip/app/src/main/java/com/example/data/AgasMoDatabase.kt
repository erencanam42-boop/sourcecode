package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.CompanionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MedicineEntity::class,
        MedicineLogEntity::class,
        UserProfileEntity::class,
        CompanionEntity::class,
        ScheduledAlarmEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AgasMoDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun medicineLogDao(): MedicineLogDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun companionDao(): CompanionDao
    abstract fun scheduledAlarmDao(): ScheduledAlarmDao

    companion object {
        @Volatile
        private var INSTANCE: AgasMoDatabase? = null

        fun getInstance(context: Context): AgasMoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AgasMoDatabase::class.java,
                    "agasmo_offline.db"
                )
                    .addCallback(SeedCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class SeedCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                CoroutineScope(Dispatchers.IO).launch {
                    INSTANCE?.let { database ->
                        seedDefaults(database)
                    }
                }
            }
        }

        suspend fun seedDefaults(database: AgasMoDatabase) {
            val companions = CompanionType.entries.map { c ->
                CompanionEntity(
                    id = c.id,
                    name = c.displayName,
                    type = c.speciesLabel,
                    colorHex = c.colorHex,
                    voiceStyle = c.voiceStyle
                )
            }
            database.companionDao().insertAll(companions)
            if (database.userProfileDao().getProfileSync() == null) {
                database.userProfileDao().upsertProfile(UserProfileEntity())
            }
        }
    }
}
