package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.agasMoDataStore: DataStore<Preferences> by preferencesDataStore(name = "agasmo_prefs")

data class UserPrefsSnapshot(
    val selectedLanguage: String = "TAGALOG",
    val selectedCompanionId: String = "LUMI",
    val onboardingCompleted: Boolean = false,
    val themeMode: String = "PINK",
    val notificationsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val voiceAlertEnabled: Boolean = true
)

class UserPrefsStore(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("selected_language")
        val COMPANION_ID = stringPreferencesKey("selected_companion_id")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NOTIF_ENABLED = booleanPreferencesKey("notifications_enabled")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val VOICE_ALERT_ENABLED = booleanPreferencesKey("voice_alert_enabled")
    }

    val prefsFlow: Flow<UserPrefsSnapshot> = context.agasMoDataStore.data.map { prefs ->
        UserPrefsSnapshot(
            selectedLanguage = prefs[Keys.LANGUAGE] ?: "TAGALOG",
            selectedCompanionId = prefs[Keys.COMPANION_ID] ?: "LUMI",
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            themeMode = prefs[Keys.THEME_MODE] ?: "PINK",
            notificationsEnabled = prefs[Keys.NOTIF_ENABLED] ?: true,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION_ENABLED] ?: true,
            voiceAlertEnabled = prefs[Keys.VOICE_ALERT_ENABLED] ?: true
        )
    }

    suspend fun getSnapshot(): UserPrefsSnapshot = prefsFlow.first()

    suspend fun setLanguage(languageCode: String) {
        context.agasMoDataStore.edit { it[Keys.LANGUAGE] = languageCode }
    }

    suspend fun setCompanion(companionId: String) {
        context.agasMoDataStore.edit { it[Keys.COMPANION_ID] = companionId }
    }

    suspend fun setOnboardingCompleted(done: Boolean) {
        context.agasMoDataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setThemeMode(mode: String) {
        context.agasMoDataStore.edit { it[Keys.THEME_MODE] = mode }
    }

    suspend fun setNotificationToggles(
        notificationsEnabled: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        voiceAlertEnabled: Boolean
    ) {
        context.agasMoDataStore.edit {
            it[Keys.NOTIF_ENABLED] = notificationsEnabled
            it[Keys.SOUND_ENABLED] = soundEnabled
            it[Keys.VIBRATION_ENABLED] = vibrationEnabled
            it[Keys.VOICE_ALERT_ENABLED] = voiceAlertEnabled
        }
    }
}
