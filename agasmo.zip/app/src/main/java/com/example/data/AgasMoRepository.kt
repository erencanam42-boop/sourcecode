package com.example.data

import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.DoseStatus
import com.example.model.MedicineFrequency
import com.example.model.MedicineType
import com.example.model.SoundStyle
import com.example.model.TodayDoseItem
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class AgasMoRepository(
    private val db: AgasMoDatabase,
    private val prefsStore: UserPrefsStore
) {
    val activeMedicines: Flow<List<MedicineEntity>> = db.medicineDao().observeActiveMedicines()
    val userProfile: Flow<UserProfileEntity?> = db.userProfileDao().observeProfile()
    val userPrefs: Flow<UserPrefsSnapshot> = prefsStore.prefsFlow
    val allLogs: Flow<List<MedicineLogEntity>> = db.medicineLogDao().observeAllLogs()

    suspend fun ensureSeeded() {
        AgasMoDatabase.seedDefaults(db)
        val profile = db.userProfileDao().getProfileSync() ?: UserProfileEntity()
        val prefs = prefsStore.getSnapshot()
        if (prefs.onboardingCompleted && !profile.onboardingCompleted) {
            db.userProfileDao().upsertProfile(
                profile.copy(
                    selectedLanguage = prefs.selectedLanguage,
                    selectedCompanionId = prefs.selectedCompanionId,
                    onboardingCompleted = true,
                    themeMode = prefs.themeMode
                )
            )
        }
    }

    suspend fun getProfileOrDefault(): UserProfileEntity {
        val profile = db.userProfileDao().getProfileSync()
        if (profile != null) return profile
        val defaultProfile = UserProfileEntity()
        db.userProfileDao().upsertProfile(defaultProfile)
        return defaultProfile
    }

    suspend fun updateLanguage(language: AppLanguage) {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(current.copy(selectedLanguage = language.code))
        prefsStore.setLanguage(language.code)
    }

    suspend fun updateCompanion(companion: CompanionType) {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(current.copy(selectedCompanionId = companion.id))
        prefsStore.setCompanion(companion.id)
    }

    suspend fun completeOnboarding() {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(current.copy(onboardingCompleted = true))
        prefsStore.setOnboardingCompleted(true)
    }

    suspend fun updateProfileDetails(
        name: String,
        age: Int,
        photoUri: String?,
        emergencyName: String,
        emergencyPhone: String
    ) {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(
            current.copy(
                name = name.trim().ifEmpty { "Juan" },
                age = age.coerceIn(1, 130),
                photoUri = photoUri,
                emergencyContactName = emergencyName.trim(),
                emergencyContactNumber = emergencyPhone.trim()
            )
        )
    }

    suspend fun updateNotificationSettings(
        notificationsEnabled: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        voiceAlertEnabled: Boolean
    ) {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(
            current.copy(
                notificationsEnabled = notificationsEnabled,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled,
                voiceAlertEnabled = voiceAlertEnabled
            )
        )
        prefsStore.setNotificationToggles(
            notificationsEnabled = notificationsEnabled,
            soundEnabled = soundEnabled,
            vibrationEnabled = vibrationEnabled,
            voiceAlertEnabled = voiceAlertEnabled
        )
    }

    suspend fun updateThemeMode(themeMode: String) {
        val current = getProfileOrDefault()
        db.userProfileDao().upsertProfile(current.copy(themeMode = themeMode))
        prefsStore.setThemeMode(themeMode)
    }

    suspend fun saveMedicine(medicine: MedicineEntity): Long {
        return if (medicine.id == 0L) {
            db.medicineDao().insertMedicine(medicine)
        } else {
            db.medicineDao().updateMedicine(medicine)
            medicine.id
        }
    }

    suspend fun toggleMedicineVoiceAlert(medicineId: Long, enabled: Boolean) {
        val med = db.medicineDao().getMedicineById(medicineId) ?: return
        db.medicineDao().updateMedicine(med.copy(voiceAlertEnabled = enabled))
    }

    suspend fun deleteMedicine(medicineId: Long) {
        db.medicineDao().deleteMedicineById(medicineId)
        db.medicineLogDao().deleteLogsForMedicine(medicineId)
        db.scheduledAlarmDao().deleteAlarmsForMedicine(medicineId)
    }

    suspend fun getMedicineById(medicineId: Long): MedicineEntity? {
        return db.medicineDao().getMedicineById(medicineId)
    }

    suspend fun getActiveMedicinesSync(): List<MedicineEntity> {
        return db.medicineDao().getActiveMedicinesSync()
    }

    suspend fun markDoseTaken(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        epochDay: Long = todayEpochDay()
    ) {
        val existing = db.medicineLogDao().getLogForDose(medicineId, epochDay, scheduledTime)
        val entry = MedicineLogEntity(
            id = existing?.id ?: 0L,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            dateEpochDay = epochDay,
            scheduledTime = scheduledTime,
            timeTakenMillis = System.currentTimeMillis(),
            status = "TAKEN",
            snoozedUntilMillis = null
        )
        db.medicineLogDao().upsertLog(entry)
    }

    suspend fun markDoseSkipped(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        epochDay: Long = todayEpochDay()
    ) {
        val existing = db.medicineLogDao().getLogForDose(medicineId, epochDay, scheduledTime)
        val entry = MedicineLogEntity(
            id = existing?.id ?: 0L,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            dateEpochDay = epochDay,
            scheduledTime = scheduledTime,
            timeTakenMillis = System.currentTimeMillis(),
            status = "SKIPPED",
            snoozedUntilMillis = null
        )
        db.medicineLogDao().upsertLog(entry)
    }

    suspend fun markDoseSnoozed(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        snoozedUntilMillis: Long,
        epochDay: Long = todayEpochDay()
    ) {
        val existing = db.medicineLogDao().getLogForDose(medicineId, epochDay, scheduledTime)
        if (existing?.status == "TAKEN" || existing?.status == "SKIPPED") return
        val entry = MedicineLogEntity(
            id = existing?.id ?: 0L,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            dateEpochDay = epochDay,
            scheduledTime = scheduledTime,
            timeTakenMillis = null,
            status = "SNOOZED",
            snoozedUntilMillis = snoozedUntilMillis
        )
        db.medicineLogDao().upsertLog(entry)
    }

    suspend fun getLogForDose(
        medicineId: Long,
        scheduledTime: String,
        epochDay: Long = todayEpochDay()
    ): MedicineLogEntity? {
        return db.medicineLogDao().getLogForDose(medicineId, epochDay, scheduledTime)
    }

    suspend fun saveScheduledAlarm(alarm: ScheduledAlarmEntity) {
        db.scheduledAlarmDao().upsertAlarm(alarm)
    }

    suspend fun getAlarmsForMedicine(medicineId: Long): List<ScheduledAlarmEntity> {
        return db.scheduledAlarmDao().getAlarmsForMedicine(medicineId)
    }

    suspend fun getAllActiveAlarms(): List<ScheduledAlarmEntity> {
        return db.scheduledAlarmDao().getAllActiveAlarms()
    }

    suspend fun deleteAlarmsForMedicine(medicineId: Long) {
        db.scheduledAlarmDao().deleteAlarmsForMedicine(medicineId)
    }

    suspend fun deleteAllScheduledAlarms() {
        db.scheduledAlarmDao().deleteAllAlarms()
    }

    fun buildDosesForDay(
        medicines: List<MedicineEntity>,
        logs: List<MedicineLogEntity>,
        epochDay: Long,
        nowMillis: Long = System.currentTimeMillis()
    ): List<TodayDoseItem> {
        val result = mutableListOf<TodayDoseItem>()
        for (med in medicines) {
            if (!isMedicineScheduledOnDay(med, epochDay)) continue
            val times = med.timesCsv.split(",").map { it.trim() }.filter { it.contains(":") }
            for (timeStr in times) {
                val triggerMillis = epochDayAndTimeToMillis(epochDay, timeStr)
                val log = logs.firstOrNull {
                    it.medicineId == med.id && it.dateEpochDay == epochDay && it.scheduledTime == timeStr
                }
                val effectiveTrigger = if (log?.status == "SNOOZED" && log.snoozedUntilMillis != null) {
                    log.snoozedUntilMillis
                } else {
                    triggerMillis
                }
                val diffMins = ((nowMillis - effectiveTrigger) / 60_000L).toInt()
                val status = when (log?.status) {
                    "TAKEN" -> DoseStatus.TAKEN
                    "SKIPPED" -> DoseStatus.SKIPPED
                    else -> if (diffMins > 0) DoseStatus.LATE else DoseStatus.UPCOMING
                }
                result.add(
                    TodayDoseItem(
                        medicineId = med.id,
                        name = med.name,
                        dosage = med.dosage,
                        type = MedicineType.fromCode(med.type),
                        colorHex = med.colorHex,
                        photoUri = med.photoUri,
                        scheduledTime = timeStr,
                        triggerMillis = effectiveTrigger,
                        status = status,
                        minutesLate = if (status == DoseStatus.LATE) diffMins.coerceAtLeast(1) else 0,
                        minutesUntil = if (status == DoseStatus.UPCOMING) (-diffMins).coerceAtLeast(0) else 0,
                        voiceAlertEnabled = med.voiceAlertEnabled,
                        maxShoutEnabled = med.maxShoutEnabled,
                        soundStyle = SoundStyle.fromCode(med.soundStyle),
                        snoozedUntilMillis = log?.snoozedUntilMillis
                    )
                )
            }
        }
        return result.sortedWith(
            compareBy<TodayDoseItem>(
                {
                    when (it.status) {
                        DoseStatus.LATE -> 0
                        DoseStatus.UPCOMING -> 1
                        DoseStatus.TAKEN -> 2
                        DoseStatus.SKIPPED -> 3
                    }
                },
                { it.scheduledTime }
            )
        )
    }

    fun computeStreakDays(logs: List<MedicineLogEntity>, today: Long = todayEpochDay()): Int {
        val takenDays = logs.filter { it.status == "TAKEN" }.map { it.dateEpochDay }.toSet()
        if (takenDays.isEmpty()) return 0
        var streak = 0
        var cursor = if (takenDays.contains(today)) today else today - 1L
        while (takenDays.contains(cursor)) {
            streak++
            cursor--
        }
        return streak
    }

    fun computeWeeklyAdherencePercent(
        medicines: List<MedicineEntity>,
        logs: List<MedicineLogEntity>,
        today: Long = todayEpochDay()
    ): Int {
        var expected = 0
        var taken = 0
        for (offset in 0..6) {
            val day = today - offset
            val dayLogs = logs.filter { it.dateEpochDay == day }
            val dayDoses = medicines.filter { isMedicineScheduledOnDay(it, day) }
                .sumOf { med -> med.timesCsv.split(",").count { it.contains(":") } }
            expected += dayDoses
            taken += dayLogs.count { it.status == "TAKEN" }
        }
        if (expected == 0) return if (taken > 0) 100 else 0
        return ((taken.toFloat() / expected.toFloat()) * 100f).toInt().coerceIn(0, 100)
    }

    fun buildDoctorExportReport(
        profile: UserProfileEntity,
        medicines: List<MedicineEntity>,
        logs: List<MedicineLogEntity>,
        streakDays: Int,
        weeklyAdherence: Int
    ): String {
        val sb = StringBuilder()
        sb.appendLine("AgasMo - Medicine Adherence Summary")
        sb.appendLine("Patient: ${profile.name} (Age ${profile.age})")
        sb.appendLine("Current Streak: $streakDays day(s)")
        sb.appendLine("7-Day Adherence: $weeklyAdherence%")
        sb.appendLine()
        sb.appendLine("Active Prescriptions:")
        if (medicines.isEmpty()) {
            sb.appendLine("- None recorded")
        } else {
            medicines.forEach { med ->
                sb.appendLine("- ${med.name} (${med.dosage}) | ${med.type} | Times: ${med.timesCsv}")
            }
        }
        sb.appendLine()
        sb.appendLine("Recent Logs (Latest 15):")
        logs.take(15).forEach { log ->
            val cal = Calendar.getInstance().apply {
                timeInMillis = epochDayToMidnightMillis(log.dateEpochDay)
            }
            val dateStr = String.format(
                java.util.Locale.US,
                "%04d-%02d-%02d",
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
            )
            sb.appendLine("- $dateStr ${log.scheduledTime} | ${log.medicineName} (${log.dosage}): ${log.status}")
        }
        return sb.toString()
    }

    companion object {
        fun todayEpochDay(): Long {
            val cal = Calendar.getInstance()
            val tzOffset = cal.timeZone.getOffset(cal.timeInMillis)
            return (cal.timeInMillis + tzOffset) / 86_400_000L
        }

        fun epochDayToMidnightMillis(epochDay: Long): Long {
            val cal = Calendar.getInstance()
            val utcMidnight = epochDay * 86_400_000L
            val offset = cal.timeZone.getOffset(utcMidnight)
            cal.timeInMillis = utcMidnight - offset
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            return cal.timeInMillis
        }

        fun epochDayAndTimeToMillis(epochDay: Long, timeStr: String): Long {
            val parts = timeStr.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
            val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val cal = Calendar.getInstance().apply {
                timeInMillis = epochDayToMidnightMillis(epochDay)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        fun isoDayOfWeek(epochDay: Long): Int {
            val cal = Calendar.getInstance().apply {
                timeInMillis = epochDayToMidnightMillis(epochDay)
            }
            return when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.MONDAY -> 1
                Calendar.TUESDAY -> 2
                Calendar.WEDNESDAY -> 3
                Calendar.THURSDAY -> 4
                Calendar.FRIDAY -> 5
                Calendar.SATURDAY -> 6
                Calendar.SUNDAY -> 7
                else -> 1
            }
        }

        fun isMedicineScheduledOnDay(med: MedicineEntity, epochDay: Long): Boolean {
            if (!med.isActive) return false
            if (epochDay < med.startDateEpochDay) return false
            if (med.durationDays > 0 && epochDay >= med.startDateEpochDay + med.durationDays) {
                return false
            }
            return when (MedicineFrequency.fromCode(med.frequency)) {
                MedicineFrequency.EVERYDAY -> true
                MedicineFrequency.EVERY_OTHER_DAY -> (epochDay - med.startDateEpochDay) % 2L == 0L
                MedicineFrequency.SPECIFIC_DAYS -> {
                    val allowed = med.specificDaysCsv.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
                    allowed.contains(isoDayOfWeek(epochDay))
                }
            }
        }
    }
}
