package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines WHERE isActive = 1 ORDER BY id DESC")
    fun observeActiveMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE isActive = 1")
    suspend fun getActiveMedicinesSync(): List<MedicineEntity>

    @Query("SELECT * FROM medicines WHERE id = :id LIMIT 1")
    suspend fun getMedicineById(id: Long): MedicineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineEntity): Long

    @Update
    suspend fun updateMedicine(medicine: MedicineEntity)

    @Query("DELETE FROM medicines WHERE id = :id")
    suspend fun deleteMedicineById(id: Long)
}

@Dao
interface MedicineLogDao {
    @Query("SELECT * FROM medicine_logs WHERE dateEpochDay = :epochDay ORDER BY scheduledTime ASC")
    fun observeLogsForDay(epochDay: Long): Flow<List<MedicineLogEntity>>

    @Query("SELECT * FROM medicine_logs WHERE dateEpochDay >= :startEpochDay ORDER BY dateEpochDay DESC, scheduledTime ASC")
    fun observeLogsSince(startEpochDay: Long): Flow<List<MedicineLogEntity>>

    @Query("SELECT * FROM medicine_logs ORDER BY dateEpochDay DESC, scheduledTime ASC")
    fun observeAllLogs(): Flow<List<MedicineLogEntity>>

    @Query("SELECT * FROM medicine_logs WHERE medicineId = :medicineId AND dateEpochDay = :epochDay AND scheduledTime = :scheduledTime LIMIT 1")
    suspend fun getLogForDose(medicineId: Long, epochDay: Long, scheduledTime: String): MedicineLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLog(log: MedicineLogEntity): Long

    @Query("DELETE FROM medicine_logs WHERE medicineId = :medicineId")
    suspend fun deleteLogsForMedicine(medicineId: Long)
}

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun observeProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: UserProfileEntity)
}

@Dao
interface CompanionDao {
    @Query("SELECT * FROM companions")
    fun observeCompanions(): Flow<List<CompanionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(companions: List<CompanionEntity>)
}

@Dao
interface ScheduledAlarmDao {
    @Query("SELECT * FROM scheduled_alarms WHERE isActive = 1")
    suspend fun getAllActiveAlarms(): List<ScheduledAlarmEntity>

    @Query("SELECT * FROM scheduled_alarms WHERE medicineId = :medicineId")
    suspend fun getAlarmsForMedicine(medicineId: Long): List<ScheduledAlarmEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlarm(alarm: ScheduledAlarmEntity)

    @Query("DELETE FROM scheduled_alarms WHERE medicineId = :medicineId")
    suspend fun deleteAlarmsForMedicine(medicineId: Long)

    @Query("DELETE FROM scheduled_alarms WHERE requestCode = :requestCode")
    suspend fun deleteAlarmByCode(requestCode: Int)

    @Query("DELETE FROM scheduled_alarms")
    suspend fun deleteAllAlarms()
}
