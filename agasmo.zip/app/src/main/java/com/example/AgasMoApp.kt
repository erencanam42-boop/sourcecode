package com.example

import android.app.Application
import com.example.alarm.NotificationHelper
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.UserPrefsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AgasMoApp : Application() {

    val database: AgasMoDatabase by lazy { AgasMoDatabase.getInstance(this) }
    val prefsStore: UserPrefsStore by lazy { UserPrefsStore(this) }
    val repository: AgasMoRepository by lazy { AgasMoRepository(database, prefsStore) }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
        appScope.launch {
            repository.ensureSeeded()
        }
    }
}
