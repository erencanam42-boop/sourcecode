package com.example.i18n

import com.example.model.AppLanguage
import com.example.model.CompanionMood
import com.example.model.CompanionType
import com.example.model.MedicineFrequency
import com.example.model.MedicineType
import com.example.model.SoundStyle
import com.example.model.ThemeMode

data class AppStrings(
    val appTagline: String,
    val navToday: String,
    val navAdd: String,
    val navHistory: String,
    val navCompanion: String,
    val navProfile: String,
    val onboardingLangTitle: String,
    val onboardingLangSubtitle: String,
    val hearExample: String,
    val continueBtn: String,
    val onboardingCompanionTitle: String,
    val onboardingCompanionSubtitle: String,
    val hearVoice: String,
    val startWithCompanion: (String) -> String,
    val homeGreeting: (String) -> String,
    val nextMedicineTitle: String,
    val noMoreMedsToday: String,
    val addFirstMedTip: String,
    val takeNow: String,
    val snooze10m: String,
    val skipBtn: String,
    val lateMinutesShout: (Int) -> String,
    val inHoursMins: (Int, Int) -> String,
    val inMins: (Int) -> String,
    val dueNow: String,
    val progressToday: (Int, Int) -> String,
    val notifOffBanner: (String) -> String,
    val searchMedsHint: String,
    val todayMedsHeader: String,
    val statusTaken: String,
    val statusLate: String,
    val statusUpcoming: String,
    val statusSkipped: String,
    val voiceAlertToggle: String,
    val snoozedToast: String,
    val takenToast: (String) -> String,
    val skippedToast: (String) -> String,
    val permDialogTitle: (String) -> String,
    val permDialogBody: (String) -> String,
    val permAllow: String,
    val permLater: String,
    val addMedTitle: String,
    val editMedTitle: String,
    val medNameLabel: String,
    val dosageLabel: String,
    val typeLabel: String,
    val colorLabel: String,
    val photoOptionalLabel: String,
    val pickPhotoBtn: String,
    val removePhotoBtn: String,
    val timesLabel: String,
    val addTimeBtn: String,
    val frequencyLabel: String,
    val durationLabel: String,
    val duration7Days: String,
    val duration30Days: String,
    val durationForever: String,
    val reminderLabel: String,
    val rem30Before: String,
    val rem10Before: String,
    val remOnTime: String,
    val maxShoutLabel: String,
    val soundStyleLabel: String,
    val saveMedBtn: String,
    val medSavedToast: (String) -> String,
    val medDeletedToast: String,
    val deleteMedBtn: String,
    val enterMedNameError: String,
    val historyTitle: String,
    val streakLabel: (Int) -> String,
    val adherenceThisWeek: String,
    val exportToDoctor: String,
    val noLogsForDate: String,
    val profileTitle: String,
    val userNameLabel: String,
    val userAgeLabel: String,
    val saveProfileBtn: String,
    val profileSavedToast: String,
    val sectionLanguage: String,
    val languageChangedToast: String,
    val sectionCompanion: String,
    val currentCompanionLabel: String,
    val changeBtn: String,
    val hearShoutBtn: String,
    val sectionNotifications: String,
    val masterNotifLabel: String,
    val soundLabel: String,
    val vibrationLabel: String,
    val openSystemNotifSettings: String,
    val batteryOptimizeBtn: String,
    val batteryOptimizedAlready: String,
    val sectionTheme: String,
    val sectionEmergency: String,
    val emergencyNameLabel: String,
    val emergencyPhoneLabel: String,
    val emergencyHint: String,
    val emergencyAlertBtn: (String) -> String,
    val emergencyLateBanner: (String) -> String,
    val aboutLabel: String,
    val companionScreenTitle: String,
    val moodHappyLabel: String,
    val moodAngryLabel: String,
    val moodSleepyLabel: String,
    val playVoiceBtn: String,
    val badgesTitle: String,
    val badgeOnTimeTitle: String,
    val badgeOnTimeDesc: String,
    val badgeStreakTitle: String,
    val badgeStreakDesc: String,
    val badgeFriendTitle: (String) -> String,
    val badgeFriendDesc: (String) -> String,
    val unlockedLabel: String,
    val cancelBtn: String,
    val editBtn: String
)

object L10n {

    fun strings(lang: AppLanguage): AppStrings = when (lang) {
        AppLanguage.TAGALOG -> tagalogStrings
        AppLanguage.ENGLISH -> englishStrings
        AppLanguage.TAGLISH -> taglishStrings
        AppLanguage.BISAYA -> bisayaStrings
        AppLanguage.ILOCANO -> ilocanoStrings
    }

    fun medicineTypeLabel(type: MedicineType, lang: AppLanguage): String = when (lang) {
        AppLanguage.TAGALOG -> when (type) {
            MedicineType.TABLET -> "Tableta"
            MedicineType.CAPSULE -> "Kapsula"
            MedicineType.SYRUP -> "Syrup"
            MedicineType.INJECTION -> "Iniksyon"
        }
        AppLanguage.ENGLISH -> when (type) {
            MedicineType.TABLET -> "Tablet"
            MedicineType.CAPSULE -> "Capsule"
            MedicineType.SYRUP -> "Syrup"
            MedicineType.INJECTION -> "Injection"
        }
        AppLanguage.TAGLISH -> when (type) {
            MedicineType.TABLET -> "Tablet"
            MedicineType.CAPSULE -> "Capsule"
            MedicineType.SYRUP -> "Syrup"
            MedicineType.INJECTION -> "Injection"
        }
        AppLanguage.BISAYA -> when (type) {
            MedicineType.TABLET -> "Tableta"
            MedicineType.CAPSULE -> "Kapsula"
            MedicineType.SYRUP -> "Syrup"
            MedicineType.INJECTION -> "Indiksyon"
        }
        AppLanguage.ILOCANO -> when (type) {
            MedicineType.TABLET -> "Tableta"
            MedicineType.CAPSULE -> "Kapsula"
            MedicineType.SYRUP -> "Syrup"
            MedicineType.INJECTION -> "Indiksion"
        }
    }

    fun frequencyLabel(freq: MedicineFrequency, lang: AppLanguage): String = when (lang) {
        AppLanguage.TAGALOG -> when (freq) {
            MedicineFrequency.EVERYDAY -> "Araw-araw"
            MedicineFrequency.EVERY_OTHER_DAY -> "Tuwing makalawa"
            MedicineFrequency.SPECIFIC_DAYS -> "Piling araw"
        }
        AppLanguage.ENGLISH -> when (freq) {
            MedicineFrequency.EVERYDAY -> "Everyday"
            MedicineFrequency.EVERY_OTHER_DAY -> "Every other day"
            MedicineFrequency.SPECIFIC_DAYS -> "Specific days"
        }
        AppLanguage.TAGLISH -> when (freq) {
            MedicineFrequency.EVERYDAY -> "Everyday"
            MedicineFrequency.EVERY_OTHER_DAY -> "Every other day"
            MedicineFrequency.SPECIFIC_DAYS -> "Specific days"
        }
        AppLanguage.BISAYA -> when (freq) {
            MedicineFrequency.EVERYDAY -> "Kada adlaw"
            MedicineFrequency.EVERY_OTHER_DAY -> "Tag-duha ka adlaw"
            MedicineFrequency.SPECIFIC_DAYS -> "Pinili nga adlaw"
        }
        AppLanguage.ILOCANO -> when (freq) {
            MedicineFrequency.EVERYDAY -> "Inaldaw"
            MedicineFrequency.EVERY_OTHER_DAY -> "Tunggal makadua nga aldaw"
            MedicineFrequency.SPECIFIC_DAYS -> "Napili nga aldaw"
        }
    }

    fun soundStyleLabel(style: SoundStyle, lang: AppLanguage): String = when (lang) {
        AppLanguage.TAGALOG -> when (style) {
            SoundStyle.SWEET -> "Malambing"
            SoundStyle.NORMAL -> "Normal"
            SoundStyle.MAX_SHOUT -> "MAX SHOUT!"
        }
        AppLanguage.ENGLISH -> when (style) {
            SoundStyle.SWEET -> "Sweet"
            SoundStyle.NORMAL -> "Normal"
            SoundStyle.MAX_SHOUT -> "MAX SHOUT!"
        }
        AppLanguage.TAGLISH -> when (style) {
            SoundStyle.SWEET -> "Sweet"
            SoundStyle.NORMAL -> "Normal"
            SoundStyle.MAX_SHOUT -> "MAX SHOUT!"
        }
        AppLanguage.BISAYA -> when (style) {
            SoundStyle.SWEET -> "Malumo"
            SoundStyle.NORMAL -> "Normal"
            SoundStyle.MAX_SHOUT -> "MAX SHOUT!"
        }
        AppLanguage.ILOCANO -> when (style) {
            SoundStyle.SWEET -> "Naalumamay"
            SoundStyle.NORMAL -> "Normal"
            SoundStyle.MAX_SHOUT -> "MAX SHOUT!"
        }
    }

    fun themeLabel(mode: ThemeMode, lang: AppLanguage): String = when (lang) {
        AppLanguage.TAGALOG -> when (mode) {
            ThemeMode.PINK -> "Peach Pink"
            ThemeMode.LIGHT -> "Maliwanag"
            ThemeMode.DARK -> "Madilim"
        }
        AppLanguage.ENGLISH -> when (mode) {
            ThemeMode.PINK -> "Pink"
            ThemeMode.LIGHT -> "Light"
            ThemeMode.DARK -> "Dark"
        }
        AppLanguage.TAGLISH -> when (mode) {
            ThemeMode.PINK -> "Pink Peach"
            ThemeMode.LIGHT -> "Light"
            ThemeMode.DARK -> "Dark Mode"
        }
        AppLanguage.BISAYA -> when (mode) {
            ThemeMode.PINK -> "Pink"
            ThemeMode.LIGHT -> "Hayag"
            ThemeMode.DARK -> "Ngitngit"
        }
        AppLanguage.ILOCANO -> when (mode) {
            ThemeMode.PINK -> "Pink"
            ThemeMode.LIGHT -> "Nalawag"
            ThemeMode.DARK -> "Nasipnget"
        }
    }

    fun dayShortLabel(isoDay: Int, lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.TAGALOG, AppLanguage.TAGLISH -> listOf("Lun", "Mar", "Miy", "Huw", "Biy", "Sab", "Lin")[isoDay - 1]
            AppLanguage.ENGLISH -> listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")[isoDay - 1]
            AppLanguage.BISAYA -> listOf("Lun", "Mar", "Miy", "Huw", "Biy", "Sab", "Dom")[isoDay - 1]
            AppLanguage.ILOCANO -> listOf("Lun", "Mar", "Miy", "Huw", "Biy", "Sab", "Dom")[isoDay - 1]
        }
    }

    fun companionPersonality(companion: CompanionType, lang: AppLanguage): String = when (companion) {
        CompanionType.LUMI -> when (lang) {
            AppLanguage.TAGALOG -> "Makulit na Kuwago"
            AppLanguage.ENGLISH -> "Playful Cheeky Owl"
            AppLanguage.TAGLISH -> "Makulit Owl Bestie"
            AppLanguage.BISAYA -> "Kiat nga Kuwago"
            AppLanguage.ILOCANO -> "Naragsak a Kullaaw"
        }
        CompanionType.BRAM -> when (lang) {
            AppLanguage.TAGALOG -> "Mahinahon • Para kay Lola/Lolo"
            AppLanguage.ENGLISH -> "Gentle • Best for Lola/Lolo"
            AppLanguage.TAGLISH -> "Mahinahon • Sweet for Lola/Lolo"
            AppLanguage.BISAYA -> "Buotan • Para kang Lola/Lolo"
            AppLanguage.ILOCANO -> "Naalumamay • Para ken Lola/Lolo"
        }
        CompanionType.MIMI -> when (lang) {
            AppLanguage.TAGALOG -> "Cute at Sweet na Pusa"
            AppLanguage.ENGLISH -> "Sweet & Cute Kitty"
            AppLanguage.TAGLISH -> "Super Cute Kitty"
            AppLanguage.BISAYA -> "Gwapa ug Sweet nga Iring"
            AppLanguage.ILOCANO -> "Naayat ken Cute a Pusa"
        }
        CompanionType.KIKO -> when (lang) {
            AppLanguage.TAGALOG -> "Hyper at Masiglang Aso"
            AppLanguage.ENGLISH -> "Hyper Energetic Pup"
            AppLanguage.TAGLISH -> "Hyper Barkada Dog"
            AppLanguage.BISAYA -> "Abtik ug Hyper nga Iro"
            AppLanguage.ILOCANO -> "Nasalukag nga Aso"
        }
        CompanionType.TALA -> when (lang) {
            AppLanguage.TAGALOG -> "Chill pero Seryoso sa Gamot"
            AppLanguage.ENGLISH -> "Chill & Cool Fox"
            AppLanguage.TAGLISH -> "Chill Cool Bestie"
            AppLanguage.BISAYA -> "Chill nga Fox"
            AppLanguage.ILOCANO -> "Chill a Fox"
        }
    }

    fun companionPreviewVoice(companion: CompanionType, lang: AppLanguage): String = when (companion) {
        CompanionType.LUMI -> when (lang) {
            AppLanguage.TAGALOG -> "Hoot-hoot! Twit-twoo! Inumin mo na gamot mo, hoot!"
            AppLanguage.ENGLISH -> "Hoot-hoot! Twit-twoo! You must take your pill, hoot!"
            AppLanguage.TAGLISH -> "Hoot-hoot! Twit-twoo! Time na for your pill, bilis!"
            AppLanguage.BISAYA -> "Hoot-hoot! Twit-twoo! Inoma na imong tambal, hoot!"
            AppLanguage.ILOCANO -> "Hoot-hoot! Twit-twoo! Oras mon nga uminom ti agas!"
        }
        CompanionType.BRAM -> when (lang) {
            AppLanguage.TAGALOG -> "Mmm~ Bear hug muna! Anak, oras na ng gamot mo. Inumin mo na ha."
            AppLanguage.ENGLISH -> "Mmm~ Warm bear hug! My dear, it is time for your medicine."
            AppLanguage.TAGLISH -> "Mmm~ Bear hug! Anak, oras na ng meds mo. Take it gently ha."
            AppLanguage.BISAYA -> "Mmm~ Bear hug una! Anak, oras na sa imong tambal. Inoma na ha."
            AppLanguage.ILOCANO -> "Mmm~ Bear hug pay! Anakko, oras mon nga uminom ti agas."
        }
        CompanionType.MIMI -> when (lang) {
            AppLanguage.TAGALOG -> "Meow-meow~ Nyaa! Baby, time na para sa gamot mo, purr~"
            AppLanguage.ENGLISH -> "Meow-meow~ Nyaa! Sweetie, time for your vitamin pill, purr~"
            AppLanguage.TAGLISH -> "Meow-meow~ Nyaa! Baby, time na for your Vitamin, purr~"
            AppLanguage.BISAYA -> "Meow-meow~ Nyaa! Langga, oras na sa imong tambal, purr~"
            AppLanguage.ILOCANO -> "Meow-meow~ Nyaa! Ay-ayaten, oras mon ti bitamina, purr~"
        }
        CompanionType.KIKO -> when (lang) {
            AppLanguage.TAGALOG -> "Arf-arf! Woof-woof! Tara na! Gamot time na!"
            AppLanguage.ENGLISH -> "Arf-arf! Woof-woof! Let's go! Medicine time right now!"
            AppLanguage.TAGLISH -> "Arf-arf! Woof-woof! Tara na! Gamot time na, let's go!"
            AppLanguage.BISAYA -> "Arf-arf! Woof-woof! Dali na! Oras na sa tambal!"
            AppLanguage.ILOCANO -> "Arf-arf! Woof-woof! Intayon! Oras ti agas itan!"
        }
        CompanionType.TALA -> when (lang) {
            AppLanguage.TAGALOG -> "Yip-yip~ Yo, gamot time na. Wag ka pa-cool, inom na."
            AppLanguage.ENGLISH -> "Yip-yip~ Yo, medicine time. Stay cool, take your dose."
            AppLanguage.TAGLISH -> "Yip-yip~ Yo, meds time na. Wag ka pa-cool, inom na."
            AppLanguage.BISAYA -> "Yip-yip~ Yo, oras na sa tambal. Ayaw paglangan, inoma na."
            AppLanguage.ILOCANO -> "Yip-yip~ Yo, oras ti agas itan. Saan ka agpa-late, inumem."
        }
    }

    fun companionOnTimeMessage(companion: CompanionType, lang: AppLanguage): String = when (companion) {
        CompanionType.LUMI -> when (lang) {
            AppLanguage.TAGALOG -> "Hoot-hoot! Yay! Ang galing mo! Proud si Lumi sayo!"
            AppLanguage.ENGLISH -> "Hoot-hoot! Yay! You did awesome! I am so proud of you!"
            AppLanguage.TAGLISH -> "Hoot-hoot! Yay! Ang galing mo today! Proud si Lumi sayo!"
            AppLanguage.BISAYA -> "Hoot-hoot! Yay! Maayo kaayo ka! Proud kaayo ko nimo!"
            AppLanguage.ILOCANO -> "Hoot-hoot! Yay! Nalaing ka unay! Proud ak kenka!"
        }
        CompanionType.BRAM -> when (lang) {
            AppLanguage.TAGALOG -> "Mmm~ Masaya si Bram! Ang bait mo naman, anak."
            AppLanguage.ENGLISH -> "Mmm~ Bram is happy! You are taking great care of yourself."
            AppLanguage.TAGLISH -> "Mmm~ Bram is happy! Ang bait mo naman uminom on-time."
            AppLanguage.BISAYA -> "Mmm~ Lipay si Bram! Buotan kaayo ka, anak."
            AppLanguage.ILOCANO -> "Mmm~ Naragsak ni Bram! Nasingpet ka unay, anakko."
        }
        CompanionType.MIMI -> when (lang) {
            AppLanguage.TAGALOG -> "Meow~ Nyaa! Ang galing mo! Love you! Purr~"
            AppLanguage.ENGLISH -> "Meow~ Nyaa! Good job sweetie! Love you! Purr~"
            AppLanguage.TAGLISH -> "Meow~ Nyaa! Good girl or boy! Love you so much! Purr~"
            AppLanguage.BISAYA -> "Meow~ Nyaa! Maayo kaayo langga! Love you! Purr~"
            AppLanguage.ILOCANO -> "Meow~ Nyaa! Nalaing ka unay! Ay-ayaten ka! Purr~"
        }
        CompanionType.KIKO -> when (lang) {
            AppLanguage.TAGALOG -> "Arf-arf! Galing! High five, woof!"
            AppLanguage.ENGLISH -> "Arf-arf! Awesome! High five! Good job, woof!"
            AppLanguage.TAGLISH -> "Arf-arf! Good boy! High five, woof-woof!"
            AppLanguage.BISAYA -> "Arf-arf! Maayo kaayo! High five, woof!"
            AppLanguage.ILOCANO -> "Arf-arf! Nalaing! High five, woof!"
        }
        CompanionType.TALA -> when (lang) {
            AppLanguage.TAGALOG -> "Yip~ Nice, on-time ka. Astig ka talaga."
            AppLanguage.ENGLISH -> "Yip~ Nice, right on time. Super cool."
            AppLanguage.TAGLISH -> "Yip~ Nice, on-time ka today. Astig."
            AppLanguage.BISAYA -> "Yip~ Nice, sakto sa oras. Astig kaayo."
            AppLanguage.ILOCANO -> "Yip~ Nice, husto ti oras. Astig ka."
        }
    }

    fun companionLateMessage(companion: CompanionType, lang: AppLanguage, minutesLate: Int): String = when (companion) {
        CompanionType.LUMI -> when (lang) {
            AppLanguage.TAGALOG -> "HOOT-HOOT!! ${minutesLate}m late ka na! MAX SHOUT! Inumin mo na!"
            AppLanguage.ENGLISH -> "HOOT-HOOT!! You are ${minutesLate}m late! MAX SHOUT! Take it now!"
            AppLanguage.TAGLISH -> "HOOT-HOOT!! ${minutesLate}m late ka na! MAX SHOUT! Take your pill!"
            AppLanguage.BISAYA -> "HOOT-HOOT!! ${minutesLate}m late na ka! MAX SHOUT! Inoma na!"
            AppLanguage.ILOCANO -> "HOOT-HOOT!! ${minutesLate}m naladaw kan! MAX SHOUT! Inumem itan!"
        }
        CompanionType.BRAM -> when (lang) {
            AppLanguage.TAGALOG -> "Mmm, anak, late ka na ng ${minutesLate}m. Inumin mo na, nag-aalala si Bram."
            AppLanguage.ENGLISH -> "Mmm, dear, you are ${minutesLate}m late. Please take it, Bram is worried."
            AppLanguage.TAGLISH -> "Mmm, anak, ${minutesLate}m late ka na. Inumin na please, worried si Bram."
            AppLanguage.BISAYA -> "Mmm, anak, late na ka ug ${minutesLate}m. Inoma na, nabalaka si Bram."
            AppLanguage.ILOCANO -> "Mmm, anakko, naladaw kan iti ${minutesLate}m. Inumem itan, madanagan ni Bram."
        }
        CompanionType.MIMI -> when (lang) {
            AppLanguage.TAGALOG -> "Meow!! Nyaa! ${minutesLate}m late ka na! Magtatampo na si Mimi!"
            AppLanguage.ENGLISH -> "Meow!! Nyaa! ${minutesLate}m late! Mimi is pouting right now!"
            AppLanguage.TAGLISH -> "Meow!! Nyaa! ${minutesLate}m late ka na! Magagalit na si Mimi!"
            AppLanguage.BISAYA -> "Meow!! Nyaa! ${minutesLate}m late na ka! Masuk-an na si Mimi!"
            AppLanguage.ILOCANO -> "Meow!! Nyaa! ${minutesLate}m naladaw kan! Agungeten ni Mimi!"
        }
        CompanionType.KIKO -> when (lang) {
            AppLanguage.TAGALOG -> "Arf! Woof! ${minutesLate}m late ka na! Bilis! Takbo na sa gamot!"
            AppLanguage.ENGLISH -> "Arf! Woof! ${minutesLate}m late! Hurry up! Run to your medicine!"
            AppLanguage.TAGLISH -> "Arf! Woof! ${minutesLate}m late ka na! Bilis! Go take your meds!"
            AppLanguage.BISAYA -> "Arf! Woof! ${minutesLate}m late na ka! Dali! Kuhaa na ang tambal!"
            AppLanguage.ILOCANO -> "Arf! Woof! ${minutesLate}m naladaw kan! Darasem! Alaem ti agas!"
        }
        CompanionType.TALA -> when (lang) {
            AppLanguage.TAGALOG -> "Yip! Bro, ${minutesLate}m late ka na. Hindi cool yung late sa gamot."
            AppLanguage.ENGLISH -> "Yip! Hey, ${minutesLate}m late. Missing your dose isn't cool."
            AppLanguage.TAGLISH -> "Yip! Bro, ${minutesLate}m late ka na. Not cool mag-skip ng meds."
            AppLanguage.BISAYA -> "Yip! Bai, ${minutesLate}m late na ka. Dili cool ang malangan sa tambal."
            AppLanguage.ILOCANO -> "Yip! Pards, ${minutesLate}m naladaw kan. Saan a cool ti maladaw iti agas."
        }
    }

    fun companionSleepyMessage(companion: CompanionType, lang: AppLanguage): String = when (lang) {
        AppLanguage.TAGALOG -> "Tapos na lahat ng gamot today! Pahinga na tayo, zzz... (${companion.displayName})"
        AppLanguage.ENGLISH -> "All medicines done today! Time to rest, zzz... (${companion.displayName})"
        AppLanguage.TAGLISH -> "All done na ang meds today! Sleepy time na, zzz... (${companion.displayName})"
        AppLanguage.BISAYA -> "Nahuman na tanan tambal karon! Pahulay na ta, zzz... (${companion.displayName})"
        AppLanguage.ILOCANO -> "Nalpas amin nga agas ita! Aginana tayon, zzz... (${companion.displayName})"
    }

    fun companionMoodMessage(
        companion: CompanionType,
        mood: CompanionMood,
        lang: AppLanguage,
        minutesLate: Int
    ): String = when (mood) {
        CompanionMood.HAPPY -> companionOnTimeMessage(companion, lang)
        CompanionMood.ANGRY -> companionLateMessage(companion, lang, minutesLate.coerceAtLeast(15))
        CompanionMood.SLEEPY -> companionSleepyMessage(companion, lang)
    }

    fun notificationTitle(companion: CompanionType, isMaxShout: Boolean, lang: AppLanguage): String {
        val shoutTag = if (isMaxShout) " MAX SHOUT!!" else ""
        return when (companion) {
            CompanionType.LUMI -> "HOOT-HOOT!! AgasMo - Lumi$shoutTag"
            CompanionType.BRAM -> when (lang) {
                AppLanguage.ENGLISH -> "Bram Reminder$shoutTag"
                else -> "Bram Paalala$shoutTag"
            }
            CompanionType.MIMI -> "Meow~ Mimi Reminder$shoutTag"
            CompanionType.KIKO -> "Arf Arf! Kiko Reminder$shoutTag"
            CompanionType.TALA -> "Yip~ Tala Reminder$shoutTag"
        }
    }

    fun notificationBody(
        companion: CompanionType,
        lang: AppLanguage,
        medName: String,
        dosage: String,
        isMaxShout: Boolean,
        minutesLate: Int
    ): String {
        val medDisplay = if (dosage.isNotBlank()) "$medName ($dosage)" else medName
        if (isMaxShout) {
            val latePart = companionLateMessage(companion, lang, minutesLate.coerceAtLeast(30))
            return "$latePart — $medDisplay"
        }
        return when (companion) {
            CompanionType.LUMI -> when (lang) {
                AppLanguage.TAGALOG -> "Hoot-hoot! Twit-twoo! Oras na para uminom ng $medDisplay!"
                AppLanguage.ENGLISH -> "Hoot-hoot! Twit-twoo! Time to take $medDisplay! Don't miss it!"
                AppLanguage.TAGLISH -> "Hoot-hoot! Twit-twoo! Oras na for $medDisplay! Inumin mo na!"
                AppLanguage.BISAYA -> "Hoot-hoot! Twit-twoo! Oras na sa imong tambal - $medDisplay!"
                AppLanguage.ILOCANO -> "Hoot-hoot! Twit-twoo! Oras mon nga uminom ti agas - $medDisplay!"
            }
            CompanionType.BRAM -> when (lang) {
                AppLanguage.TAGALOG -> "Mmm~ Anak, oras na ng gamot mo - $medDisplay. Inumin mo na ha."
                AppLanguage.ENGLISH -> "Mmm~ Dear, time for your medicine - $medDisplay. Please take it."
                AppLanguage.TAGLISH -> "Mmm~ Anak, oras na ng $medDisplay mo. Take it gently ha."
                AppLanguage.BISAYA -> "Mmm~ Anak, oras na sa imong tambal - $medDisplay. Inoma na ha."
                AppLanguage.ILOCANO -> "Mmm~ Anakko, oras mon ti agas mo - $medDisplay. Inumem a."
            }
            CompanionType.MIMI -> when (lang) {
                AppLanguage.TAGALOG -> "Meow-meow~ Nyaa! Baby, oras na para sa $medDisplay! Purr~"
                AppLanguage.ENGLISH -> "Meow-meow~ Nyaa! Sweetie, time to take $medDisplay! Purr~"
                AppLanguage.TAGLISH -> "Meow-meow~ Nyaa! Baby, time na for $medDisplay! Purr~"
                AppLanguage.BISAYA -> "Meow-meow~ Nyaa! Langga, oras na sa $medDisplay! Purr~"
                AppLanguage.ILOCANO -> "Meow-meow~ Nyaa! Ay-ayaten, oras mon ti $medDisplay! Purr~"
            }
            CompanionType.KIKO -> when (lang) {
                AppLanguage.TAGALOG -> "Arf-arf! Woof! Gamot time na! $medDisplay, tara inumin na!"
                AppLanguage.ENGLISH -> "Arf-arf! Woof! Medicine time! $medDisplay, let's go!"
                AppLanguage.TAGLISH -> "Arf-arf! Woof! Gamot time na! $medDisplay, let's go!"
                AppLanguage.BISAYA -> "Arf-arf! Woof! Oras na sa tambal! $medDisplay, dali na!"
                AppLanguage.ILOCANO -> "Arf-arf! Woof! Oras ti agas itan! $medDisplay, intayon!"
            }
            CompanionType.TALA -> when (lang) {
                AppLanguage.TAGALOG -> "Yip~ Yo, gamot time na - $medDisplay. Wag ka pa-cool, inom na."
                AppLanguage.ENGLISH -> "Yip~ Yo, medicine time - $medDisplay. Stay sharp, take it now."
                AppLanguage.TAGLISH -> "Yip~ Yo, meds time na - $medDisplay. Wag ka pa-cool, inom na."
                AppLanguage.BISAYA -> "Yip~ Yo, oras na sa tambal - $medDisplay. Ayaw paglangan, inoma na."
                AppLanguage.ILOCANO -> "Yip~ Yo, oras ti agas itan - $medDisplay. Saan agpa-late, inumem."
            }
        }
    }

    private val tagalogStrings = AppStrings(
        appTagline = "Aga sa Gamot Mo",
        navToday = "Ngayon",
        navAdd = "Magdagdag",
        navHistory = "Kasaysayan",
        navCompanion = "Kasama",
        navProfile = "Profile",
        onboardingLangTitle = "Anong wika mo? / What is your language?",
        onboardingLangSubtitle = "Pumili ng wikang pinakamadali para sayo.",
        hearExample = "Pakinggan",
        continueBtn = "Magpatuloy",
        onboardingCompanionTitle = "Sino gusto mong kasama sa pag-inom ng gamot?",
        onboardingCompanionSubtitle = "Pindutin para marinig ang boses nila!",
        hearVoice = "Pakinggan",
        startWithCompanion = { name -> "Simulan na with $name!" },
        homeGreeting = { name -> "Kamusta, $name!" },
        nextMedicineTitle = "Susunod na Gamot",
        noMoreMedsToday = "Wala pang naka-schedule o tapos na lahat today!",
        addFirstMedTip = "Pindutin ang + Magdagdag para maglagay ng gamot.",
        takeNow = "Inumin Na",
        snooze10m = "Snooze 10m",
        skipBtn = "Laktawan",
        lateMinutesShout = { m -> "Late ka na ng $m minuto! MAX SHOUT!" },
        inHoursMins = { h, m -> "sa loob ng ${h}h ${m}m" },
        inMins = { m -> "sa loob ng ${m}m" },
        dueNow = "Oras na ngayon!",
        progressToday = { done, total -> "$done/$total gamot na-inom mo today! Good job!" },
        notifOffBanner = { comp -> "Naka-OFF yung notification mo! Hindi ka maaalalahanan ni $comp. Pindutin dito para i-ON." },
        searchMedsHint = "Hanapin ang pangalan ng gamot...",
        todayMedsHeader = "Mga Gamot Ngayon",
        statusTaken = "Nainom",
        statusLate = "Late!",
        statusUpcoming = "Malapit na",
        statusSkipped = "Nilaktawan",
        voiceAlertToggle = "Boses",
        snoozedToast = "Na-snooze ng 10 minuto!",
        takenToast = { name -> "Nainom na ang $name! Galing!" },
        skippedToast = { name -> "Nilaktawan ang $name." },
        permDialogTitle = { comp -> "Payagan si $comp mag-notify!" },
        permDialogBody = { comp -> "Payagan mo si $comp na mag-notify sayo? Para maalala mo gamot mo!" },
        permAllow = "Payagan",
        permLater = "Mamaya na",
        addMedTitle = "Magdagdag ng Gamot",
        editMedTitle = "I-edit ang Gamot",
        medNameLabel = "Pangalan ng Gamot (hal. Vitamin B 500)",
        dosageLabel = "Dosage (hal. 500mg)",
        typeLabel = "Uri ng Gamot",
        colorLabel = "Kulay",
        photoOptionalLabel = "Larawan ng Gamot (Opsyonal)",
        pickPhotoBtn = "Pumili ng Larawan",
        removePhotoBtn = "Tanggalin",
        timesLabel = "Mga Oras sa Isang Araw",
        addTimeBtn = "+ Magdagdag ng Oras",
        frequencyLabel = "Dalas ng Pag-inom",
        durationLabel = "Tagal ng Pag-inom",
        duration7Days = "7 araw",
        duration30Days = "30 araw",
        durationForever = "Habang buhay",
        reminderLabel = "Paalala Bago ang Oras",
        rem30Before = "30m bago",
        rem10Before = "10m bago",
        remOnTime = "Sa tamang oras",
        maxShoutLabel = "MAX SHOUT kapag late (30m+)",
        soundStyleLabel = "Boses ng Kasama",
        saveMedBtn = "I-save at I-schedule",
        medSavedToast = { name -> "Na-save at naka-alarm na ang $name!" },
        medDeletedToast = "Natanggal na ang gamot.",
        deleteMedBtn = "Tanggalin ang Gamot",
        enterMedNameError = "Pakilagay ang pangalan ng gamot.",
        historyTitle = "Kasaysayan at Streak",
        streakLabel = { days -> "$days araw na streak! 🔥" },
        adherenceThisWeek = "Pagsunod ngayong linggo",
        exportToDoctor = "I-export sa Doktor",
        noLogsForDate = "Walang nakalistang pag-inom sa petsang ito.",
        profileTitle = "Profile at Settings",
        userNameLabel = "Pangalan mo",
        userAgeLabel = "Edad",
        saveProfileBtn = "I-save ang Profile",
        profileSavedToast = "Na-save na ang profile!",
        sectionLanguage = "Wika / Language",
        languageChangedToast = "Napalitan na sa Tagalog!",
        sectionCompanion = "Ang Aking Kasama",
        currentCompanionLabel = "Kasalukuyang Kasama",
        changeBtn = "Palitan",
        hearShoutBtn = "Pakinggan ang MAX SHOUT",
        sectionNotifications = "Mga Notification at Tunog",
        masterNotifLabel = "Mga Notification",
        soundLabel = "Malakas na Tunog",
        vibrationLabel = "Vibration",
        openSystemNotifSettings = "Buksan ang System Notification Settings",
        batteryOptimizeBtn = "I-exempt sa Battery Saver (Para di mapatay alarm)",
        batteryOptimizedAlready = "Naka-exempt na sa Battery Saver ✓",
        sectionTheme = "Tema ng App",
        sectionEmergency = "Emergency Contact (Kapag 2 oras nang late)",
        emergencyNameLabel = "Pangalan ng Kaanak",
        emergencyPhoneLabel = "Numero ng Telepono",
        emergencyHint = "Kapag hindi nainom ng 2 oras, may lalabas na mabilisang alert button.",
        emergencyAlertBtn = { name -> "I-text si $name ngayon" },
        emergencyLateBanner = { name -> "2+ oras nang late! Magpadala ng alert kay $name?" },
        aboutLabel = "AgasMo v1.0 • Offline Medicine Companion",
        companionScreenTitle = "Mood ng Kasama Mo",
        moodHappyLabel = "Masaya dahil on-time ka!",
        moodAngryLabel = "Nag-aalala / Nagagalit! Late ka na!",
        moodSleepyLabel = "Inaantok na dahil tapos lahat!",
        playVoiceBtn = "Magsalita",
        badgesTitle = "Mga Parangal (Badges)",
        badgeOnTimeTitle = "On-Time King",
        badgeOnTimeDesc = "Naka-inom ng 5 gamot sa tamang oras",
        badgeStreakTitle = "7-Day Streak",
        badgeStreakDesc = "7 sunod-sunod na araw ng pag-inom",
        badgeFriendTitle = { comp -> "$comp Best Friend" },
        badgeFriendDesc = { comp -> "Nakumpleto ang pag-inom kasama si $comp" },
        unlockedLabel = "Nakuha Na!",
        cancelBtn = "Kanselahin",
        editBtn = "I-edit"
    )

    private val englishStrings = AppStrings(
        appTagline = "Early on Your Medicine",
        navToday = "Today",
        navAdd = "Add Med",
        navHistory = "History",
        navCompanion = "Companion",
        navProfile = "Profile",
        onboardingLangTitle = "Anong wika mo? / What is your language?",
        onboardingLangSubtitle = "Choose the language you are most comfortable with.",
        hearExample = "Hear Example",
        continueBtn = "Continue",
        onboardingCompanionTitle = "Who do you want as your companion?",
        onboardingCompanionSubtitle = "Tap any card to hear their voice!",
        hearVoice = "Hear Voice",
        startWithCompanion = { name -> "Start now with $name!" },
        homeGreeting = { name -> "Hello, $name!" },
        nextMedicineTitle = "Next Medicine",
        noMoreMedsToday = "No medicines scheduled or all done today!",
        addFirstMedTip = "Tap + Add Med below to schedule your medicine.",
        takeNow = "Take Now",
        snooze10m = "Snooze 10m",
        skipBtn = "Skip",
        lateMinutesShout = { m -> "You are $m minutes late! MAX SHOUT!" },
        inHoursMins = { h, m -> "in ${h}h ${m}m" },
        inMins = { m -> "in ${m}m" },
        dueNow = "Due right now!",
        progressToday = { done, total -> "$done/$total medicines taken today! Good job!" },
        notifOffBanner = { comp -> "Notifications are OFF! $comp can't remind you. Tap here to turn ON." },
        searchMedsHint = "Search medicine by name...",
        todayMedsHeader = "Today's Medicines",
        statusTaken = "Taken",
        statusLate = "Late!",
        statusUpcoming = "Upcoming",
        statusSkipped = "Skipped",
        voiceAlertToggle = "Voice",
        snoozedToast = "Snoozed for 10 mins!",
        takenToast = { name -> "Took $name! Great job!" },
        skippedToast = { name -> "Skipped $name." },
        permDialogTitle = { comp -> "Allow $comp to notify you?" },
        permDialogBody = { comp -> "Allow $comp to send loud reminders so you never miss your medicine!" },
        permAllow = "Allow",
        permLater = "Not now",
        addMedTitle = "Add Medicine",
        editMedTitle = "Edit Medicine",
        medNameLabel = "Medicine Name (e.g. Vitamin B 500)",
        dosageLabel = "Dosage (e.g. 500mg)",
        typeLabel = "Medicine Type",
        colorLabel = "Color",
        photoOptionalLabel = "Medicine Photo (Optional)",
        pickPhotoBtn = "Choose Photo",
        removePhotoBtn = "Remove",
        timesLabel = "Times Per Day",
        addTimeBtn = "+ Add Time",
        frequencyLabel = "Frequency",
        durationLabel = "Duration",
        duration7Days = "7 days",
        duration30Days = "30 days",
        durationForever = "Forever",
        reminderLabel = "Reminder Timing",
        rem30Before = "30m before",
        rem10Before = "10m before",
        remOnTime = "On time",
        maxShoutLabel = "MAX SHOUT when late (30m+)",
        soundStyleLabel = "Companion Voice Style",
        saveMedBtn = "Save & Schedule Alarm",
        medSavedToast = { name -> "Saved and scheduled $name!" },
        medDeletedToast = "Medicine deleted.",
        deleteMedBtn = "Delete Medicine",
        enterMedNameError = "Please enter the medicine name.",
        historyTitle = "History & Streak",
        streakLabel = { days -> "$days days streak! 🔥" },
        adherenceThisWeek = "Adherence this week",
        exportToDoctor = "Export to Doctor",
        noLogsForDate = "No medicine logs for this date.",
        profileTitle = "Profile & Settings",
        userNameLabel = "Your Name",
        userAgeLabel = "Age",
        saveProfileBtn = "Save Profile",
        profileSavedToast = "Profile saved!",
        sectionLanguage = "Wika / Language",
        languageChangedToast = "Language changed to English!",
        sectionCompanion = "My Companion",
        currentCompanionLabel = "Current Companion",
        changeBtn = "Change",
        hearShoutBtn = "Hear Shout",
        sectionNotifications = "Notification & Sound",
        masterNotifLabel = "Notifications",
        soundLabel = "Loud Sound",
        vibrationLabel = "Vibration",
        openSystemNotifSettings = "Open System Notification Settings",
        batteryOptimizeBtn = "Ignore Battery Optimization (Keep alarms alive)",
        batteryOptimizedAlready = "Battery Optimization Ignored ✓",
        sectionTheme = "Theme",
        sectionEmergency = "Emergency Contact (2h late alert)",
        emergencyNameLabel = "Contact Name",
        emergencyPhoneLabel = "Phone Number",
        emergencyHint = "If a dose is 2+ hours late, a quick SMS alert button appears.",
        emergencyAlertBtn = { name -> "Message $name now" },
        emergencyLateBanner = { name -> "2+ hours late! Send an alert to $name?" },
        aboutLabel = "AgasMo v1.0 • Offline Medicine Companion",
        companionScreenTitle = "Companion Mood",
        moodHappyLabel = "Happy because you're on time!",
        moodAngryLabel = "Grumpy & worried! You're late!",
        moodSleepyLabel = "Sleepy because all meds are done!",
        playVoiceBtn = "Speak",
        badgesTitle = "Rewards & Badges",
        badgeOnTimeTitle = "On-Time King",
        badgeOnTimeDesc = "Took 5 doses right on schedule",
        badgeStreakTitle = "7-Day Streak",
        badgeStreakDesc = "7 consecutive days of taking meds",
        badgeFriendTitle = { comp -> "$comp Best Friend" },
        badgeFriendDesc = { comp -> "Completed doses with $comp" },
        unlockedLabel = "Unlocked!",
        cancelBtn = "Cancel",
        editBtn = "Edit"
    )

    private val taglishStrings = AppStrings(
        appTagline = "Aga sa Gamot Mo",
        navToday = "Today",
        navAdd = "Add Med",
        navHistory = "History",
        navCompanion = "Bestie",
        navProfile = "Profile",
        onboardingLangTitle = "Anong wika mo? / What is your language?",
        onboardingLangSubtitle = "Pick the language na pinaka-comfy ka!",
        hearExample = "Hear Example",
        continueBtn = "Gora na!",
        onboardingCompanionTitle = "Sino gusto mo maging kasama mo?",
        onboardingCompanionSubtitle = "Tap to hear their cute voices!",
        hearVoice = "Hear Voice",
        startWithCompanion = { name -> "Simulan na with $name!" },
        homeGreeting = { name -> "Kamusta, $name! Musta ka?" },
        nextMedicineTitle = "Next na Gamot mo",
        noMoreMedsToday = "Walang meds or tapos na lahat today!",
        addFirstMedTip = "Tap + Add Med below para mag-add ng meds.",
        takeNow = "Inumin mo na, please!",
        snooze10m = "Snooze muna 10m, okay?",
        skipBtn = "Skip muna",
        lateMinutesShout = { m -> "Hala, late ka na ng ${m}m! HOOT-HOOT!" },
        inHoursMins = { h, m -> "in ${h}h ${m}m" },
        inMins = { m -> "in ${m}m" },
        dueNow = "Time na now na!",
        progressToday = { done, total -> "$done/$total gamot taken na today! Nice one!" },
        notifOffBanner = { comp -> "Naka-OFF ang notification mo! Di ka mare-remind ni $comp. Tap here para i-ON." },
        searchMedsHint = "Search gamot by name...",
        todayMedsHeader = "Meds mo Today",
        statusTaken = "Taken na",
        statusLate = "Hala Late!",
        statusUpcoming = "Soon",
        statusSkipped = "Skipped",
        voiceAlertToggle = "Voice",
        snoozedToast = "Snoozed muna 10 mins!",
        takenToast = { name -> "Taken na si $name! Nice!" },
        skippedToast = { name -> "Na-skip si $name." },
        permDialogTitle = { comp -> "Allow si $comp to notify you?" },
        permDialogBody = { comp -> "Allow mo si $comp mag-notify sayo para di mo makalimutan ang meds mo!" },
        permAllow = "Allow",
        permLater = "Later",
        addMedTitle = "Add New Gamot",
        editMedTitle = "Edit Gamot",
        medNameLabel = "Medicine Name (ex. Vitamin B 500)",
        dosageLabel = "Dosage (ex. 500mg)",
        typeLabel = "Type ng Gamot",
        colorLabel = "Color",
        photoOptionalLabel = "Pic ng Gamot (Optional)",
        pickPhotoBtn = "Pick Photo",
        removePhotoBtn = "Remove",
        timesLabel = "Times Per Day",
        addTimeBtn = "+ Add Time",
        frequencyLabel = "How often?",
        durationLabel = "Duration",
        duration7Days = "7 days",
        duration30Days = "30 days",
        durationForever = "Forever",
        reminderLabel = "Kelan mag-remind?",
        rem30Before = "30m before",
        rem10Before = "10m before",
        remOnTime = "On time",
        maxShoutLabel = "MAX SHOUT pag late (30m+)",
        soundStyleLabel = "Companion Voice Vibe",
        saveMedBtn = "Save & Set Alarm",
        medSavedToast = { name -> "Saved & naka-alarm na si $name!" },
        medDeletedToast = "Deleted na yung med.",
        deleteMedBtn = "Delete Med",
        enterMedNameError = "Lagay muna name ng gamot please.",
        historyTitle = "History & Streak",
        streakLabel = { days -> "$days days streak! 🔥" },
        adherenceThisWeek = "Adherence this week",
        exportToDoctor = "Share sa Doctor",
        noLogsForDate = "No logs for this date pa.",
        profileTitle = "Profile & Settings",
        userNameLabel = "Name mo",
        userAgeLabel = "Age",
        saveProfileBtn = "Save Profile",
        profileSavedToast = "Profile saved!",
        sectionLanguage = "Wika / Language",
        languageChangedToast = "Language changed to Taglish!",
        sectionCompanion = "My Companion",
        currentCompanionLabel = "Current Bestie",
        changeBtn = "Change",
        hearShoutBtn = "Hear Shout",
        sectionNotifications = "Notification Settings",
        masterNotifLabel = "Notifications",
        soundLabel = "Loud Sound",
        vibrationLabel = "Vibration",
        openSystemNotifSettings = "Open System Notification Settings",
        batteryOptimizeBtn = "Ignore Battery Saver (Para sure ang alarm)",
        batteryOptimizedAlready = "Battery Saver Ignored ✓",
        sectionTheme = "Theme",
        sectionEmergency = "Emergency Contact (2h late alert)",
        emergencyNameLabel = "Contact Name",
        emergencyPhoneLabel = "Phone Number",
        emergencyHint = "Pag 2 hours nang late, may quick SMS alert button.",
        emergencyAlertBtn = { name -> "Message si $name" },
        emergencyLateBanner = { name -> "2+ hours late! Text na ba si $name?" },
        aboutLabel = "AgasMo v1.0 • Offline Medicine Companion",
        companionScreenTitle = "Companion Mood",
        moodHappyLabel = "Happy kasi on-time ka!",
        moodAngryLabel = "Galit mode! Late ka na!",
        moodSleepyLabel = "Sleepy na kasi done na all meds!",
        playVoiceBtn = "Play Voice",
        badgesTitle = "Badges mo",
        badgeOnTimeTitle = "On-Time King",
        badgeOnTimeDesc = "5 meds taken on-time!",
        badgeStreakTitle = "7-Day Streak",
        badgeStreakDesc = "7 straight days ng pag-inom!",
        badgeFriendTitle = { comp -> "$comp Best Friend" },
        badgeFriendDesc = { comp -> "Super close na kayo ni $comp" },
        unlockedLabel = "Unlocked!",
        cancelBtn = "Cancel",
        editBtn = "Edit"
    )

    private val bisayaStrings = AppStrings(
        appTagline = "Sayon sa Imong Tambal",
        navToday = "Karon",
        navAdd = "Dugang",
        navHistory = "Kasaysayan",
        navCompanion = "Kauban",
        navProfile = "Profile",
        onboardingLangTitle = "Unsa imong pinulongan? / Language?",
        onboardingLangSubtitle = "Pilia ang pinulongan nga labing sayon para nimo.",
        hearExample = "Paminawa",
        continueBtn = "Padayon",
        onboardingCompanionTitle = "Kinsa imong gusto nga kauban?",
        onboardingCompanionSubtitle = "Pindota aron madungog ang ilang tingog!",
        hearVoice = "Paminaw",
        startWithCompanion = { name -> "Sugdi na uban ni $name!" },
        homeGreeting = { name -> "Kumusta, $name!" },
        nextMedicineTitle = "Sunod nga Tambal",
        noMoreMedsToday = "Walay tambal o nahuman na tanan karon!",
        addFirstMedTip = "Pindota ang + Dugang sa ubos aron magbutang ug tambal.",
        takeNow = "Inoma Na",
        snooze10m = "I-snooze 10m",
        skipBtn = "Laktawi",
        lateMinutesShout = { m -> "Late na ka ug $m minutos! MAX SHOUT!" },
        inHoursMins = { h, m -> "sulod sa ${h}h ${m}m" },
        inMins = { m -> "sulod sa ${m}m" },
        dueNow = "Oras na karon!",
        progressToday = { done, total -> "$done/$total tambal ang nainom karon! Maayo kaayo!" },
        notifOffBanner = { comp -> "Naka-OFF ang imong notification! Dili ka mapahinumdoman ni $comp. Pindota diri aron i-ON." },
        searchMedsHint = "Pangitaa ang ngalan sa tambal...",
        todayMedsHeader = "Mga Tambal Karon",
        statusTaken = "Nainom",
        statusLate = "Late!",
        statusUpcoming = "Hapit na",
        statusSkipped = "Gilaktawan",
        voiceAlertToggle = "Tingog",
        snoozedToast = "Gi-snooze ug 10 minutos!",
        takenToast = { name -> "Nainom na ang $name! Maayo!" },
        skippedToast = { name -> "Gilaktawan ang $name." },
        permDialogTitle = { comp -> "Tugoti si $comp nga mo-notify!" },
        permDialogBody = { comp -> "Tugoti si $comp nga mo-notify nimo aron mahinumdoman ang imong tambal!" },
        permAllow = "Tugoti",
        permLater = "Unya na",
        addMedTitle = "Magdugang ug Tambal",
        editMedTitle = "Usba ang Tambal",
        medNameLabel = "Ngalan sa Tambal (pananglitan Vitamin B 500)",
        dosageLabel = "Dosage (pananglitan 500mg)",
        typeLabel = "Klase sa Tambal",
        colorLabel = "Kolor",
        photoOptionalLabel = "Hulagway sa Tambal (Opsyonal)",
        pickPhotoBtn = "Pili ug Hulagway",
        removePhotoBtn = "Tangtanga",
        timesLabel = "Mga Oras Kada Adlaw",
        addTimeBtn = "+ Dugang Oras",
        frequencyLabel = "Kanus-a Inomon",
        durationLabel = "Kadugayon",
        duration7Days = "7 ka adlaw",
        duration30Days = "30 ka adlaw",
        durationForever = "Hangtod sa hangtod",
        reminderLabel = "Pahinumdom",
        rem30Before = "30m sa wala pa",
        rem10Before = "10m sa wala pa",
        remOnTime = "Sa saktong oras",
        maxShoutLabel = "MAX SHOUT kung late (30m+)",
        soundStyleLabel = "Tingog sa Kauban",
        saveMedBtn = "I-save ug I-alarm",
        medSavedToast = { name -> "Na-save ug naka-alarm na ang $name!" },
        medDeletedToast = "Natangtang na ang tambal.",
        deleteMedBtn = "Tangtanga ang Tambal",
        enterMedNameError = "Palihog isulat ang ngalan sa tambal.",
        historyTitle = "Kasaysayan ug Streak",
        streakLabel = { days -> "$days ka adlaw nga streak! 🔥" },
        adherenceThisWeek = "Pagsunod karong semanaha",
        exportToDoctor = "Ipadala sa Doktor",
        noLogsForDate = "Walay rekord sa tambal niining petsaha.",
        profileTitle = "Profile ug Settings",
        userNameLabel = "Imong Ngalan",
        userAgeLabel = "Edad",
        saveProfileBtn = "I-save ang Profile",
        profileSavedToast = "Na-save na ang profile!",
        sectionLanguage = "Pinulongan / Language",
        languageChangedToast = "Gibalhin na sa Bisaya!",
        sectionCompanion = "Akong Kauban",
        currentCompanionLabel = "Kasamtangang Kauban",
        changeBtn = "Ilisi",
        hearShoutBtn = "Paminawa ang MAX SHOUT",
        sectionNotifications = "Mga Notification ug Tingog",
        masterNotifLabel = "Mga Notification",
        soundLabel = "Kusog nga Tingog",
        vibrationLabel = "Vibration",
        openSystemNotifSettings = "Ablihi ang System Notification Settings",
        batteryOptimizeBtn = "I-exempt sa Battery Saver",
        batteryOptimizedAlready = "Naka-exempt na sa Battery Saver ✓",
        sectionTheme = "Tema sa App",
        sectionEmergency = "Emergency Contact (2h late alert)",
        emergencyNameLabel = "Ngalan sa Pamilya",
        emergencyPhoneLabel = "Numero sa Telepono",
        emergencyHint = "Kung 2 ka oras na nga late, mogawas ang dali nga alert button.",
        emergencyAlertBtn = { name -> "I-text si $name karon" },
        emergencyLateBanner = { name -> "2+ ka oras na nga late! Padad-an ug alert si $name?" },
        aboutLabel = "AgasMo v1.0 • Offline Medicine Companion",
        companionScreenTitle = "Mood sa Imong Kauban",
        moodHappyLabel = "Malipayon kay sakto ka sa oras!",
        moodAngryLabel = "Nabalaka ug nasuko! Late na ka!",
        moodSleepyLabel = "Katulgon na kay nahuman na tanan!",
        playVoiceBtn = "Patingoga",
        badgesTitle = "Mga Pasidungog (Badges)",
        badgeOnTimeTitle = "On-Time King",
        badgeOnTimeDesc = "Nakainom ug 5 ka tambal sa saktong oras",
        badgeStreakTitle = "7-Day Streak",
        badgeStreakDesc = "7 ka sunod-sunod nga adlaw nga pag-inom",
        badgeFriendTitle = { comp -> "$comp Best Friend" },
        badgeFriendDesc = { comp -> "Nahuman ang tambal uban ni $comp" },
        unlockedLabel = "Nakuha Na!",
        cancelBtn = "Kanselahon",
        editBtn = "Usba"
    )

    private val ilocanoStrings = AppStrings(
        appTagline = "Nasapa nga Agas Mo",
        navToday = "Ita",
        navAdd = "Agnayon",
        navHistory = "Pakasaritaan",
        navCompanion = "Kadua",
        navProfile = "Profile",
        onboardingLangTitle = "Ania ti pagsasaom? / Language?",
        onboardingLangSubtitle = "Piliem ti pagsasao a kalakaan kenka.",
        hearExample = "Denggen",
        continueBtn = "Agtuloy",
        onboardingCompanionTitle = "Sino ti kayat mo a kaduam?",
        onboardingCompanionSubtitle = "Pindutem tapno mangngeg ti timek da!",
        hearVoice = "Denggen",
        startWithCompanion = { name -> "Rugianen kadua ni $name!" },
        homeGreeting = { name -> "Kumusta ka, $name!" },
        nextMedicineTitle = "Sumaruno nga Agas",
        noMoreMedsToday = "Awan pay ti agas wenno nalpas amin ita!",
        addFirstMedTip = "Pindutem ti + Agnayon tapno ikabil ti agas mo.",
        takeNow = "Inumem",
        snooze10m = "I-snooze 10m",
        skipBtn = "Labsan",
        lateMinutesShout = { m -> "Naladaw kan iti $m minutos! MAX SHOUT!" },
        inHoursMins = { h, m -> "iti uneg ti ${h}h ${m}m" },
        inMins = { m -> "iti uneg ti ${m}m" },
        dueNow = "Oras nan ita!",
        progressToday = { done, total -> "$done/$total agas ti nainom mo ita! Nalaing!" },
        notifOffBanner = { comp -> "Naka-OFF ti notification mo! Saan na ka mapalagipan ni $comp. Pindutem ditoy tapno i-ON." },
        searchMedsHint = "Biroken ti nagan ti agas...",
        todayMedsHeader = "Dagiti Agas Ita",
        statusTaken = "Nainom",
        statusLate = "Naladaw!",
        statusUpcoming = "Asidegen",
        statusSkipped = "Nalabsan",
        voiceAlertToggle = "Timek",
        snoozedToast = "Nai-snooze iti 10 minutos!",
        takenToast = { name -> "Nainom mon ti $name! Nalaing!" },
        skippedToast = { name -> "Nalabsan ti $name." },
        permDialogTitle = { comp -> "Palubosan ni $comp nga ag-notify!" },
        permDialogBody = { comp -> "Palubosam ni $comp nga ag-notify kenka tapno malagip mo ti agas mo!" },
        permAllow = "Palubosan",
        permLater = "Inton madamdama",
        addMedTitle = "Agnayon ti Agas",
        editMedTitle = "Baliwan ti Agas",
        medNameLabel = "Nagan ti Agas (kas. Vitamin B 500)",
        dosageLabel = "Dosage (kas. 500mg)",
        typeLabel = "Klase ti Agas",
        colorLabel = "Maris",
        photoOptionalLabel = "Ladawan ti Agas (Opsyonal)",
        pickPhotoBtn = "Agpili ti Ladawan",
        removePhotoBtn = "Ikkaten",
        timesLabel = "Oras iti Maysa nga Aldaw",
        addTimeBtn = "+ Agnayon ti Oras",
        frequencyLabel = "Kaadu ti Panaginom",
        durationLabel = "Kapaut na",
        duration7Days = "7 nga aldaw",
        duration30Days = "30 nga aldaw",
        durationForever = "Agnanayon",
        reminderLabel = "Palagip Sakbay ti Oras",
        rem30Before = "30m sakbay",
        rem10Before = "10m sakbay",
        remOnTime = "Husto nga oras",
        maxShoutLabel = "MAX SHOUT no naladaw (30m+)",
        soundStyleLabel = "Timek ti Kadua",
        saveMedBtn = "I-save ken I-alarm",
        medSavedToast = { name -> "Nai-save ken naka-alarmen ti $name!" },
        medDeletedToast = "Naikkaten ti agas.",
        deleteMedBtn = "Ikkaten ti Agas",
        enterMedNameError = "Ikabil pay ti nagan ti agas.",
        historyTitle = "Pakasaritaan ken Streak",
        streakLabel = { days -> "$days nga aldaw a streak! 🔥" },
        adherenceThisWeek = "Panagtungpal ita a lawas",
        exportToDoctor = "Ipatulod iti Doktor",
        noLogsForDate = "Awan ti rekord ti agas iti daytoy a petsa.",
        profileTitle = "Profile ken Settings",
        userNameLabel = "Nagan mo",
        userAgeLabel = "Tawen",
        saveProfileBtn = "I-save ti Profile",
        profileSavedToast = "Nai-save ti profile!",
        sectionLanguage = "Pagsasao / Language",
        languageChangedToast = "Nabaliwanen iti Ilocano!",
        sectionCompanion = "Ti Kaduak",
        currentCompanionLabel = "Agdama a Kadua",
        changeBtn = "Baliwan",
        hearShoutBtn = "Denggen ti MAX SHOUT",
        sectionNotifications = "Notification ken Uni",
        masterNotifLabel = "Dagiti Notification",
        soundLabel = "Napigsa nga Uni",
        vibrationLabel = "Vibration",
        openSystemNotifSettings = "Lukatan ti System Notification Settings",
        batteryOptimizeBtn = "I-exempt iti Battery Saver",
        batteryOptimizedAlready = "Naka-exempt iti Battery Saver ✓",
        sectionTheme = "Tema ti App",
        sectionEmergency = "Emergency Contact (2h late alert)",
        emergencyNameLabel = "Nagan ti Kabagian",
        emergencyPhoneLabel = "Numero ti Telepono",
        emergencyHint = "No 2 nga oras a naladaw, agparang ti alisto nga alert button.",
        emergencyAlertBtn = { name -> "I-text ni $name ita" },
        emergencyLateBanner = { name -> "2+ nga oras a naladaw! Agipatulod ti alert ken $name?" },
        aboutLabel = "AgasMo v1.0 • Offline Medicine Companion",
        companionScreenTitle = "Mood ti Kaduam",
        moodHappyLabel = "Naragsak ta husto ti oras mo!",
        moodAngryLabel = "Madanagan ken agunget! Naladaw kan!",
        moodSleepyLabel = "Makaturturogen ta nalpas amin!",
        playVoiceBtn = "Agsao",
        badgesTitle = "Dagiti Pammadayaw (Badges)",
        badgeOnTimeTitle = "On-Time King",
        badgeOnTimeDesc = "Nainom ti 5 nga agas iti husto nga oras",
        badgeStreakTitle = "7-Day Streak",
        badgeStreakDesc = "7 nga agsasaruno nga aldaw a panaginom",
        badgeFriendTitle = { comp -> "$comp Best Friend" },
        badgeFriendDesc = { comp -> "Nalpas ti agas kadua ni $comp" },
        unlockedLabel = "Naala Mon!",
        cancelBtn = "Kanselaren",
        editBtn = "Baliwan"
    )
}
