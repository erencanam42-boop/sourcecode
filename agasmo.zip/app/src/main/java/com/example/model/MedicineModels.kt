package com.example.model

enum class MedicineType(val code: String) {
    TABLET("TABLET"),
    CAPSULE("CAPSULE"),
    SYRUP("SYRUP"),
    INJECTION("INJECTION");

    companion object {
        fun fromCode(code: String?): MedicineType =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: TABLET
    }
}

enum class MedicineFrequency(val code: String) {
    EVERYDAY("EVERYDAY"),
    EVERY_OTHER_DAY("EVERY_OTHER_DAY"),
    SPECIFIC_DAYS("SPECIFIC_DAYS");

    companion object {
        fun fromCode(code: String?): MedicineFrequency =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: EVERYDAY
    }
}

enum class SoundStyle(val code: String) {
    SWEET("SWEET"),
    NORMAL("NORMAL"),
    MAX_SHOUT("MAX_SHOUT");

    companion object {
        fun fromCode(code: String?): SoundStyle =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: NORMAL
    }
}

enum class ThemeMode(val code: String) {
    PINK("PINK"),
    LIGHT("LIGHT"),
    DARK("DARK");

    companion object {
        fun fromCode(code: String?): ThemeMode =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: PINK
    }
}

enum class DoseStatus {
    TAKEN,
    LATE,
    UPCOMING,
    SKIPPED
}

data class TodayDoseItem(
    val medicineId: Long,
    val name: String,
    val dosage: String,
    val type: MedicineType,
    val colorHex: Long,
    val photoUri: String?,
    val scheduledTime: String,
    val triggerMillis: Long,
    val status: DoseStatus,
    val minutesLate: Int,
    val minutesUntil: Int,
    val voiceAlertEnabled: Boolean,
    val maxShoutEnabled: Boolean,
    val soundStyle: SoundStyle,
    val snoozedUntilMillis: Long? = null
)

data class HistoryLogDisplay(
    val logId: Long,
    val medicineId: Long,
    val medicineName: String,
    val dosage: String,
    val scheduledTime: String,
    val timeTakenMillis: Long?,
    val status: String
)

data class AchievementBadge(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val unlocked: Boolean,
    val progressLabel: String
)

object PillPalette {
    val colors: List<Long> = listOf(
        0xFF8B5CF6, // Purple
        0xFFFF69B4, // Pink
        0xFFFF8C00, // Orange
        0xFF34C759, // Green
        0xFF00BFBF, // Teal
        0xFFFF3B30, // Coral Red
        0xFFFFCC00, // Sunny Yellow
        0xFF5E5CE6  // Indigo
    )
}
