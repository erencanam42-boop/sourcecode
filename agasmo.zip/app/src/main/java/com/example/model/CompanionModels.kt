package com.example.model

import androidx.annotation.DrawableRes
import com.example.R

enum class CompanionType(
    val id: String,
    val displayName: String,
    val speciesLabel: String,
    val colorHex: Long,
    val softBgHex: Long,
    val voiceStyle: String,
    val pitch: Float,
    val speechRate: Float,
    @param:DrawableRes val avatarRes: Int
) {
    LUMI(
        id = "LUMI",
        displayName = "Lumi",
        speciesLabel = "The Owl",
        colorHex = 0xFF8B5CF6,
        softBgHex = 0xFFF0E7FF,
        voiceStyle = "Makulit & Bubbly Owl",
        pitch = 1.42f,
        speechRate = 1.06f,
        avatarRes = R.drawable.img_companion_lumi
    ),
    BRAM(
        id = "BRAM",
        displayName = "Bram",
        speciesLabel = "The Bear",
        colorHex = 0xFF8B4513,
        softBgHex = 0xFFFFF1E6,
        voiceStyle = "Cuddly Gentle Bear",
        pitch = 0.78f,
        speechRate = 0.85f,
        avatarRes = R.drawable.img_companion_bram
    ),
    MIMI(
        id = "MIMI",
        displayName = "Mimi",
        speciesLabel = "The Cat",
        colorHex = 0xFFFF69B4,
        softBgHex = 0xFFFFE4E1,
        voiceStyle = "Super Cute Kitty",
        pitch = 1.56f,
        speechRate = 1.00f,
        avatarRes = R.drawable.img_companion_mimi
    ),
    KIKO(
        id = "KIKO",
        displayName = "Kiko",
        speciesLabel = "The Dog",
        colorHex = 0xFFFF8C00,
        softBgHex = 0xFFFFF3E0,
        voiceStyle = "Bouncy Hyper Pup",
        pitch = 1.28f,
        speechRate = 1.18f,
        avatarRes = R.drawable.img_companion_kiko
    ),
    TALA(
        id = "TALA",
        displayName = "Tala",
        speciesLabel = "The Fox",
        colorHex = 0xFF00BFBF,
        softBgHex = 0xFFE0F7FA,
        voiceStyle = "Chill & Cool Fox",
        pitch = 1.08f,
        speechRate = 0.94f,
        avatarRes = R.drawable.img_companion_tala
    );

    companion object {
        fun fromId(id: String?): CompanionType {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: LUMI
        }
    }
}

enum class CompanionMood {
    HAPPY,
    ANGRY,
    SLEEPY
}
