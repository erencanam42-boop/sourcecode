package com.example.model

import java.util.Locale

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeSubtitle: String,
    val flagEmoji: String,
    val sampleSentence: String,
    val ttsLanguageTag: String
) {
    TAGALOG(
        code = "TAGALOG",
        displayName = "Tagalog",
        nativeSubtitle = "Filipino (Default)",
        flagEmoji = "🇵🇭",
        sampleSentence = "Kamusta! Oras na para uminom ng gamot mo!",
        ttsLanguageTag = "fil-PH"
    ),
    ENGLISH(
        code = "ENGLISH",
        displayName = "English",
        nativeSubtitle = "International",
        flagEmoji = "🇺🇸",
        sampleSentence = "Hello! It is time to take your medicine now!",
        ttsLanguageTag = "en-US"
    ),
    TAGLISH(
        code = "TAGLISH",
        displayName = "Taglish",
        nativeSubtitle = "Mix Tagalog & English",
        flagEmoji = "✨",
        sampleSentence = "Kamusta! Time na para uminom ng meds mo, let's go!",
        ttsLanguageTag = "fil-PH"
    ),
    BISAYA(
        code = "BISAYA",
        displayName = "Bisaya / Cebuano",
        nativeSubtitle = "Visayas & Mindanao",
        flagEmoji = "🌴",
        sampleSentence = "Kumusta! Oras na sa pag-inom sa imong tambal!",
        ttsLanguageTag = "fil-PH"
    ),
    ILOCANO(
        code = "ILOCANO",
        displayName = "Ilocano",
        nativeSubtitle = "Bambang, Cagayan Valley",
        flagEmoji = "🌾",
        sampleSentence = "Kumusta ka! Oras mon nga uminom ti agas mo!",
        ttsLanguageTag = "fil-PH"
    );

    fun toTtsLocale(): Locale {
        return when (this) {
            ENGLISH -> Locale.US
            else -> Locale.Builder().setLanguage("fil").setRegion("PH").build()
        }
    }

    companion object {
        fun fromCode(code: String?): AppLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: TAGALOG
        }
    }
}
