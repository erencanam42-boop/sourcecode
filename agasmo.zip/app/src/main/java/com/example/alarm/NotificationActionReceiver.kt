package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.UserPrefsStore
import com.example.i18n.L10n
import com.example.model.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val medicineId = intent.getLongExtra(NotificationHelper.EXTRA_MEDICINE_ID, -1L)
        val medicineName = intent.getStringExtra(NotificationHelper.EXTRA_MEDICINE_NAME) ?: "Medicine"
        val dosage = intent.getStringExtra(NotificationHelper.EXTRA_DOSAGE) ?: ""
        val scheduledTime = intent.getStringExtra(NotificationHelper.EXTRA_SCHEDULED_TIME) ?: "08:00"
        val notifId = intent.getIntExtra(
            NotificationHelper.EXTRA_NOTIF_ID,
            NotificationHelper.notificationIdForDose(medicineId, scheduledTime)
        )
        if (medicineId <= 0L) return

        NotificationManagerCompat.from(context).cancel(notifId)
        CompanionVoicePlayer.getInstance(context).stop()

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AgasMoDatabase.getInstance(context)
                val repo = AgasMoRepository(db, UserPrefsStore(context))
                val scheduler = MedicineAlarmScheduler(context, repo)
                val profile = repo.getProfileOrDefault()
                val language = AppLanguage.fromCode(profile.selectedLanguage)
                val strings = L10n.strings(language)
                val med = repo.getMedicineById(medicineId)

                val toastMsg: String = when (action) {
                    ACTION_TAKE -> {
                        repo.markDoseTaken(medicineId, medicineName, dosage, scheduledTime)
                        scheduler.cancelMaxShoutForDose(medicineId, scheduledTime)
                        if (med != null) scheduler.scheduleNextDayAfterAction(med, scheduledTime)
                        strings.takenToast(medicineName)
                    }
                    ACTION_SNOOZE -> {
                        scheduler.cancelMaxShoutForDose(medicineId, scheduledTime)
                        scheduler.scheduleSnooze10m(medicineId, medicineName, dosage, scheduledTime)
                        strings.snoozedToast
                    }
                    ACTION_SKIP -> {
                        repo.markDoseSkipped(medicineId, medicineName, dosage, scheduledTime)
                        scheduler.cancelMaxShoutForDose(medicineId, scheduledTime)
                        if (med != null) scheduler.scheduleNextDayAfterAction(med, scheduledTime)
                        strings.skippedToast(medicineName)
                    }
                    else -> ""
                }

                if (toastMsg.isNotBlank()) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context.applicationContext, toastMsg, Toast.LENGTH_SHORT).show()
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_TAKE = "com.example.agasmo.ACTION_TAKE"
        const val ACTION_SNOOZE = "com.example.agasmo.ACTION_SNOOZE"
        const val ACTION_SKIP = "com.example.agasmo.ACTION_SKIP"
    }
}
