package com.example.alarm

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.UserPrefsStore
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.SoundStyle

class MedicineBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val medicineId = inputData.getLong(KEY_MEDICINE_ID, -1L)
        val scheduledTime = inputData.getString(KEY_SCHEDULED_TIME) ?: return Result.success()
        if (medicineId <= 0L) return Result.success()

        val db = AgasMoDatabase.getInstance(applicationContext)
        val repo = AgasMoRepository(db, UserPrefsStore(applicationContext))
        val med = repo.getMedicineById(medicineId) ?: return Result.success()
        if (!med.isActive) return Result.success()

        val today = AgasMoRepository.todayEpochDay()
        val existingLog = repo.getLogForDose(medicineId, scheduledTime, today)
        if (existingLog?.status == "TAKEN" || existingLog?.status == "SKIPPED") {
            return Result.success()
        }

        // Check if primary AlarmManager already notified for this dose recently
        val prefs = applicationContext.getSharedPreferences(PREFS_FIRED, Context.MODE_PRIVATE)
        val firedKey = "${medicineId}_${today}_${scheduledTime}"
        val lastFired = prefs.getLong(firedKey, 0L)
        if (System.currentTimeMillis() - lastFired < 5 * 60_000L) {
            return Result.success()
        }

        val profile = repo.getProfileOrDefault()
        if (!profile.notificationsEnabled) return Result.success()

        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val language = AppLanguage.fromCode(profile.selectedLanguage)
        val doseMillis = AgasMoRepository.epochDayAndTimeToMillis(today, scheduledTime)
        val minutesLate = ((System.currentTimeMillis() - doseMillis) / 60_000L).toInt().coerceAtLeast(0)
        val isMaxShout = med.maxShoutEnabled && minutesLate >= 30

        NotificationHelper.showCompanionReminderNotification(
            context = applicationContext,
            medicineId = med.id,
            medicineName = med.name,
            dosage = med.dosage,
            scheduledTime = scheduledTime,
            companion = companion,
            language = language,
            isMaxShout = isMaxShout,
            minutesLate = minutesLate,
            soundEnabled = profile.soundEnabled,
            vibrationEnabled = profile.vibrationEnabled
        )
        prefs.edit().putLong(firedKey, System.currentTimeMillis()).apply()

        if (profile.voiceAlertEnabled && med.voiceAlertEnabled) {
            val spoken = L10n.notificationBody(
                companion = companion,
                lang = language,
                medName = med.name,
                dosage = med.dosage,
                isMaxShout = isMaxShout,
                minutesLate = minutesLate
            )
            CompanionVoicePlayer.getInstance(applicationContext).speak(
                text = spoken,
                companion = companion,
                language = language,
                soundStyle = SoundStyle.fromCode(med.soundStyle),
                isMaxShout = isMaxShout,
                useAlarmStream = true
            )
        }

        return Result.success()
    }

    companion object {
        const val KEY_MEDICINE_ID = "medicine_id"
        const val KEY_SCHEDULED_TIME = "scheduled_time"
        const val PREFS_FIRED = "agasmo_fired_alarms"
    }
}
