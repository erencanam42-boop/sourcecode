package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.UserPrefsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            NotificationHelper.ensureChannels(context)
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AgasMoDatabase.getInstance(context)
                    val repo = AgasMoRepository(db, UserPrefsStore(context))
                    repo.ensureSeeded()
                    val scheduler = MedicineAlarmScheduler(context, repo)
                    scheduler.rescheduleAllActiveAlarms()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
