package com.example.alarm

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType

object NotificationHelper {

    const val CHANNEL_ID = "agasmo_reminder"
    const val CHANNEL_NAME = "AgasMo Medicine Reminder"
    const val CHANNEL_MAX_SHOUT_ID = "agasmo_max_shout"
    const val CHANNEL_MAX_SHOUT_NAME = "AgasMo MAX SHOUT Alerts"
    const val CHANNEL_VOICE_SERVICE_ID = "agasmo_voice_service"

    val VIBRATION_PATTERN = longArrayOf(0L, 500L, 200L, 500L)
    val SHOUT_VIBRATION_PATTERN = longArrayOf(0L, 600L, 150L, 600L, 150L, 600L)

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val notifSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: notifSound

        val reminderChannel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Loud medicine reminders from your AgasMo companion"
            enableVibration(true)
            vibrationPattern = VIBRATION_PATTERN
            setShowBadge(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            setSound(
                alarmSound,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        manager.createNotificationChannel(reminderChannel)

        val shoutChannel = NotificationChannel(
            CHANNEL_MAX_SHOUT_ID,
            CHANNEL_MAX_SHOUT_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Urgent MAX SHOUT medicine alerts when a dose is late"
            enableVibration(true)
            vibrationPattern = SHOUT_VIBRATION_PATTERN
            setShowBadge(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            setBypassDnd(true)
            setSound(
                alarmSound,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        manager.createNotificationChannel(shoutChannel)

        val voiceChannel = NotificationChannel(
            CHANNEL_VOICE_SERVICE_ID,
            "Companion Voice Playback",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Plays companion voice reminder audio"
            setShowBadge(false)
        }
        manager.createNotificationChannel(voiceChannel)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        val managerEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        if (!managerEnabled) return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun notificationIdForDose(medicineId: Long, scheduledTime: String): Int {
        return ((medicineId * 1000L + scheduledTime.hashCode().toLong()) and 0x7FFFFFFFL).toInt()
            .coerceAtLeast(100)
    }

    fun showCompanionReminderNotification(
        context: Context,
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        companion: CompanionType,
        language: AppLanguage,
        isMaxShout: Boolean,
        minutesLate: Int,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        ensureChannels(context)
        if (!hasNotificationPermission(context)) return

        val strings = L10n.strings(language)
        val title = L10n.notificationTitle(companion, isMaxShout, language)
        val body = L10n.notificationBody(
            companion = companion,
            lang = language,
            medName = medicineName,
            dosage = dosage,
            isMaxShout = isMaxShout,
            minutesLate = minutesLate
        )
        val notifId = notificationIdForDose(medicineId, scheduledTime)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val takeIntent = buildActionIntent(
            context = context,
            action = NotificationActionReceiver.ACTION_TAKE,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            notifId = notifId,
            companionId = companion.id,
            languageCode = language.code,
            requestOffset = 1
        )
        val snoozeIntent = buildActionIntent(
            context = context,
            action = NotificationActionReceiver.ACTION_SNOOZE,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            notifId = notifId,
            companionId = companion.id,
            languageCode = language.code,
            requestOffset = 2
        )
        val skipIntent = buildActionIntent(
            context = context,
            action = NotificationActionReceiver.ACTION_SKIP,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            notifId = notifId,
            companionId = companion.id,
            languageCode = language.code,
            requestOffset = 3
        )

        val avatarBitmap = try {
            BitmapFactory.decodeResource(context.resources, companion.avatarRes)
        } catch (_: Exception) {
            null
        }

        val channelId = if (isMaxShout) CHANNEL_MAX_SHOUT_ID else CHANNEL_ID
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(companion.colorHex.toInt())
            .setContentIntent(contentPendingIntent)
            .setAutoCancel(true)
            .addAction(0, strings.takeNow, takeIntent)
            .addAction(0, strings.snooze10m, snoozeIntent)
            .addAction(0, strings.skipBtn, skipIntent)

        if (avatarBitmap != null) {
            builder.setLargeIcon(avatarBitmap)
        }
        if (soundEnabled) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(soundUri)
        } else {
            builder.setSilent(true)
        }
        if (vibrationEnabled) {
            builder.setVibrate(if (isMaxShout) SHOUT_VIBRATION_PATTERN else VIBRATION_PATTERN)
        }

        try {
            NotificationManagerCompat.from(context).notify(notifId, builder.build())
        } catch (_: SecurityException) {
        }
    }

    private fun buildActionIntent(
        context: Context,
        action: String,
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        notifId: Int,
        companionId: String,
        languageCode: String,
        requestOffset: Int
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_MEDICINE_ID, medicineId)
            putExtra(EXTRA_MEDICINE_NAME, medicineName)
            putExtra(EXTRA_DOSAGE, dosage)
            putExtra(EXTRA_SCHEDULED_TIME, scheduledTime)
            putExtra(EXTRA_NOTIF_ID, notifId)
            putExtra(EXTRA_COMPANION_ID, companionId)
            putExtra(EXTRA_LANGUAGE_CODE, languageCode)
        }
        val reqCode = ((notifId * 10 + requestOffset) and 0x7FFFFFFF)
        return PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    const val EXTRA_MEDICINE_ID = "extra_medicine_id"
    const val EXTRA_MEDICINE_NAME = "extra_medicine_name"
    const val EXTRA_DOSAGE = "extra_dosage"
    const val EXTRA_SCHEDULED_TIME = "extra_scheduled_time"
    const val EXTRA_NOTIF_ID = "extra_notif_id"
    const val EXTRA_COMPANION_ID = "extra_companion_id"
    const val EXTRA_LANGUAGE_CODE = "extra_language_code"
    const val EXTRA_IS_MAX_SHOUT = "extra_is_max_shout"
    const val EXTRA_IS_SNOOZE = "extra_is_snooze"
}
