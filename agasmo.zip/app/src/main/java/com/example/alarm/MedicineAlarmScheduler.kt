package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.AgasMoRepository
import com.example.data.MedicineEntity
import com.example.data.ScheduledAlarmEntity
import com.example.model.AppLanguage
import com.example.model.CompanionType
import java.util.concurrent.TimeUnit

class MedicineAlarmScheduler(
    private val context: Context,
    private val repository: AgasMoRepository
) {
    private val alarmManager: AlarmManager? =
        context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    suspend fun scheduleMedicine(medicine: MedicineEntity) {
        cancelMedicineAlarms(medicine.id)
        if (!medicine.isActive) return

        val profile = repository.getProfileOrDefault()
        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val language = AppLanguage.fromCode(profile.selectedLanguage)

        val times = medicine.timesCsv.split(",")
            .map { it.trim() }
            .filter { it.contains(":") }

        for (timeStr in times) {
            val triggerAt = computeNextTriggerMillis(medicine, timeStr) ?: continue
            val reqCode = requestCodeFor(medicine.id, timeStr, isMaxShout = false)

            scheduleExactAlarmInternal(
                requestCode = reqCode,
                medicineId = medicine.id,
                medicineName = medicine.name,
                dosage = medicine.dosage,
                timeStr = timeStr,
                companionId = companion.id,
                languageCode = language.code,
                triggerAtMillis = triggerAt,
                isMaxShout = false,
                isSnooze = false
            )

            repository.saveScheduledAlarm(
                ScheduledAlarmEntity(
                    requestCode = reqCode,
                    medicineId = medicine.id,
                    timeStr = timeStr,
                    companionId = companion.id,
                    language = language.code,
                    isActive = true,
                    triggerAtMillis = triggerAt,
                    isMaxShout = false
                )
            )

            scheduleWorkManagerBackup(medicine.id, timeStr, triggerAt)
        }
    }

    suspend fun scheduleNextDayAfterAction(medicine: MedicineEntity, timeStr: String) {
        val profile = repository.getProfileOrDefault()
        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val language = AppLanguage.fromCode(profile.selectedLanguage)
        val tomorrowStart = AgasMoRepository.todayEpochDay() + 1L
        val nextTrigger = computeNextTriggerMillisFromDay(medicine, timeStr, tomorrowStart) ?: return
        val reqCode = requestCodeFor(medicine.id, timeStr, isMaxShout = false)

        scheduleExactAlarmInternal(
            requestCode = reqCode,
            medicineId = medicine.id,
            medicineName = medicine.name,
            dosage = medicine.dosage,
            timeStr = timeStr,
            companionId = companion.id,
            languageCode = language.code,
            triggerAtMillis = nextTrigger,
            isMaxShout = false,
            isSnooze = false
        )

        repository.saveScheduledAlarm(
            ScheduledAlarmEntity(
                requestCode = reqCode,
                medicineId = medicine.id,
                timeStr = timeStr,
                companionId = companion.id,
                language = language.code,
                isActive = true,
                triggerAtMillis = nextTrigger,
                isMaxShout = false
            )
        )
        scheduleWorkManagerBackup(medicine.id, timeStr, nextTrigger)
    }

    suspend fun scheduleSnooze10m(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String
    ) {
        val profile = repository.getProfileOrDefault()
        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val language = AppLanguage.fromCode(profile.selectedLanguage)
        val snoozeTrigger = System.currentTimeMillis() + 10 * 60_000L
        val reqCode = requestCodeFor(medicineId, scheduledTime, isMaxShout = false)

        scheduleExactAlarmInternal(
            requestCode = reqCode,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            timeStr = scheduledTime,
            companionId = companion.id,
            languageCode = language.code,
            triggerAtMillis = snoozeTrigger,
            isMaxShout = false,
            isSnooze = true
        )

        repository.markDoseSnoozed(
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            scheduledTime = scheduledTime,
            snoozedUntilMillis = snoozeTrigger
        )
        repository.saveScheduledAlarm(
            ScheduledAlarmEntity(
                requestCode = reqCode,
                medicineId = medicineId,
                timeStr = scheduledTime,
                companionId = companion.id,
                language = language.code,
                isActive = true,
                triggerAtMillis = snoozeTrigger,
                isMaxShout = false
            )
        )
        scheduleWorkManagerBackup(medicineId, scheduledTime, snoozeTrigger)
    }

    suspend fun scheduleMaxShoutFollowUp(
        medicineId: Long,
        medicineName: String,
        dosage: String,
        scheduledTime: String,
        delayMinutes: Int
    ) {
        val profile = repository.getProfileOrDefault()
        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val language = AppLanguage.fromCode(profile.selectedLanguage)
        val triggerAt = System.currentTimeMillis() + delayMinutes * 60_000L
        val reqCode = requestCodeFor(medicineId, scheduledTime, isMaxShout = true)

        scheduleExactAlarmInternal(
            requestCode = reqCode,
            medicineId = medicineId,
            medicineName = medicineName,
            dosage = dosage,
            timeStr = scheduledTime,
            companionId = companion.id,
            languageCode = language.code,
            triggerAtMillis = triggerAt,
            isMaxShout = true,
            isSnooze = false
        )

        repository.saveScheduledAlarm(
            ScheduledAlarmEntity(
                requestCode = reqCode,
                medicineId = medicineId,
                timeStr = scheduledTime,
                companionId = companion.id,
                language = language.code,
                isActive = true,
                triggerAtMillis = triggerAt,
                isMaxShout = true
            )
        )
    }

    fun cancelMaxShoutForDose(medicineId: Long, scheduledTime: String) {
        val reqCode = requestCodeFor(medicineId, scheduledTime, isMaxShout = true)
        cancelPendingIntent(reqCode)
        WorkManager.getInstance(context).cancelUniqueWork(backupWorkName(medicineId, scheduledTime))
    }

    suspend fun cancelMedicineAlarms(medicineId: Long) {
        val existing = repository.getAlarmsForMedicine(medicineId)
        for (alarm in existing) {
            cancelPendingIntent(alarm.requestCode)
            WorkManager.getInstance(context).cancelUniqueWork(backupWorkName(medicineId, alarm.timeStr))
        }
        val med = repository.getMedicineById(medicineId)
        if (med != null) {
            val times = med.timesCsv.split(",").map { it.trim() }.filter { it.contains(":") }
            for (t in times) {
                cancelPendingIntent(requestCodeFor(medicineId, t, isMaxShout = false))
                cancelPendingIntent(requestCodeFor(medicineId, t, isMaxShout = true))
                WorkManager.getInstance(context).cancelUniqueWork(backupWorkName(medicineId, t))
            }
        }
        repository.deleteAlarmsForMedicine(medicineId)
    }

    suspend fun rescheduleAllActiveAlarms() {
        val oldAlarms = repository.getAllActiveAlarms()
        for (alarm in oldAlarms) {
            cancelPendingIntent(alarm.requestCode)
            WorkManager.getInstance(context).cancelUniqueWork(backupWorkName(alarm.medicineId, alarm.timeStr))
        }
        repository.deleteAllScheduledAlarms()

        val activeMeds = repository.getActiveMedicinesSync()
        for (med in activeMeds) {
            scheduleMedicine(med)
        }
    }

    private fun scheduleExactAlarmInternal(
        requestCode: Int,
        medicineId: Long,
        medicineName: String,
        dosage: String,
        timeStr: String,
        companionId: String,
        languageCode: String,
        triggerAtMillis: Long,
        isMaxShout: Boolean,
        isSnooze: Boolean
    ) {
        val am = alarmManager ?: return
        val intent = Intent(context, MedicineAlarmReceiver::class.java).apply {
            putExtra(NotificationHelper.EXTRA_MEDICINE_ID, medicineId)
            putExtra(NotificationHelper.EXTRA_MEDICINE_NAME, medicineName)
            putExtra(NotificationHelper.EXTRA_DOSAGE, dosage)
            putExtra(NotificationHelper.EXTRA_SCHEDULED_TIME, timeStr)
            putExtra(NotificationHelper.EXTRA_COMPANION_ID, companionId)
            putExtra(NotificationHelper.EXTRA_LANGUAGE_CODE, languageCode)
            putExtra(NotificationHelper.EXTRA_IS_MAX_SHOUT, isMaxShout)
            putExtra(NotificationHelper.EXTRA_IS_SNOOZE, isSnooze)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val safeTrigger = triggerAtMillis.coerceAtLeast(System.currentTimeMillis() + 1_000L)

        try {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                am.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pendingIntent)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pendingIntent)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pendingIntent)
        }
    }

    private fun cancelPendingIntent(requestCode: Int) {
        val am = alarmManager ?: return
        val intent = Intent(context, MedicineAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            am.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    private fun scheduleWorkManagerBackup(medicineId: Long, timeStr: String, triggerAtMillis: Long) {
        val delayMillis = ((triggerAtMillis - System.currentTimeMillis()) + 2 * 60_000L)
            .coerceAtLeast(60_000L)
        val data = Data.Builder()
            .putLong(MedicineBackupWorker.KEY_MEDICINE_ID, medicineId)
            .putString(MedicineBackupWorker.KEY_SCHEDULED_TIME, timeStr)
            .build()
        val request = OneTimeWorkRequestBuilder<MedicineBackupWorker>()
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            backupWorkName(medicineId, timeStr),
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    private fun computeNextTriggerMillis(med: MedicineEntity, timeStr: String): Long? {
        return computeNextTriggerMillisFromDay(med, timeStr, AgasMoRepository.todayEpochDay())
    }

    private fun computeNextTriggerMillisFromDay(
        med: MedicineEntity,
        timeStr: String,
        startSearchDay: Long
    ): Long? {
        val now = System.currentTimeMillis()
        for (offset in 0..14) {
            val day = startSearchDay + offset
            if (!AgasMoRepository.isMedicineScheduledOnDay(med, day)) continue
            val doseMillis = AgasMoRepository.epochDayAndTimeToMillis(day, timeStr)
            val remindMillis = doseMillis - (med.reminderOffsetMinutes * 60_000L)
            if (remindMillis > now - 5_000L) {
                return remindMillis.coerceAtLeast(now + 1_500L)
            }
        }
        return null
    }

    companion object {
        fun requestCodeFor(medicineId: Long, timeStr: String, isMaxShout: Boolean): Int {
            val parts = timeStr.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
            val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val minsOfDay = hour * 60 + minute
            val base = (medicineId.toInt() * 1500) + minsOfDay + if (isMaxShout) 700_000 else 0
            return (base and 0x7FFFFFFF).coerceAtLeast(1)
        }

        private fun backupWorkName(medicineId: Long, timeStr: String): String {
            return "backup_alarm_${medicineId}_${timeStr.replace(":", "_")}"
        }
    }
}
