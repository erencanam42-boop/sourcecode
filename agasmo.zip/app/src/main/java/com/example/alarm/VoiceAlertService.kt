package com.example.alarm

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.SoundStyle

class VoiceAlertService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val timeoutRunnable = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannels(this)
        val notification = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_VOICE_SERVICE_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("AgasMo")
            .setContentText("Companion voice reminder...")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    SERVICE_NOTIF_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(SERVICE_NOTIF_ID, notification)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val text = intent?.getStringExtra(EXTRA_VOICE_TEXT).orEmpty()
        val companion = CompanionType.fromId(intent?.getStringExtra(EXTRA_COMPANION_ID))
        val language = AppLanguage.fromCode(intent?.getStringExtra(EXTRA_LANGUAGE_CODE))
        val soundStyle = SoundStyle.fromCode(intent?.getStringExtra(EXTRA_SOUND_STYLE))
        val isMaxShout = intent?.getBooleanExtra(EXTRA_IS_MAX_SHOUT, false) ?: false

        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, 15_000L)

        if (text.isNotBlank()) {
            CompanionVoicePlayer.getInstance(this).speak(
                text = text,
                companion = companion,
                language = language,
                soundStyle = soundStyle,
                isMaxShout = isMaxShout,
                useAlarmStream = true,
                onDone = {
                    handler.post { stopSelf() }
                }
            )
        } else {
            stopSelf()
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeoutRunnable)
        super.onDestroy()
    }

    companion object {
        private const val SERVICE_NOTIF_ID = 9901
        const val EXTRA_VOICE_TEXT = "extra_voice_text"
        const val EXTRA_COMPANION_ID = "extra_companion_id"
        const val EXTRA_LANGUAGE_CODE = "extra_language_code"
        const val EXTRA_SOUND_STYLE = "extra_sound_style"
        const val EXTRA_IS_MAX_SHOUT = "extra_is_max_shout"
    }
}
