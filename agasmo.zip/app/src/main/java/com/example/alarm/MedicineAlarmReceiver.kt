package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.UserPrefsStore
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.SoundStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MedicineAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val medicineId = intent.getLongExtra(NotificationHelper.EXTRA_MEDICINE_ID, -1L)
        val fallbackName = intent.getStringExtra(NotificationHelper.EXTRA_MEDICINE_NAME) ?: "Medicine"
        val fallbackDosage = intent.getStringExtra(NotificationHelper.EXTRA_DOSAGE) ?: ""
        val scheduledTime = intent.getStringExtra(NotificationHelper.EXTRA_SCHEDULED_TIME) ?: "08:00"
        val extraCompanionId = intent.getStringExtra(NotificationHelper.EXTRA_COMPANION_ID)
        val extraLanguageCode = intent.getStringExtra(NotificationHelper.EXTRA_LANGUAGE_CODE)
        val isMaxShoutTrigger = intent.getBooleanExtra(NotificationHelper.EXTRA_IS_MAX_SHOUT, false)

        if (medicineId <= 0L) return

        NotificationHelper.ensureChannels(context)
        val pendingResult = goAsync()
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = try {
            powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "AgasMo:AlarmWakeLock"
            )?.apply { acquire(12_000L) }
        } catch (_: Exception) {
            null
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AgasMoDatabase.getInstance(context)
                val repo = AgasMoRepository(db, UserPrefsStore(context))
                val scheduler = MedicineAlarmScheduler(context, repo)

                val med = repo.getMedicineById(medicineId)
                if (med != null && !med.isActive) return@launch

                val today = AgasMoRepository.todayEpochDay()
                val existingLog = repo.getLogForDose(medicineId, scheduledTime, today)
                if (existingLog?.status == "TAKEN" || existingLog?.status == "SKIPPED") {
                    if (!isMaxShoutTrigger && med != null) {
                        scheduler.scheduleNextDayAfterAction(med, scheduledTime)
                    }
                    return@launch
                }

                val profile = repo.getProfileOrDefault()
                val companion = CompanionType.fromId(profile.selectedCompanionId.ifBlank { extraCompanionId })
                val language = AppLanguage.fromCode(profile.selectedLanguage.ifBlank { extraLanguageCode })

                val medName = med?.name ?: fallbackName
                val dosage = med?.dosage ?: fallbackDosage
                val soundStyle = SoundStyle.fromCode(med?.soundStyle)
                val maxShoutEnabled = med?.maxShoutEnabled ?: true
                val voiceEnabled = profile.voiceAlertEnabled && (med?.voiceAlertEnabled ?: true)

                val doseMillis = AgasMoRepository.epochDayAndTimeToMillis(today, scheduledTime)
                val minutesLate = ((System.currentTimeMillis() - doseMillis) / 60_000L).toInt().coerceAtLeast(0)
                val useMaxShout = isMaxShoutTrigger || soundStyle == SoundStyle.MAX_SHOUT

                if (profile.notificationsEnabled) {
                    NotificationHelper.showCompanionReminderNotification(
                        context = context,
                        medicineId = medicineId,
                        medicineName = medName,
                        dosage = dosage,
                        scheduledTime = scheduledTime,
                        companion = companion,
                        language = language,
                        isMaxShout = useMaxShout,
                        minutesLate = minutesLate,
                        soundEnabled = profile.soundEnabled,
                        vibrationEnabled = profile.vibrationEnabled
                    )
                }

                val prefs = context.getSharedPreferences(MedicineBackupWorker.PREFS_FIRED, Context.MODE_PRIVATE)
                prefs.edit().putLong("${medicineId}_${today}_${scheduledTime}", System.currentTimeMillis()).apply()

                if (voiceEnabled && profile.notificationsEnabled) {
                    val spoken = L10n.notificationBody(
                        companion = companion,
                        lang = language,
                        medName = medName,
                        dosage = dosage,
                        isMaxShout = useMaxShout,
                        minutesLate = minutesLate
                    )
                    triggerVoiceAlert(
                        context = context,
                        spokenText = spoken,
                        companion = companion,
                        language = language,
                        soundStyle = soundStyle,
                        isMaxShout = useMaxShout
                    )
                }

                if (maxShoutEnabled) {
                    val nextShoutDelay = if (isMaxShoutTrigger) 10 else 30
                    scheduler.scheduleMaxShoutFollowUp(
                        medicineId = medicineId,
                        medicineName = medName,
                        dosage = dosage,
                        scheduledTime = scheduledTime,
                        delayMinutes = nextShoutDelay
                    )
                }

                if (!isMaxShoutTrigger && med != null) {
                    scheduler.scheduleNextDayAfterAction(med, scheduledTime)
                }
            } finally {
                try {
                    if (wakeLock?.isHeld == true) wakeLock.release()
                } catch (_: Exception) {
                }
                pendingResult.finish()
            }
        }
    }

    private fun triggerVoiceAlert(
        context: Context,
        spokenText: String,
        companion: CompanionType,
        language: AppLanguage,
        soundStyle: SoundStyle,
        isMaxShout: Boolean
    ) {
        val serviceIntent = Intent(context, VoiceAlertService::class.java).apply {
            putExtra(VoiceAlertService.EXTRA_VOICE_TEXT, spokenText)
            putExtra(VoiceAlertService.EXTRA_COMPANION_ID, companion.id)
            putExtra(VoiceAlertService.EXTRA_LANGUAGE_CODE, language.code)
            putExtra(VoiceAlertService.EXTRA_SOUND_STYLE, soundStyle.code)
            putExtra(VoiceAlertService.EXTRA_IS_MAX_SHOUT, isMaxShout)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            CompanionVoicePlayer.getInstance(context).speak(
                text = spokenText,
                companion = companion,
                language = language,
                soundStyle = soundStyle,
                isMaxShout = isMaxShout,
                useAlarmStream = true
            )
        }
    }
}
