package com.example.alarm

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.SoundStyle
import java.util.Locale
import java.util.UUID

class CompanionVoicePlayer private constructor(private val appContext: Context) {

    private var tts: TextToSpeech? = null
    private var isReady: Boolean = false
    private var pendingRequest: PendingSpeech? = null
    private val listeners = mutableMapOf<String, () -> Unit>()

    private data class PendingSpeech(
        val text: String,
        val companion: CompanionType,
        val language: AppLanguage,
        val soundStyle: SoundStyle,
        val isMaxShout: Boolean,
        val useAlarmStream: Boolean,
        val onDone: (() -> Unit)?
    )

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isReady = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            utteranceId?.let { id -> listeners.remove(id)?.invoke() }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            utteranceId?.let { id -> listeners.remove(id)?.invoke() }
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            utteranceId?.let { id -> listeners.remove(id)?.invoke() }
                        }
                    })
                    pendingRequest?.let { req ->
                        pendingRequest = null
                        executeSpeak(req)
                    }
                } else {
                    isReady = false
                    pendingRequest?.onDone?.invoke()
                    pendingRequest = null
                }
            }
        } catch (_: Exception) {
            isReady = false
        }
    }

    fun speak(
        text: String,
        companion: CompanionType,
        language: AppLanguage,
        soundStyle: SoundStyle = SoundStyle.NORMAL,
        isMaxShout: Boolean = false,
        useAlarmStream: Boolean = false,
        onDone: (() -> Unit)? = null
    ) {
        val req = PendingSpeech(
            text = text,
            companion = companion,
            language = language,
            soundStyle = soundStyle,
            isMaxShout = isMaxShout,
            useAlarmStream = useAlarmStream,
            onDone = onDone
        )
        if (!isReady || tts == null) {
            pendingRequest = req
            if (tts == null) initTts()
            return
        }
        executeSpeak(req)
    }

    private fun executeSpeak(req: PendingSpeech) {
        val engine = tts ?: run {
            req.onDone?.invoke()
            return
        }
        try {
            val desiredLocale = req.language.toTtsLocale()
            val langResult = engine.setLanguage(desiredLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                val filResult = engine.setLanguage(Locale.Builder().setLanguage("fil").setRegion("PH").build())
                if (filResult == TextToSpeech.LANG_MISSING_DATA || filResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.US)
                }
            }

            selectCharacterVoice(engine, req.companion, desiredLocale)

            val pitchBoost = when {
                req.isMaxShout || req.soundStyle == SoundStyle.MAX_SHOUT -> 1.12f
                req.soundStyle == SoundStyle.SWEET -> 1.07f
                else -> 1.0f
            }
            val rateBoost = when {
                req.isMaxShout || req.soundStyle == SoundStyle.MAX_SHOUT -> 1.08f
                req.soundStyle == SoundStyle.SWEET -> 0.93f
                else -> 1.0f
            }
            engine.setPitch((req.companion.pitch * pitchBoost).coerceIn(0.65f, 1.85f))
            engine.setSpeechRate((req.companion.speechRate * rateBoost).coerceIn(0.65f, 1.55f))

            val usage = if (req.useAlarmStream) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_MEDIA
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )

            val utteranceId = UUID.randomUUID().toString()
            if (req.onDone != null) {
                listeners[utteranceId] = req.onDone
            }
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            }
            val expressiveText = formatExpressiveText(req.text, req.companion)
            engine.speak(expressiveText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } catch (_: Exception) {
            req.onDone?.invoke()
        }
    }

    private fun selectCharacterVoice(
        engine: TextToSpeech,
        companion: CompanionType,
        locale: Locale
    ) {
        runCatching {
            val available: Set<Voice> = engine.voices ?: return
            val matching = available.filter { v ->
                !v.isNetworkConnectionRequired &&
                    v.locale != null &&
                    v.locale.language.equals(locale.language, ignoreCase = true)
            }
            if (matching.isEmpty()) return

            // Pick a distinct offline voice when multiple local voices exist on the device
            val sorted = matching.sortedBy { it.name }
            val picked = when (companion) {
                CompanionType.MIMI -> sorted.firstOrNull { it.name.contains("f", ignoreCase = true) } ?: sorted.first()
                CompanionType.LUMI -> sorted.getOrElse(1) { sorted.first() }
                CompanionType.BRAM -> sorted.lastOrNull { it.name.contains("m", ignoreCase = true) } ?: sorted.last()
                CompanionType.KIKO -> sorted.getOrElse(2) { sorted.first() }
                CompanionType.TALA -> sorted.getOrElse(3) { sorted.last() }
            }
            engine.voice = picked
        }
    }

    private fun formatExpressiveText(raw: String, companion: CompanionType): String {
        val cleaned = raw.replace("~", ", ").replace("—", ", ")
        return when (companion) {
            CompanionType.MIMI -> cleaned.replace("!", "! ")
            CompanionType.BRAM -> cleaned.replace(".", "... ")
            else -> cleaned
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: CompanionVoicePlayer? = null

        fun getInstance(context: Context): CompanionVoicePlayer {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CompanionVoicePlayer(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
