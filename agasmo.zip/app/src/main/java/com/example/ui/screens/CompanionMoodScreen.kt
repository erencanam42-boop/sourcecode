package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.L10n
import com.example.model.CompanionMood
import com.example.ui.AgasMoUiState
import com.example.ui.components.AgasMoCard
import com.example.ui.components.CompanionAvatar
import com.example.ui.theme.LocalAgasMoColors

@Composable
fun CompanionMoodScreen(
    uiState: AgasMoUiState,
    onPlayMoodVoice: (CompanionMood) -> Unit,
    onPlayMaxShout: () -> Unit
) {
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current
    val accent = Color(uiState.companion.colorHex)

    val infiniteTransition = rememberInfiniteTransition(label = "companion_anim")
    val breatheScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    )
    val shakeRotation by infiniteTransition.animateFloat(
        initialValue = if (uiState.companionMood == CompanionMood.ANGRY) -4f else -1f,
        targetValue = if (uiState.companionMood == CompanionMood.ANGRY) 4f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (uiState.companionMood == CompanionMood.ANGRY) 240 else 1500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tilt"
    )

    val moodLabel = when (uiState.companionMood) {
        CompanionMood.HAPPY -> strings.moodHappyLabel
        CompanionMood.ANGRY -> strings.moodAngryLabel
        CompanionMood.SLEEPY -> strings.moodSleepyLabel
    }
    val speechText = L10n.companionMoodMessage(
        companion = uiState.companion,
        mood = uiState.companionMood,
        lang = uiState.language,
        minutesLate = uiState.maxLateMinutesToday
    )

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = strings.companionScreenTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ext.primaryText
                )
            }

            item {
                AgasMoCard(
                    borderColor = if (uiState.companionMood == CompanionMood.ANGRY) ext.lateRed else accent
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CompanionAvatar(
                            companion = uiState.companion,
                            size = 164.dp,
                            mood = uiState.companionMood,
                            modifier = Modifier
                                .scale(breatheScale)
                                .graphicsLayer { rotationZ = shakeRotation }
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "${uiState.companion.displayName} ${uiState.companion.speciesLabel}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ext.primaryText
                        )
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (uiState.companionMood == CompanionMood.ANGRY) ext.lateRed.copy(alpha = 0.14f)
                            else accent.copy(alpha = 0.14f),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Text(
                                text = moodLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (uiState.companionMood == CompanionMood.ANGRY) ext.lateRed else accent,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "\"$speechText\"",
                                style = MaterialTheme.typography.titleMedium,
                                color = ext.primaryText,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { onPlayMoodVoice(uiState.companionMood) },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accent),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("companion_play_voice_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = strings.playVoiceBtn)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.playVoiceBtn, color = Color.White)
                            }
                            OutlinedButton(
                                onClick = onPlayMaxShout,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("companion_max_shout_button")
                            ) {
                                Icon(Icons.Filled.Campaign, contentDescription = strings.hearShoutBtn)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MAX SHOUT!")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = strings.badgesTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = ext.primaryText
                )
            }

            items(uiState.badges, key = { it.id }) { badge ->
                AgasMoCard(
                    containerColor = if (badge.unlocked) MaterialTheme.colorScheme.surface
                    else MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = badge.emoji, fontSize = 36.sp)
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = badge.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = ext.primaryText
                            )
                            Text(
                                text = badge.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.secondaryText
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (badge.unlocked) ext.takenGreen else ext.cardBorder.copy(alpha = 0.45f)
                        ) {
                            Text(
                                text = badge.progressLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (badge.unlocked) Color.White else ext.primaryText,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
