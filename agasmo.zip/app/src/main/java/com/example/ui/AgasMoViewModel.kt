package com.example.ui

import android.app.Application
import android.content.Context
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AgasMoApp
import com.example.alarm.CompanionVoicePlayer
import com.example.alarm.MedicineAlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.data.AgasMoRepository
import com.example.data.MedicineEntity
import com.example.data.MedicineLogEntity
import com.example.data.UserProfileEntity
import com.example.i18n.L10n
import com.example.model.AchievementBadge
import com.example.model.AppLanguage
import com.example.model.CompanionMood
import com.example.model.CompanionType
import com.example.model.DoseStatus
import com.example.model.HistoryLogDisplay
import com.example.model.ThemeMode
import com.example.model.TodayDoseItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AgasMoUiState(
    val isLoading: Boolean = true,
    val profile: UserProfileEntity = UserProfileEntity(),
    val language: AppLanguage = AppLanguage.TAGALOG,
    val companion: CompanionType = CompanionType.LUMI,
    val themeMode: ThemeMode = ThemeMode.PINK,
    val onboardingStep: Int = 0, // 0 = language, 1 = companion
    val todayDoses: List<TodayDoseItem> = emptyList(),
    val allMedicines: List<MedicineEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedCalendarDay: Long = AgasMoRepository.todayEpochDay(),
    val selectedDayLogs: List<HistoryLogDisplay> = emptyList(),
    val daysWithTakenLogs: Set<Long> = emptySet(),
    val daysWithLateOrMissed: Set<Long> = emptySet(),
    val streakDays: Int = 0,
    val weeklyAdherencePercent: Int = 0,
    val companionMood: CompanionMood = CompanionMood.HAPPY,
    val maxLateMinutesToday: Int = 0,
    val badges: List<AchievementBadge> = emptyList(),
    val systemNotificationsAllowed: Boolean = true,
    val isBatteryOptimizationIgnored: Boolean = true
)

class AgasMoViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AgasMoApp
    private val repository = app.repository
    private val scheduler = MedicineAlarmScheduler(application, repository)
    private val voicePlayer = CompanionVoicePlayer.getInstance(application)

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCalendarDay = MutableStateFlow(AgasMoRepository.todayEpochDay())
    private val _onboardingStep = MutableStateFlow(0)
    private val _systemNotifAllowed = MutableStateFlow(NotificationHelper.hasNotificationPermission(application))
    private val _batteryIgnored = MutableStateFlow(checkBatteryIgnored(application))

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastEvents: SharedFlow<String> = _toastEvents.asSharedFlow()

    private val tickerFlow = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(30_000L)
        }
    }

    private val baseDataFlow = combine(
        repository.userProfile,
        repository.activeMedicines,
        repository.allLogs,
        tickerFlow
    ) { profile, meds, logs, now ->
        QuadData(profile ?: UserProfileEntity(), meds, logs, now)
    }

    private val uiInputsFlow = combine(
        _searchQuery,
        _selectedCalendarDay,
        _onboardingStep,
        _systemNotifAllowed,
        _batteryIgnored
    ) { query, calDay, step, notifOk, battOk ->
        UiInputs(query, calDay, step, notifOk, battOk)
    }

    val uiState: StateFlow<AgasMoUiState> = combine(baseDataFlow, uiInputsFlow) { data, inputs ->
        val profile = data.profile
        val language = AppLanguage.fromCode(profile.selectedLanguage)
        val companion = CompanionType.fromId(profile.selectedCompanionId)
        val themeMode = ThemeMode.fromCode(profile.themeMode)
        val today = AgasMoRepository.todayEpochDay()

        val allTodayDoses = repository.buildDosesForDay(
            medicines = data.medicines,
            logs = data.logs,
            epochDay = today,
            nowMillis = data.nowMillis
        )
        val filteredDoses = if (inputs.searchQuery.isBlank()) {
            allTodayDoses
        } else {
            allTodayDoses.filter {
                it.name.contains(inputs.searchQuery.trim(), ignoreCase = true) ||
                    it.dosage.contains(inputs.searchQuery.trim(), ignoreCase = true)
            }
        }

        val hasLate = allTodayDoses.any { it.status == DoseStatus.LATE }
        val allDone = allTodayDoses.isNotEmpty() && allTodayDoses.all {
            it.status == DoseStatus.TAKEN || it.status == DoseStatus.SKIPPED
        }
        val mood = when {
            hasLate -> CompanionMood.ANGRY
            allDone -> CompanionMood.SLEEPY
            else -> CompanionMood.HAPPY
        }
        val maxLate = allTodayDoses.maxOfOrNull { it.minutesLate } ?: 0

        val dayLogs = data.logs.filter { it.dateEpochDay == inputs.calDay }.map { log ->
            HistoryLogDisplay(
                logId = log.id,
                medicineId = log.medicineId,
                medicineName = log.medicineName,
                dosage = log.dosage,
                scheduledTime = log.scheduledTime,
                timeTakenMillis = log.timeTakenMillis,
                status = log.status
            )
        }
        val takenDays = data.logs.filter { it.status == "TAKEN" }.map { it.dateEpochDay }.toSet()
        val skippedDays = data.logs.filter { it.status == "SKIPPED" }.map { it.dateEpochDay }.toSet()
        val streak = repository.computeStreakDays(data.logs, today)
        val adherence = repository.computeWeeklyAdherencePercent(data.medicines, data.logs, today)

        val strings = L10n.strings(language)
        val takenCountTotal = data.logs.count { it.status == "TAKEN" }
        val badges = listOf(
            AchievementBadge(
                id = "on_time_king",
                title = strings.badgeOnTimeTitle,
                description = strings.badgeOnTimeDesc,
                emoji = "👑",
                unlocked = takenCountTotal >= 5,
                progressLabel = "${takenCountTotal.coerceAtMost(5)}/5"
            ),
            AchievementBadge(
                id = "streak_7",
                title = strings.badgeStreakTitle,
                description = strings.badgeStreakDesc,
                emoji = "🔥",
                unlocked = streak >= 7,
                progressLabel = "${streak.coerceAtMost(7)}/7"
            ),
            AchievementBadge(
                id = "best_friend",
                title = strings.badgeFriendTitle(companion.displayName),
                description = strings.badgeFriendDesc(companion.displayName),
                emoji = "💜",
                unlocked = takenCountTotal >= 1,
                progressLabel = if (takenCountTotal >= 1) strings.unlockedLabel else "0/1"
            )
        )

        AgasMoUiState(
            isLoading = false,
            profile = profile,
            language = language,
            companion = companion,
            themeMode = themeMode,
            onboardingStep = inputs.onboardingStep,
            todayDoses = filteredDoses,
            allMedicines = data.medicines,
            searchQuery = inputs.searchQuery,
            selectedCalendarDay = inputs.calDay,
            selectedDayLogs = dayLogs,
            daysWithTakenLogs = takenDays,
            daysWithLateOrMissed = skippedDays,
            streakDays = streak,
            weeklyAdherencePercent = adherence,
            companionMood = mood,
            maxLateMinutesToday = maxLate,
            badges = badges,
            systemNotificationsAllowed = inputs.systemNotifAllowed,
            isBatteryOptimizationIgnored = inputs.batteryIgnored
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = AgasMoUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    fun refreshSystemChecks() {
        _systemNotifAllowed.value = NotificationHelper.hasNotificationPermission(app)
        _batteryIgnored.value = checkBatteryIgnored(app)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCalendarDay(epochDay: Long) {
        _selectedCalendarDay.value = epochDay
    }

    fun setOnboardingStep(step: Int) {
        _onboardingStep.value = step
    }

    fun selectLanguage(language: AppLanguage, showToast: Boolean = true) {
        viewModelScope.launch {
            repository.updateLanguage(language)
            scheduler.rescheduleAllActiveAlarms()
            if (showToast) {
                _toastEvents.emit(L10n.strings(language).languageChangedToast)
            }
        }
    }

    fun selectCompanion(companion: CompanionType) {
        viewModelScope.launch {
            repository.updateCompanion(companion)
            scheduler.rescheduleAllActiveAlarms()
        }
    }

    fun finishOnboarding() {
        viewModelScope.launch {
            repository.completeOnboarding()
        }
    }

    fun speakLanguageExample(language: AppLanguage) {
        val companion = uiState.value.companion
        voicePlayer.speak(
            text = language.sampleSentence,
            companion = companion,
            language = language
        )
    }

    fun speakCompanionPreview(companion: CompanionType, language: AppLanguage = uiState.value.language) {
        val line = L10n.companionPreviewVoice(companion, language)
        voicePlayer.speak(
            text = line,
            companion = companion,
            language = language
        )
    }

    fun speakCompanionMood(mood: CompanionMood) {
        val state = uiState.value
        val line = L10n.companionMoodMessage(
            companion = state.companion,
            mood = mood,
            lang = state.language,
            minutesLate = state.maxLateMinutesToday
        )
        voicePlayer.speak(
            text = line,
            companion = state.companion,
            language = state.language,
            isMaxShout = mood == CompanionMood.ANGRY
        )
    }

    fun speakMaxShoutTest() {
        val state = uiState.value
        val line = L10n.companionLateMessage(state.companion, state.language, 30)
        voicePlayer.speak(
            text = line,
            companion = state.companion,
            language = state.language,
            isMaxShout = true
        )
    }

    fun takeDose(dose: TodayDoseItem) {
        viewModelScope.launch {
            repository.markDoseTaken(dose.medicineId, dose.name, dose.dosage, dose.scheduledTime)
            NotificationManagerCompat.from(app)
                .cancel(NotificationHelper.notificationIdForDose(dose.medicineId, dose.scheduledTime))
            scheduler.cancelMaxShoutForDose(dose.medicineId, dose.scheduledTime)
            repository.getMedicineById(dose.medicineId)?.let { med ->
                scheduler.scheduleNextDayAfterAction(med, dose.scheduledTime)
            }
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.takenToast(dose.name))
            val praise = L10n.companionOnTimeMessage(uiState.value.companion, uiState.value.language)
            if (uiState.value.profile.voiceAlertEnabled && dose.voiceAlertEnabled) {
                voicePlayer.speak(praise, uiState.value.companion, uiState.value.language)
            }
        }
    }

    fun snoozeDose(dose: TodayDoseItem) {
        viewModelScope.launch {
            NotificationManagerCompat.from(app)
                .cancel(NotificationHelper.notificationIdForDose(dose.medicineId, dose.scheduledTime))
            scheduler.cancelMaxShoutForDose(dose.medicineId, dose.scheduledTime)
            scheduler.scheduleSnooze10m(dose.medicineId, dose.name, dose.dosage, dose.scheduledTime)
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.snoozedToast)
        }
    }

    fun skipDose(dose: TodayDoseItem) {
        viewModelScope.launch {
            repository.markDoseSkipped(dose.medicineId, dose.name, dose.dosage, dose.scheduledTime)
            NotificationManagerCompat.from(app)
                .cancel(NotificationHelper.notificationIdForDose(dose.medicineId, dose.scheduledTime))
            scheduler.cancelMaxShoutForDose(dose.medicineId, dose.scheduledTime)
            repository.getMedicineById(dose.medicineId)?.let { med ->
                scheduler.scheduleNextDayAfterAction(med, dose.scheduledTime)
            }
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.skippedToast(dose.name))
        }
    }

    fun toggleDoseVoiceAlert(dose: TodayDoseItem) {
        viewModelScope.launch {
            repository.toggleMedicineVoiceAlert(dose.medicineId, !dose.voiceAlertEnabled)
        }
    }

    fun saveMedicine(medicine: MedicineEntity, onSaved: () -> Unit) {
        viewModelScope.launch {
            val savedId = repository.saveMedicine(medicine)
            val savedMed = repository.getMedicineById(savedId) ?: medicine.copy(id = savedId)
            scheduler.scheduleMedicine(savedMed)
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.medSavedToast(savedMed.name))
            onSaved()
        }
    }

    fun deleteMedicine(medicineId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            scheduler.cancelMedicineAlarms(medicineId)
            repository.deleteMedicine(medicineId)
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.medDeletedToast)
            onDeleted()
        }
    }

    fun saveProfileDetails(
        name: String,
        age: Int,
        photoUri: String?,
        emergencyName: String,
        emergencyPhone: String
    ) {
        viewModelScope.launch {
            repository.updateProfileDetails(name, age, photoUri, emergencyName, emergencyPhone)
            val strings = L10n.strings(uiState.value.language)
            _toastEvents.emit(strings.profileSavedToast)
        }
    }

    fun updateNotificationSettings(
        notificationsEnabled: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        voiceAlertEnabled: Boolean
    ) {
        viewModelScope.launch {
            repository.updateNotificationSettings(
                notificationsEnabled = notificationsEnabled,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled,
                voiceAlertEnabled = voiceAlertEnabled
            )
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.updateThemeMode(mode.code)
        }
    }

    fun buildDoctorExportText(): String {
        val state = uiState.value
        val allLogs = state.selectedDayLogs.map {
            MedicineLogEntity(
                id = it.logId,
                medicineId = it.medicineId,
                medicineName = it.medicineName,
                dosage = it.dosage,
                dateEpochDay = state.selectedCalendarDay,
                scheduledTime = it.scheduledTime,
                timeTakenMillis = it.timeTakenMillis,
                status = it.status
            )
        }
        return repository.buildDoctorExportReport(
            profile = state.profile,
            medicines = state.allMedicines,
            logs = allLogs,
            streakDays = state.streakDays,
            weeklyAdherence = state.weeklyAdherencePercent
        )
    }

    private data class QuadData(
        val profile: UserProfileEntity,
        val medicines: List<MedicineEntity>,
        val logs: List<MedicineLogEntity>,
        val nowMillis: Long
    )

    private data class UiInputs(
        val searchQuery: String,
        val calDay: Long,
        val onboardingStep: Int,
        val systemNotifAllowed: Boolean,
        val batteryIgnored: Boolean
    )

    companion object {
        private fun checkBatteryIgnored(context: Context): Boolean {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return true
            return pm.isIgnoringBatteryOptimizations(context.packageName)
        }
    }
}
