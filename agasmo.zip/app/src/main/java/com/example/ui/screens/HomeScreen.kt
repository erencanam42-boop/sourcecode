package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.i18n.L10n
import com.example.model.DoseStatus
import com.example.model.TodayDoseItem
import com.example.ui.AgasMoUiState
import com.example.ui.components.AgasMoCard
import com.example.ui.components.CompanionAvatar
import com.example.ui.components.NotificationOffBanner
import com.example.ui.components.PillIconBadge
import com.example.ui.components.formatTime12Hour
import com.example.ui.components.openAppNotificationSettings
import com.example.ui.theme.LocalAgasMoColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    uiState: AgasMoUiState,
    onSearchChange: (String) -> Unit,
    onTakeDose: (TodayDoseItem) -> Unit,
    onSnoozeDose: (TodayDoseItem) -> Unit,
    onSkipDose: (TodayDoseItem) -> Unit,
    onToggleVoiceAlert: (TodayDoseItem) -> Unit,
    onEditMedicine: (Long) -> Unit,
    onAddMedicineClick: () -> Unit,
    onCompanionAvatarClick: () -> Unit
) {
    val context = LocalContext.current
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current
    val dateLabel = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())

    val totalCount = uiState.todayDoses.size
    val takenCount = uiState.todayDoses.count { it.status == DoseStatus.TAKEN }
    val nextDose = uiState.todayDoses.firstOrNull {
        it.status == DoseStatus.LATE || it.status == DoseStatus.UPCOMING
    }

    val notifOff = !uiState.systemNotificationsAllowed || !uiState.profile.notificationsEnabled
    val showEmergencyAlert = uiState.maxLateMinutesToday >= 120 &&
        uiState.profile.emergencyContactNumber.isNotBlank()

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.homeGreeting(uiState.profile.name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = ext.primaryText
                        )
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.bodyLarge,
                            color = ext.secondaryText
                        )
                    }
                    CompanionAvatar(
                        companion = uiState.companion,
                        size = 64.dp,
                        mood = uiState.companionMood,
                        modifier = Modifier
                            .testTag("home_companion_avatar")
                            .clickable { onCompanionAvatarClick() }
                    )
                }
            }

            if (notifOff) {
                item {
                    NotificationOffBanner(
                        text = strings.notifOffBanner(uiState.companion.displayName),
                        onClick = { openAppNotificationSettings(context) }
                    )
                }
            }

            if (showEmergencyAlert) {
                item {
                    val contactName = uiState.profile.emergencyContactName.ifBlank {
                        uiState.profile.emergencyContactNumber
                    }
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = ext.lateRed.copy(alpha = 0.14f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = "Emergency alert",
                                tint = ext.lateRed
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.emergencyLateBanner(contactName),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = ext.primaryText
                                )
                            }
                            Button(
                                onClick = {
                                    val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                                        data = Uri.parse("smsto:${uiState.profile.emergencyContactNumber}")
                                        putExtra(
                                            "sms_body",
                                            "AgasMo Alert: ${uiState.profile.name} is 2+ hours late on medicine."
                                        )
                                    }
                                    runCatching { context.startActivity(smsIntent) }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ext.lateRed),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("emergency_sms_button")
                            ) {
                                Text(strings.emergencyAlertBtn(contactName))
                            }
                        }
                    }
                }
            }

            item {
                NextMedicineHeroCard(
                    nextDose = nextDose,
                    uiState = uiState,
                    onTake = { nextDose?.let(onTakeDose) },
                    onSnooze = { nextDose?.let(onSnoozeDose) },
                    onAddClick = onAddMedicineClick
                )
            }

            if (totalCount > 0) {
                item {
                    AgasMoCard {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = strings.progressToday(takenCount, totalCount),
                                style = MaterialTheme.typography.titleMedium,
                                color = ext.primaryText
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = {
                                    if (totalCount == 0) 0f else takenCount.toFloat() / totalCount.toFloat()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                color = ext.takenGreen,
                                trackColor = ext.cardBorder.copy(alpha = 0.4f)
                            )
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text(strings.searchMedsHint) },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = strings.searchMedsHint)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_search_input")
                )
            }

            item {
                Text(
                    text = strings.todayMedsHeader,
                    style = MaterialTheme.typography.titleLarge,
                    color = ext.primaryText
                )
            }

            if (uiState.todayDoses.isEmpty()) {
                item {
                    AgasMoCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = strings.noMoreMedsToday,
                                style = MaterialTheme.typography.titleMedium,
                                color = ext.primaryText
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = strings.addFirstMedTip,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.secondaryText
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = onAddMedicineClick,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.testTag("home_empty_add_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = strings.navAdd)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.addMedTitle)
                            }
                        }
                    }
                }
            } else {
                items(
                    items = uiState.todayDoses,
                    key = { "${it.medicineId}_${it.scheduledTime}" }
                ) { dose ->
                    DoseCardItem(
                        dose = dose,
                        uiState = uiState,
                        onTake = { onTakeDose(dose) },
                        onSnooze = { onSnoozeDose(dose) },
                        onSkip = { onSkipDose(dose) },
                        onToggleVoice = { onToggleVoiceAlert(dose) },
                        onEdit = { onEditMedicine(dose.medicineId) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun NextMedicineHeroCard(
    nextDose: TodayDoseItem?,
    uiState: AgasMoUiState,
    onTake: () -> Unit,
    onSnooze: () -> Unit,
    onAddClick: () -> Unit
) {
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current
    val accent = Color(uiState.companion.colorHex)

    AgasMoCard(
        containerColor = if (nextDose?.status == DoseStatus.LATE) {
            ext.lateRed.copy(alpha = 0.12f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        borderColor = if (nextDose?.status == DoseStatus.LATE) ext.lateRed else accent
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (nextDose?.status == DoseStatus.LATE) ext.lateRed else accent
                ) {
                    Text(
                        text = strings.nextMedicineTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                if (nextDose != null) {
                    val timingText = when {
                        nextDose.status == DoseStatus.LATE -> strings.lateMinutesShout(nextDose.minutesLate)
                        nextDose.minutesUntil >= 60 -> strings.inHoursMins(nextDose.minutesUntil / 60, nextDose.minutesUntil % 60)
                        nextDose.minutesUntil > 0 -> strings.inMins(nextDose.minutesUntil)
                        else -> strings.dueNow
                    }
                    Text(
                        text = timingText,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (nextDose.status == DoseStatus.LATE) ext.lateRed else accent
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (nextDose == null) {
                Text(
                    text = strings.noMoreMedsToday,
                    style = MaterialTheme.typography.titleLarge,
                    color = ext.primaryText
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = L10n.companionSleepyMessage(uiState.companion, uiState.language),
                    style = MaterialTheme.typography.bodyLarge,
                    color = ext.secondaryText
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("hero_add_med_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = strings.addMedTitle)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.addMedTitle)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PillIconBadge(type = nextDose.type, colorHex = nextDose.colorHex, size = 56.dp)
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = nextDose.name,
                            style = MaterialTheme.typography.headlineSmall,
                            color = ext.primaryText
                        )
                        Text(
                            text = "${nextDose.dosage} • ${formatTime12Hour(nextDose.scheduledTime)}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = ext.secondaryText
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onTake,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ext.takenGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("hero_take_button")
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = strings.takeNow)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.takeNow, color = Color.White)
                    }
                    OutlinedButton(
                        onClick = onSnooze,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("hero_snooze_button")
                    ) {
                        Icon(Icons.Filled.Snooze, contentDescription = strings.snooze10m)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.snooze10m)
                    }
                }
            }
        }
    }
}

@Composable
private fun DoseCardItem(
    dose: TodayDoseItem,
    uiState: AgasMoUiState,
    onTake: () -> Unit,
    onSnooze: () -> Unit,
    onSkip: () -> Unit,
    onToggleVoice: () -> Unit,
    onEdit: () -> Unit
) {
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current

    val (badgeText, badgeBg, badgeFg) = when (dose.status) {
        DoseStatus.TAKEN -> Triple(strings.statusTaken, ext.takenGreen, Color.White)
        DoseStatus.LATE -> Triple(strings.statusLate, ext.lateRed, Color.White)
        DoseStatus.UPCOMING -> Triple(strings.statusUpcoming, ext.soonYellow, Color(0xFF4A2C2A))
        DoseStatus.SKIPPED -> Triple(strings.statusSkipped, Color(0xFF9E9E9E), Color.White)
    }

    AgasMoCard {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!dose.photoUri.isNullOrBlank()) {
                    AsyncImage(
                        model = dose.photoUri,
                        contentDescription = dose.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                } else {
                    PillIconBadge(type = dose.type, colorHex = dose.colorHex, size = 52.dp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = dose.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = ext.primaryText
                    )
                    Text(
                        text = "${dose.dosage} • ${formatTime12Hour(dose.scheduledTime)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ext.secondaryText
                    )
                }
                Surface(shape = RoundedCornerShape(12.dp), color = badgeBg) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelMedium,
                        color = badgeFg,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("edit_med_${dose.medicineId}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = strings.editBtn,
                        tint = ext.secondaryText
                    )
                }
            }

            if (dose.status == DoseStatus.LATE) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.lateMinutesShout(dose.minutesLate),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = ext.lateRed
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (dose.status != DoseStatus.TAKEN) {
                    Button(
                        onClick = onTake,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ext.takenGreen),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("take_med_${dose.medicineId}_${dose.scheduledTime}")
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = strings.takeNow, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.takeNow, color = Color.White, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onSnooze,
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("snooze_med_${dose.medicineId}_${dose.scheduledTime}")
                    ) {
                        Text(strings.snooze10m, maxLines = 1)
                    }
                    TextButton(
                        onClick = onSkip,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("skip_med_${dose.medicineId}_${dose.scheduledTime}")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = strings.skipBtn, modifier = Modifier.size(18.dp))
                    }
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                IconButton(
                    onClick = onToggleVoice,
                    modifier = Modifier
                        .background(
                            if (dose.voiceAlertEnabled) MaterialTheme.colorScheme.primaryContainer
                            else ext.cardBorder.copy(alpha = 0.25f),
                            RoundedCornerShape(12.dp)
                        )
                        .testTag("voice_toggle_${dose.medicineId}")
                ) {
                    Icon(
                        imageVector = if (dose.voiceAlertEnabled) {
                            Icons.AutoMirrored.Filled.VolumeUp
                        } else {
                            Icons.AutoMirrored.Filled.VolumeOff
                        },
                        contentDescription = strings.voiceAlertToggle,
                        tint = if (dose.voiceAlertEnabled) MaterialTheme.colorScheme.primary else ext.secondaryText
                    )
                }
            }
        }
    }
}
