package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.AgasMoRepository
import com.example.i18n.L10n
import com.example.ui.AgasMoUiState
import com.example.ui.components.AgasMoCard
import com.example.ui.components.formatTime12Hour
import com.example.ui.theme.LocalAgasMoColors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarHistoryScreen(
    uiState: AgasMoUiState,
    onSelectDay: (Long) -> Unit,
    onBuildExportReport: () -> String
) {
    val context = LocalContext.current
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current
    val todayCal = remember { Calendar.getInstance() }
    var displayedYear by remember { mutableIntStateOf(todayCal.get(Calendar.YEAR)) }
    var displayedMonth by remember { mutableIntStateOf(todayCal.get(Calendar.MONTH)) }

    val monthCalendar = remember(displayedYear, displayedMonth) {
        Calendar.getInstance().apply {
            set(Calendar.YEAR, displayedYear)
            set(Calendar.MONTH, displayedMonth)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }
    val monthTitle = remember(displayedYear, displayedMonth) {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(monthCalendar.time)
    }
    val firstDayOffset = (monthCalendar.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon=0 .. Sun=6
    val daysInMonth = monthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

    val selectedDateStr = remember(uiState.selectedCalendarDay) {
        val millis = AgasMoRepository.epochDayToMidnightMillis(uiState.selectedCalendarDay)
        SimpleDateFormat("EEE, MMM d, yyyy", Locale.getDefault()).format(Date(millis))
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = strings.historyTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ext.primaryText
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AgasMoCard(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = strings.streakLabel(uiState.streakDays),
                                style = MaterialTheme.typography.titleLarge,
                                color = ext.primaryText
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${uiState.companion.displayName} is cheering!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.secondaryText
                            )
                        }
                    }
                    AgasMoCard(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${uiState.weeklyAdherencePercent}%",
                                style = MaterialTheme.typography.headlineMedium,
                                color = ext.takenGreen
                            )
                            Text(
                                text = strings.adherenceThisWeek,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.secondaryText
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { uiState.weeklyAdherencePercent / 100f },
                                color = ext.takenGreen,
                                trackColor = ext.cardBorder.copy(alpha = 0.35f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                        }
                    }
                }
            }

            item {
                AgasMoCard {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = {
                                    if (displayedMonth == 0) {
                                        displayedMonth = 11
                                        displayedYear--
                                    } else {
                                        displayedMonth--
                                    }
                                },
                                modifier = Modifier.testTag("calendar_prev_month")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                            }
                            Text(
                                text = monthTitle,
                                style = MaterialTheme.typography.titleLarge,
                                color = ext.primaryText
                            )
                            IconButton(
                                onClick = {
                                    if (displayedMonth == 11) {
                                        displayedMonth = 0
                                        displayedYear++
                                    } else {
                                        displayedMonth++
                                    }
                                },
                                modifier = Modifier.testTag("calendar_next_month")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            (1..7).forEach { iso ->
                                Text(
                                    text = L10n.dayShortLabel(iso, uiState.language),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ext.secondaryText,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        val totalCells = firstDayOffset + daysInMonth
                        val rows = (totalCells + 6) / 7
                        for (rowIndex in 0 until rows) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                for (col in 0..6) {
                                    val cellIdx = rowIndex * 7 + col
                                    val dayNum = cellIdx - firstDayOffset + 1
                                    if (dayNum in 1..daysInMonth) {
                                        val cellCal = Calendar.getInstance().apply {
                                            set(Calendar.YEAR, displayedYear)
                                            set(Calendar.MONTH, displayedMonth)
                                            set(Calendar.DAY_OF_MONTH, dayNum)
                                            set(Calendar.HOUR_OF_DAY, 12)
                                        }
                                        val tzOffset = cellCal.timeZone.getOffset(cellCal.timeInMillis)
                                        val epochDay = (cellCal.timeInMillis + tzOffset) / 86_400_000L
                                        val isSelected = epochDay == uiState.selectedCalendarDay
                                        val hasTaken = uiState.daysWithTakenLogs.contains(epochDay)
                                        val hasSkipped = uiState.daysWithLateOrMissed.contains(epochDay)

                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) MaterialTheme.colorScheme.primary
                                                    else Color.Transparent
                                                )
                                                .border(
                                                    width = if (epochDay == AgasMoRepository.todayEpochDay() && !isSelected) 1.5.dp else 0.dp,
                                                    color = if (epochDay == AgasMoRepository.todayEpochDay() && !isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                                    shape = CircleShape
                                                )
                                                .clickable { onSelectDay(epochDay) }
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(
                                                    text = dayNum.toString(),
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = if (isSelected) Color.White else ext.primaryText
                                                )
                                                if (hasTaken || hasSkipped) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(6.dp)
                                                            .clip(CircleShape)
                                                            .background(
                                                                if (hasTaken) ext.takenGreen else ext.lateRed
                                                            )
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = selectedDateStr,
                        style = MaterialTheme.typography.titleLarge,
                        color = ext.primaryText
                    )
                    Button(
                        onClick = {
                            val report = onBuildExportReport()
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "AgasMo Medicine History")
                                putExtra(Intent.EXTRA_TEXT, report)
                            }
                            runCatching {
                                context.startActivity(Intent.createChooser(sendIntent, strings.exportToDoctor))
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("export_doctor_button")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = strings.exportToDoctor, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.exportToDoctor)
                    }
                }
            }

            if (uiState.selectedDayLogs.isEmpty()) {
                item {
                    AgasMoCard {
                        Text(
                            text = strings.noLogsForDate,
                            style = MaterialTheme.typography.bodyLarge,
                            color = ext.secondaryText,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(uiState.selectedDayLogs, key = { it.logId }) { log ->
                    val statusColor = when (log.status) {
                        "TAKEN" -> ext.takenGreen
                        "SKIPPED" -> Color.Gray
                        else -> ext.soonYellow
                    }
                    AgasMoCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${log.medicineName} (${log.dosage})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ext.primaryText
                                )
                                Text(
                                    text = formatTime12Hour(log.scheduledTime),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ext.secondaryText
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = statusColor
                            ) {
                                Text(
                                    text = log.status,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
