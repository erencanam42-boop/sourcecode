package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.L10n
import com.example.ui.components.AgasMoBackground
import com.example.ui.components.NotificationPermissionDialog
import com.example.ui.components.openAppNotificationSettings
import com.example.ui.screens.AddMedicineScreen
import com.example.ui.screens.CalendarHistoryScreen
import com.example.ui.screens.CompanionMoodScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingCompanionScreen
import com.example.ui.screens.OnboardingLanguageScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.theme.AgasMoTheme

enum class AgasMoTab(val route: String) {
    TODAY("today"),
    ADD("add"),
    HISTORY("history"),
    COMPANION("companion"),
    PROFILE("profile")
}

@Composable
fun AgasMoRoot(viewModel: AgasMoViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    var currentTab by remember { mutableStateOf(AgasMoTab.TODAY) }
    var editingMedicineId by remember { mutableStateOf<Long?>(null) }
    var showPermissionPrompt by remember { mutableStateOf(false) }
    var hasPromptedOnce by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshSystemChecks()
    }

    LaunchedEffect(uiState.profile.onboardingCompleted, uiState.isLoading) {
        if (!uiState.isLoading && uiState.profile.onboardingCompleted && !hasPromptedOnce) {
            hasPromptedOnce = true
            viewModel.refreshSystemChecks()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    showPermissionPrompt = true
                }
            }
        }
    }

    AgasMoTheme(
        themeMode = uiState.themeMode,
        companionAccent = Color(uiState.companion.colorHex)
    ) {
        if (uiState.isLoading) {
            AgasMoBackground {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (!uiState.profile.onboardingCompleted) {
            if (uiState.onboardingStep == 0) {
                OnboardingLanguageScreen(
                    selectedLanguage = uiState.language,
                    onSelectLanguage = { viewModel.selectLanguage(it, showToast = false) },
                    onHearExample = { viewModel.speakLanguageExample(it) },
                    onContinue = { viewModel.setOnboardingStep(1) }
                )
            } else {
                BackHandler { viewModel.setOnboardingStep(0) }
                OnboardingCompanionScreen(
                    selectedLanguage = uiState.language,
                    selectedCompanion = uiState.companion,
                    onSelectCompanion = { viewModel.selectCompanion(it) },
                    onHearVoice = { viewModel.speakCompanionPreview(it) },
                    onStart = { viewModel.finishOnboarding() }
                )
            }
        } else {
            if (currentTab != AgasMoTab.TODAY) {
                BackHandler {
                    editingMedicineId = null
                    currentTab = AgasMoTab.TODAY
                }
            }

            val strings = L10n.strings(uiState.language)
            val navItems = listOf(
                NavDest(AgasMoTab.TODAY, strings.navToday, Icons.Filled.Home, Icons.Outlined.Home),
                NavDest(AgasMoTab.ADD, strings.navAdd, Icons.Filled.AddCircle, Icons.Outlined.AddCircleOutline),
                NavDest(AgasMoTab.HISTORY, strings.navHistory, Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth),
                NavDest(AgasMoTab.COMPANION, strings.navCompanion, Icons.Filled.Pets, Icons.Outlined.Pets),
                NavDest(AgasMoTab.PROFILE, strings.navProfile, Icons.Filled.Person, Icons.Outlined.Person)
            )

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavRail = maxWidth >= 700.dp

                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    bottomBar = {
                        if (!useNavRail) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
                            ) {
                                navItems.forEach { item ->
                                    val selected = currentTab == item.tab
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            if (item.tab != AgasMoTab.ADD) editingMedicineId = null
                                            currentTab = item.tab
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                contentDescription = item.label
                                            )
                                        },
                                        label = { Text(item.label, maxLines = 1) },
                                        modifier = Modifier.testTag("nav_${item.tab.route}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    AgasMoBackground(modifier = Modifier.padding(innerPadding)) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .statusBarsPadding()
                        ) {
                            if (useNavRail) {
                                NavigationRail(
                                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                                ) {
                                    navItems.forEach { item ->
                                        val selected = currentTab == item.tab
                                        NavigationRailItem(
                                            selected = selected,
                                            onClick = {
                                                if (item.tab != AgasMoTab.ADD) editingMedicineId = null
                                                currentTab = item.tab
                                            },
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                    contentDescription = item.label
                                                )
                                            },
                                            label = { Text(item.label) },
                                            modifier = Modifier.testTag("rail_${item.tab.route}")
                                        )
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                            ) {
                                when (currentTab) {
                                    AgasMoTab.TODAY -> {
                                        LaunchedEffect(currentTab) {
                                            viewModel.refreshSystemChecks()
                                        }
                                        HomeScreen(
                                            uiState = uiState,
                                            onSearchChange = viewModel::setSearchQuery,
                                            onTakeDose = viewModel::takeDose,
                                            onSnoozeDose = viewModel::snoozeDose,
                                            onSkipDose = viewModel::skipDose,
                                            onToggleVoiceAlert = viewModel::toggleDoseVoiceAlert,
                                            onEditMedicine = { medId ->
                                                editingMedicineId = medId
                                                currentTab = AgasMoTab.ADD
                                            },
                                            onAddMedicineClick = {
                                                editingMedicineId = null
                                                currentTab = AgasMoTab.ADD
                                            },
                                            onCompanionAvatarClick = {
                                                currentTab = AgasMoTab.COMPANION
                                            }
                                        )
                                    }
                                    AgasMoTab.ADD -> {
                                        val editingMed = uiState.allMedicines.firstOrNull { it.id == editingMedicineId }
                                        AddMedicineScreen(
                                            language = uiState.language,
                                            editingMedicine = editingMed,
                                            onSave = { med ->
                                                viewModel.saveMedicine(med) {
                                                    editingMedicineId = null
                                                    currentTab = AgasMoTab.TODAY
                                                }
                                            },
                                            onDelete = { medId ->
                                                viewModel.deleteMedicine(medId) {
                                                    editingMedicineId = null
                                                    currentTab = AgasMoTab.TODAY
                                                }
                                            },
                                            onCancelEdit = {
                                                editingMedicineId = null
                                                currentTab = AgasMoTab.TODAY
                                            }
                                        )
                                    }
                                    AgasMoTab.HISTORY -> {
                                        CalendarHistoryScreen(
                                            uiState = uiState,
                                            onSelectDay = viewModel::setSelectedCalendarDay,
                                            onBuildExportReport = viewModel::buildDoctorExportText
                                        )
                                    }
                                    AgasMoTab.COMPANION -> {
                                        CompanionMoodScreen(
                                            uiState = uiState,
                                            onPlayMoodVoice = viewModel::speakCompanionMood,
                                            onPlayMaxShout = viewModel::speakMaxShoutTest
                                        )
                                    }
                                    AgasMoTab.PROFILE -> {
                                        ProfileSettingsScreen(
                                            uiState = uiState,
                                            onSelectLanguage = { lang -> viewModel.selectLanguage(lang, showToast = true) },
                                            onSelectCompanion = viewModel::selectCompanion,
                                            onHearCompanionVoice = { comp -> viewModel.speakCompanionPreview(comp) },
                                            onHearShout = viewModel::speakMaxShoutTest,
                                            onSaveProfile = viewModel::saveProfileDetails,
                                            onUpdateNotificationSettings = viewModel::updateNotificationSettings,
                                            onSelectTheme = viewModel::updateThemeMode
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (showPermissionPrompt) {
                NotificationPermissionDialog(
                    companion = uiState.companion,
                    strings = strings,
                    onAllow = {
                        showPermissionPrompt = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            openAppNotificationSettings(context)
                        }
                    },
                    onDismiss = {
                        showPermissionPrompt = false
                        viewModel.refreshSystemChecks()
                    }
                )
            }
        }
    }
}

private data class NavDest(
    val tab: AgasMoTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)
