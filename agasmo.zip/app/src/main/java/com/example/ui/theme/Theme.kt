package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.ThemeMode

data class AgasMoExtendedColors(
    val gradientTop: Color,
    val gradientBottom: Color,
    val cardBorder: Color,
    val takenGreen: Color,
    val lateRed: Color,
    val soonYellow: Color,
    val primaryText: Color,
    val secondaryText: Color
)

val LocalAgasMoColors = staticCompositionLocalOf {
    AgasMoExtendedColors(
        gradientTop = PeachCream,
        gradientBottom = SoftPinkBg,
        cardBorder = SoftRoseBorder,
        takenGreen = TakenGreen,
        lateRed = NeonRedLate,
        soonYellow = SoonYellow,
        primaryText = DarkBrownText,
        secondaryText = WarmCocoaText
    )
}

private val PinkColorScheme = lightColorScheme(
    primary = LumiPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE4FF),
    onPrimaryContainer = DarkBrownText,
    secondary = MimiPink,
    onSecondary = Color.White,
    secondaryContainer = SoftPinkBg,
    onSecondaryContainer = DarkBrownText,
    tertiary = KikoOrange,
    background = PeachCream,
    onBackground = DarkBrownText,
    surface = WarmWhiteCard,
    onSurface = DarkBrownText,
    surfaceVariant = Color(0xFFFFEAE4),
    onSurfaceVariant = WarmCocoaText,
    error = NeonRedLate,
    onError = Color.White,
    outline = SoftRoseBorder
)

private val LightColorScheme = lightColorScheme(
    primary = LumiPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE4FF),
    onPrimaryContainer = DarkBrownText,
    secondary = TalaTeal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF5EE),
    onSecondaryContainer = DarkBrownText,
    tertiary = KikoOrange,
    background = Color(0xFFFFFBF7),
    onBackground = DarkBrownText,
    surface = Color.White,
    onSurface = DarkBrownText,
    surfaceVariant = PeachCream,
    onSurfaceVariant = WarmCocoaText,
    error = NeonRedLate,
    onError = Color.White,
    outline = Color(0xFFE7D3CE)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFA78BFA),
    onPrimary = Color(0xFF1F1135),
    primaryContainer = Color(0xFF3E296B),
    onPrimaryContainer = CreamOnDark,
    secondary = Color(0xFFFF85C1),
    onSecondary = Color(0xFF3A0E24),
    secondaryContainer = DarkRoseElevated,
    onSecondaryContainer = CreamOnDark,
    tertiary = Color(0xFFFFAD42),
    background = DarkPlumBg,
    onBackground = CreamOnDark,
    surface = DarkRoseCard,
    onSurface = CreamOnDark,
    surfaceVariant = DarkRoseElevated,
    onSurfaceVariant = MutedRoseOnDark,
    error = NeonRedLate,
    onError = Color.White,
    outline = Color(0xFF563A40)
)

private val AgasMoShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun AgasMoTheme(
    themeMode: ThemeMode = ThemeMode.PINK,
    companionAccent: Color = LumiPurple,
    content: @Composable () -> Unit
) {
    val isDark = themeMode == ThemeMode.DARK
    val baseScheme = when (themeMode) {
        ThemeMode.PINK -> PinkColorScheme.copy(primary = companionAccent)
        ThemeMode.LIGHT -> LightColorScheme.copy(primary = companionAccent)
        ThemeMode.DARK -> DarkColorScheme
    }

    val extended = when (themeMode) {
        ThemeMode.PINK -> AgasMoExtendedColors(
            gradientTop = PeachCream,
            gradientBottom = SoftPinkBg,
            cardBorder = SoftRoseBorder,
            takenGreen = TakenGreen,
            lateRed = NeonRedLate,
            soonYellow = SoonYellow,
            primaryText = DarkBrownText,
            secondaryText = WarmCocoaText
        )
        ThemeMode.LIGHT -> AgasMoExtendedColors(
            gradientTop = Color(0xFFFFFBF7),
            gradientBottom = Color(0xFFFFF1E6),
            cardBorder = Color(0xFFEBD8D3),
            takenGreen = TakenGreen,
            lateRed = NeonRedLate,
            soonYellow = SoonYellow,
            primaryText = DarkBrownText,
            secondaryText = WarmCocoaText
        )
        ThemeMode.DARK -> AgasMoExtendedColors(
            gradientTop = DarkPlumBg,
            gradientBottom = Color(0xFF28171C),
            cardBorder = Color(0xFF4E3439),
            takenGreen = TakenGreen,
            lateRed = NeonRedLate,
            soonYellow = SoonYellow,
            primaryText = CreamOnDark,
            secondaryText = MutedRoseOnDark
        )
    }

    CompositionLocalProvider(LocalAgasMoColors provides extended) {
        MaterialTheme(
            colorScheme = baseScheme,
            typography = AgasMoTypography,
            shapes = AgasMoShapes,
            content = content
        )
    }
}
