package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.i18n.AppStrings
import com.example.model.CompanionMood
import com.example.model.CompanionType
import com.example.model.MedicineType
import com.example.ui.theme.LocalAgasMoColors
import java.util.Locale

@Composable
fun AgasMoBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val ext = LocalAgasMoColors.current
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ext.gradientTop, ext.gradientBottom)
                )
            ),
        content = content
    )
}

@Composable
fun CompanionAvatar(
    companion: CompanionType,
    size: Dp = 64.dp,
    mood: CompanionMood? = null,
    modifier: Modifier = Modifier
) {
    val accent = Color(companion.colorHex)
    Box(modifier = modifier) {
        Image(
            painter = painterResource(id = companion.avatarRes),
            contentDescription = "${companion.displayName} ${companion.speciesLabel}",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .border(3.dp, accent, CircleShape)
        )
        if (mood != null) {
            val moodEmoji = when (mood) {
                CompanionMood.HAPPY -> "😊"
                CompanionMood.ANGRY -> "😤"
                CompanionMood.SLEEPY -> "😴"
            }
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 3.dp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size((size.value * 0.36f).dp.coerceAtLeast(22.dp))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = moodEmoji)
                }
            }
        }
    }
}

@Composable
fun AgasMoCard(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = LocalAgasMoColors.current.cardBorder,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = borderColor.copy(alpha = 0.35f),
                spotColor = borderColor.copy(alpha = 0.25f)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.5.dp, borderColor.copy(alpha = 0.55f))
    ) {
        content()
    }
}

@Composable
fun PillIconBadge(
    type: MedicineType,
    colorHex: Long,
    size: Dp = 48.dp
) {
    val icon: ImageVector = when (type) {
        MedicineType.TABLET, MedicineType.CAPSULE -> Icons.Filled.Medication
        MedicineType.SYRUP -> Icons.Filled.WaterDrop
        MedicineType.INJECTION -> Icons.Filled.Vaccines
    }
    val tint = Color(colorHex)
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(16.dp))
            .background(tint.copy(alpha = 0.18f))
            .border(1.5.dp, tint.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        Icon(
            imageVector = icon,
            contentDescription = type.code,
            tint = tint,
            modifier = Modifier.size(size * 0.56f)
        )
    }
}

@Composable
fun NotificationOffBanner(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAgasMoColors.current
    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("notification_off_banner"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ext.lateRed)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.NotificationsOff,
                contentDescription = "Notifications disabled",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }
    }
}

@Composable
fun NotificationPermissionDialog(
    companion: CompanionType,
    strings: AppStrings,
    onAllow: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        icon = {
            CompanionAvatar(companion = companion, size = 72.dp, mood = CompanionMood.HAPPY)
        },
        title = {
            Text(
                text = strings.permDialogTitle(companion.displayName),
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = strings.permDialogBody(companion.displayName),
                style = MaterialTheme.typography.bodyLarge
            )
        },
        confirmButton = {
            Button(
                onClick = onAllow,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(companion.colorHex)),
                modifier = Modifier.testTag("permission_allow_button")
            ) {
                Text(strings.permAllow)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("permission_later_button")
            ) {
                Text(strings.permLater)
            }
        }
    )
}

fun formatTime12Hour(time24: String): String {
    val parts = time24.split(":")
    val hour24 = parts.getOrNull(0)?.toIntOrNull() ?: 8
    val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
    val amPm = if (hour24 >= 12) "PM" else "AM"
    val hour12 = when {
        hour24 == 0 -> 12
        hour24 > 12 -> hour24 - 12
        else -> hour24
    }
    return String.format(Locale.US, "%d:%02d %s", hour12, minute, amPm)
}

fun openAppNotificationSettings(context: Context) {
    val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}

fun openBatteryOptimizationSettings(context: Context) {
    val reqIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
        data = Uri.parse("package:${context.packageName}")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    val ok = runCatching { context.startActivity(reqIntent) }.isSuccess
    if (!ok) {
        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(fallback) }
    }
}
