package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.ThemeMode
import com.example.ui.AgasMoUiState
import com.example.ui.components.AgasMoCard
import com.example.ui.components.CompanionAvatar
import com.example.ui.components.openAppNotificationSettings
import com.example.ui.components.openBatteryOptimizationSettings
import com.example.ui.theme.LocalAgasMoColors

@Composable
fun ProfileSettingsScreen(
    uiState: AgasMoUiState,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectCompanion: (CompanionType) -> Unit,
    onHearCompanionVoice: (CompanionType) -> Unit,
    onHearShout: () -> Unit,
    onSaveProfile: (name: String, age: Int, photoUri: String?, emergencyName: String, emergencyPhone: String) -> Unit,
    onUpdateNotificationSettings: (notif: Boolean, sound: Boolean, vibration: Boolean, voice: Boolean) -> Unit,
    onSelectTheme: (ThemeMode) -> Unit
) {
    val context = LocalContext.current
    val strings = L10n.strings(uiState.language)
    val ext = LocalAgasMoColors.current

    // Hoisted profile input states so expanding/collapsing never loses user edits
    var userName by remember(uiState.profile.name) { mutableStateOf(uiState.profile.name) }
    var userAge by remember(uiState.profile.age) { mutableStateOf(uiState.profile.age.toString()) }
    var userPhotoUri by remember(uiState.profile.photoUri) { mutableStateOf(uiState.profile.photoUri) }
    var emergencyName by remember(uiState.profile.emergencyContactName) {
        mutableStateOf(uiState.profile.emergencyContactName)
    }
    var emergencyPhone by remember(uiState.profile.emergencyContactNumber) {
        mutableStateOf(uiState.profile.emergencyContactNumber)
    }
    var showCompanionPickerDialog by remember { mutableStateOf(false) }

    // Clean expandable accordion states
    var languageExpanded by rememberSaveable { mutableStateOf(false) }
    var companionExpanded by rememberSaveable { mutableStateOf(false) }
    var notificationsExpanded by rememberSaveable { mutableStateOf(false) }
    var themeExpanded by rememberSaveable { mutableStateOf(false) }
    var profileExpanded by rememberSaveable { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userPhotoUri = uri.toString()
            onSaveProfile(
                userName,
                userAge.toIntOrNull() ?: 65,
                userPhotoUri,
                emergencyName,
                emergencyPhone
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = strings.profileTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ext.primaryText
                )
            }

            // Clean Profile Summary Header Card
            item {
                AgasMoCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                        ) {
                            if (!userPhotoUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = userPhotoUri,
                                    contentDescription = userName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    Icons.Filled.Person,
                                    contentDescription = "User photo",
                                    modifier = Modifier.size(34.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = uiState.profile.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = ext.primaryText
                            )
                            Text(
                                text = "${strings.userAgeLabel}: ${uiState.profile.age} • ${uiState.language.flagEmoji} ${uiState.language.displayName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.secondaryText
                            )
                        }
                        CompanionAvatar(companion = uiState.companion, size = 48.dp)
                    }
                }
            }

            // SECTION 1 - LANGUAGE (EXPANDABLE)
            item {
                ExpandableSettingsSection(
                    title = strings.sectionLanguage,
                    summary = "${uiState.language.flagEmoji} ${uiState.language.displayName}",
                    icon = Icons.Filled.Language,
                    accentColor = MaterialTheme.colorScheme.primary,
                    expanded = languageExpanded,
                    onToggle = { languageExpanded = !languageExpanded },
                    headerTestTag = "expand_language_section"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            val selected = lang == uiState.language
                            Card(
                                onClick = { onSelectLanguage(lang) },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                ),
                                border = BorderStroke(
                                    if (selected) 2.dp else 1.dp,
                                    if (selected) MaterialTheme.colorScheme.primary else ext.cardBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_lang_${lang.code.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = lang.flagEmoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = lang.displayName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = ext.primaryText
                                        )
                                        Text(
                                            text = lang.sampleSentence,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = ext.secondaryText
                                        )
                                    }
                                    RadioButton(
                                        selected = selected,
                                        onClick = { onSelectLanguage(lang) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // SECTION 2 - MY COMPANION (EXPANDABLE)
            item {
                ExpandableSettingsSection(
                    title = strings.sectionCompanion,
                    summary = "${uiState.companion.displayName} ${uiState.companion.speciesLabel} • ${uiState.companion.voiceStyle}",
                    icon = Icons.Filled.Pets,
                    accentColor = Color(uiState.companion.colorHex),
                    expanded = companionExpanded,
                    onToggle = { companionExpanded = !companionExpanded },
                    headerTestTag = "expand_companion_section"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CompanionAvatar(companion = uiState.companion, size = 60.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${uiState.companion.displayName} ${uiState.companion.speciesLabel}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = ext.primaryText
                                )
                                Text(
                                    text = L10n.companionPersonality(uiState.companion, uiState.language),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ext.secondaryText
                                )
                            }
                            Button(
                                onClick = { showCompanionPickerDialog = true },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(uiState.companion.colorHex)),
                                modifier = Modifier.testTag("change_companion_button")
                            ) {
                                Text(strings.changeBtn, color = Color.White)
                            }
                        }

                        SettingSwitchRow(
                            label = strings.voiceAlertToggle,
                            checked = uiState.profile.voiceAlertEnabled,
                            tag = "settings_voice_switch",
                            onCheckedChange = { enabled ->
                                onUpdateNotificationSettings(
                                    uiState.profile.notificationsEnabled,
                                    uiState.profile.soundEnabled,
                                    uiState.profile.vibrationEnabled,
                                    enabled
                                )
                            }
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { onHearCompanionVoice(uiState.companion) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("settings_hear_voice_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = strings.hearVoice)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.hearVoice)
                            }
                            OutlinedButton(
                                onClick = onHearShout,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("settings_hear_shout_button")
                            ) {
                                Text("MAX SHOUT!")
                            }
                        }
                    }
                }
            }

            // SECTION 3 - NOTIFICATIONS & SOUND (EXPANDABLE)
            item {
                val notifStatus = if (uiState.profile.notificationsEnabled && uiState.systemNotificationsAllowed) {
                    "ON"
                } else {
                    "OFF"
                }
                ExpandableSettingsSection(
                    title = strings.sectionNotifications,
                    summary = "${strings.masterNotifLabel}: $notifStatus",
                    icon = Icons.Filled.Notifications,
                    accentColor = if (notifStatus == "ON") ext.takenGreen else ext.lateRed,
                    expanded = notificationsExpanded,
                    onToggle = { notificationsExpanded = !notificationsExpanded },
                    headerTestTag = "expand_notifications_section"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SettingSwitchRow(
                            label = strings.masterNotifLabel,
                            checked = uiState.profile.notificationsEnabled,
                            tag = "settings_notif_switch",
                            onCheckedChange = {
                                onUpdateNotificationSettings(
                                    it,
                                    uiState.profile.soundEnabled,
                                    uiState.profile.vibrationEnabled,
                                    uiState.profile.voiceAlertEnabled
                                )
                            }
                        )
                        SettingSwitchRow(
                            label = strings.soundLabel,
                            checked = uiState.profile.soundEnabled,
                            tag = "settings_sound_switch",
                            onCheckedChange = {
                                onUpdateNotificationSettings(
                                    uiState.profile.notificationsEnabled,
                                    it,
                                    uiState.profile.vibrationEnabled,
                                    uiState.profile.voiceAlertEnabled
                                )
                            }
                        )
                        SettingSwitchRow(
                            label = strings.vibrationLabel,
                            checked = uiState.profile.vibrationEnabled,
                            tag = "settings_vibration_switch",
                            onCheckedChange = {
                                onUpdateNotificationSettings(
                                    uiState.profile.notificationsEnabled,
                                    uiState.profile.soundEnabled,
                                    it,
                                    uiState.profile.voiceAlertEnabled
                                )
                            }
                        )

                        OutlinedButton(
                            onClick = { openAppNotificationSettings(context) },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_system_notif_settings")
                        ) {
                            Icon(Icons.Filled.Notifications, contentDescription = strings.openSystemNotifSettings)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.openSystemNotifSettings)
                        }

                        OutlinedButton(
                            onClick = { openBatteryOptimizationSettings(context) },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("battery_optimization_button")
                        ) {
                            Icon(Icons.Filled.BatteryChargingFull, contentDescription = strings.batteryOptimizeBtn)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (uiState.isBatteryOptimizationIgnored) strings.batteryOptimizedAlready
                                else strings.batteryOptimizeBtn
                            )
                        }
                    }
                }
            }

            // SECTION 4 - THEME (EXPANDABLE)
            item {
                ExpandableSettingsSection(
                    title = strings.sectionTheme,
                    summary = L10n.themeLabel(uiState.themeMode, uiState.language),
                    icon = Icons.Filled.Palette,
                    accentColor = MaterialTheme.colorScheme.secondary,
                    expanded = themeExpanded,
                    onToggle = { themeExpanded = !themeExpanded },
                    headerTestTag = "expand_theme_section"
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = uiState.themeMode == mode,
                                onClick = { onSelectTheme(mode) },
                                label = { Text(L10n.themeLabel(mode, uiState.language)) },
                                modifier = Modifier.testTag("theme_${mode.code.lowercase()}")
                            )
                        }
                    }
                }
            }

            // SECTION 5 - USER PROFILE & EMERGENCY CONTACT (EXPANDABLE)
            item {
                val emergencySummary = uiState.profile.emergencyContactName.ifBlank {
                    uiState.profile.emergencyContactNumber.ifBlank { strings.userNameLabel + ": " + uiState.profile.name }
                }
                ExpandableSettingsSection(
                    title = strings.sectionEmergency,
                    summary = emergencySummary,
                    icon = Icons.Filled.Person,
                    accentColor = ext.lateRed,
                    expanded = profileExpanded,
                    onToggle = { profileExpanded = !profileExpanded },
                    headerTestTag = "expand_profile_section"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.PhotoCamera, contentDescription = strings.pickPhotoBtn)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.pickPhotoBtn)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = userName,
                                onValueChange = { userName = it },
                                label = { Text(strings.userNameLabel) },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(2f)
                                    .testTag("profile_name_input")
                            )
                            OutlinedTextField(
                                value = userAge,
                                onValueChange = { userAge = it.filter { ch -> ch.isDigit() } },
                                label = { Text(strings.userAgeLabel) },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("profile_age_input")
                            )
                        }

                        Text(
                            text = strings.emergencyHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ext.secondaryText
                        )
                        OutlinedTextField(
                            value = emergencyName,
                            onValueChange = { emergencyName = it },
                            label = { Text(strings.emergencyNameLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = emergencyPhone,
                            onValueChange = { emergencyPhone = it },
                            label = { Text(strings.emergencyPhoneLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                onSaveProfile(
                                    userName,
                                    userAge.toIntOrNull() ?: 65,
                                    userPhotoUri,
                                    emergencyName,
                                    emergencyPhone
                                )
                            },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("save_profile_button")
                        ) {
                            Text(strings.saveProfileBtn)
                        }
                    }
                }
            }

            item {
                Text(
                    text = strings.aboutLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.secondaryText,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showCompanionPickerDialog) {
        AlertDialog(
            onDismissRequest = { showCompanionPickerDialog = false },
            shape = RoundedCornerShape(28.dp),
            title = { Text(strings.onboardingCompanionTitle) },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.height(340.dp)
                ) {
                    items(CompanionType.entries) { comp ->
                        val selected = comp == uiState.companion
                        val accent = Color(comp.colorHex)
                        Card(
                            onClick = {
                                onSelectCompanion(comp)
                                onHearCompanionVoice(comp)
                                showCompanionPickerDialog = false
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) accent.copy(alpha = 0.16f)
                                else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                if (selected) 2.5.dp else 1.dp,
                                if (selected) accent else ext.cardBorder
                            ),
                            modifier = Modifier.testTag("picker_companion_${comp.id.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CompanionAvatar(companion = comp, size = 60.dp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = comp.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ext.primaryText
                                )
                                Text(
                                    text = comp.voiceStyle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accent,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCompanionPickerDialog = false }) {
                    Text(strings.cancelBtn)
                }
            }
        )
    }
}

@Composable
private fun ExpandableSettingsSection(
    title: String,
    summary: String,
    icon: ImageVector,
    accentColor: Color,
    expanded: Boolean,
    onToggle: () -> Unit,
    headerTestTag: String,
    content: @Composable () -> Unit
) {
    val ext = LocalAgasMoColors.current
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "expand_chevron"
    )

    AgasMoCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .testTag(headerTestTag),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = accentColor.copy(alpha = 0.16f),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        color = ext.primaryText
                    )
                    Text(
                        text = summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ext.secondaryText
                    )
                }
                Icon(
                    imageVector = Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = ext.secondaryText,
                    modifier = Modifier
                        .size(28.dp)
                        .rotate(rotation)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    HorizontalDivider(
                        color = ext.cardBorder.copy(alpha = 0.5f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    content()
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    label: String,
    checked: Boolean,
    tag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    val ext = LocalAgasMoColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
            color = ext.primaryText,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
