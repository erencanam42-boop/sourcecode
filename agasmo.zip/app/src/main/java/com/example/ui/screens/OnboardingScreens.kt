package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.ui.components.AgasMoBackground
import com.example.ui.components.CompanionAvatar
import com.example.ui.theme.LocalAgasMoColors

@Composable
fun OnboardingLanguageScreen(
    selectedLanguage: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit,
    onHearExample: (AppLanguage) -> Unit,
    onContinue: () -> Unit
) {
    val strings = L10n.strings(selectedLanguage)
    val ext = LocalAgasMoColors.current

    AgasMoBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "🦉 AgasMo",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.onboardingLangTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ext.primaryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.onboardingLangSubtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ext.secondaryText
                )
                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(AppLanguage.entries) { lang ->
                        val isSelected = lang == selectedLanguage
                        val borderColor by animateColorAsState(
                            if (isSelected) MaterialTheme.colorScheme.primary else ext.cardBorder,
                            label = "lang_border"
                        )
                        val bgColor by animateColorAsState(
                            if (isSelected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface,
                            label = "lang_bg"
                        )

                        Card(
                            onClick = { onSelectLanguage(lang) },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = bgColor),
                            border = BorderStroke(if (isSelected) 2.5.dp else 1.dp, borderColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_lang_${lang.code.lowercase()}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(text = lang.flagEmoji, fontSize = 28.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = lang.displayName,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = ext.primaryText
                                        )
                                        Text(
                                            text = lang.nativeSubtitle,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = ext.secondaryText
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Selected",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "\"${lang.sampleSentence}\"",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                    color = ext.primaryText
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                FilledTonalButton(
                                    onClick = { onHearExample(lang) },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.testTag("hear_example_${lang.code.lowercase()}")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = strings.hearExample
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.hearExample)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onContinue,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("onboarding_lang_continue")
                ) {
                    Text(
                        text = strings.continueBtn,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}

@Composable
fun OnboardingCompanionScreen(
    selectedLanguage: AppLanguage,
    selectedCompanion: CompanionType,
    onSelectCompanion: (CompanionType) -> Unit,
    onHearVoice: (CompanionType) -> Unit,
    onStart: () -> Unit
) {
    val strings = L10n.strings(selectedLanguage)
    val ext = LocalAgasMoColors.current

    AgasMoBackground {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = strings.onboardingCompanionTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ext.primaryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.onboardingCompanionSubtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ext.secondaryText
                )
                Spacer(modifier = Modifier.height(14.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(CompanionType.entries) { companion ->
                        val isSelected = companion == selectedCompanion
                        val accent = Color(companion.colorHex)
                        val cardBg = if (isSelected) accent.copy(alpha = 0.14f)
                        else MaterialTheme.colorScheme.surface

                        Card(
                            onClick = {
                                onSelectCompanion(companion)
                                onHearVoice(companion)
                            },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(if (isSelected) 3.dp else 1.2.dp, if (isSelected) accent else ext.cardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_companion_${companion.id.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CompanionAvatar(companion = companion, size = 82.dp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "${companion.displayName} ${companion.speciesLabel}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ext.primaryText,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = L10n.companionPersonality(companion, selectedLanguage),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ext.secondaryText,
                                    textAlign = TextAlign.Center,
                                    minLines = 2
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                FilledTonalButton(
                                    onClick = {
                                        onSelectCompanion(companion)
                                        onHearVoice(companion)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = accent.copy(alpha = 0.2f),
                                        contentColor = ext.primaryText
                                    ),
                                    modifier = Modifier.testTag("hear_companion_${companion.id.lowercase()}")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = strings.hearVoice,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(strings.hearVoice)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onStart,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(selectedCompanion.colorHex)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("onboarding_start_button")
                ) {
                    Text(
                        text = strings.startWithCompanion(selectedCompanion.displayName),
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                }
            }
        }
    }
}
