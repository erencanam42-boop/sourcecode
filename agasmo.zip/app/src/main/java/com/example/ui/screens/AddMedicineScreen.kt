package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.AgasMoRepository
import com.example.data.MedicineEntity
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.MedicineFrequency
import com.example.model.MedicineType
import com.example.model.PillPalette
import com.example.model.SoundStyle
import com.example.ui.components.AgasMoCard
import com.example.ui.components.formatTime12Hour
import com.example.ui.theme.LocalAgasMoColors
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AddMedicineScreen(
    language: AppLanguage,
    editingMedicine: MedicineEntity?,
    onSave: (MedicineEntity) -> Unit,
    onDelete: (Long) -> Unit,
    onCancelEdit: () -> Unit
) {
    val strings = L10n.strings(language)
    val ext = LocalAgasMoColors.current

    var name by remember(editingMedicine) { mutableStateOf(editingMedicine?.name ?: "") }
    var dosage by remember(editingMedicine) { mutableStateOf(editingMedicine?.dosage ?: "500mg") }
    var type by remember(editingMedicine) {
        mutableStateOf(MedicineType.fromCode(editingMedicine?.type))
    }
    var colorHex by remember(editingMedicine) {
        mutableLongStateOf(editingMedicine?.colorHex ?: PillPalette.colors.first())
    }
    var photoUri by remember(editingMedicine) { mutableStateOf(editingMedicine?.photoUri) }
    val times = remember(editingMedicine) {
        mutableStateListOf<String>().apply {
            val initial = editingMedicine?.timesCsv
                ?.split(",")
                ?.map { it.trim() }
                ?.filter { it.contains(":") }
            if (!initial.isNullOrEmpty()) {
                addAll(initial)
            } else {
                addAll(listOf("08:00", "12:00", "20:00"))
            }
        }
    }
    var frequency by remember(editingMedicine) {
        mutableStateOf(MedicineFrequency.fromCode(editingMedicine?.frequency))
    }
    val selectedDays = remember(editingMedicine) {
        mutableStateListOf<Int>().apply {
            val parsed = editingMedicine?.specificDaysCsv
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
            if (!parsed.isNullOrEmpty()) addAll(parsed) else addAll(listOf(1, 2, 3, 4, 5, 6, 7))
        }
    }
    var durationDays by remember(editingMedicine) {
        mutableIntStateOf(editingMedicine?.durationDays ?: -1)
    }
    var reminderOffset by remember(editingMedicine) {
        mutableIntStateOf(editingMedicine?.reminderOffsetMinutes ?: 0)
    }
    var maxShout by remember(editingMedicine) {
        mutableStateOf(editingMedicine?.maxShoutEnabled ?: true)
    }
    var soundStyle by remember(editingMedicine) {
        mutableStateOf(SoundStyle.fromCode(editingMedicine?.soundStyle))
    }
    var showNameError by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    LaunchedEffect(name) {
        if (name.isNotBlank()) showNameError = false
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (editingMedicine != null) strings.editMedTitle else strings.addMedTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = ext.primaryText
                    )
                    if (editingMedicine != null) {
                        TextButton(onClick = onCancelEdit) {
                            Text(strings.cancelBtn)
                        }
                    }
                }
            }

            item {
                AgasMoCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text(strings.medNameLabel) },
                            isError = showNameError,
                            supportingText = if (showNameError) {
                                { Text(strings.enterMedNameError) }
                            } else null,
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("med_name_input")
                        )

                        OutlinedTextField(
                            value = dosage,
                            onValueChange = { dosage = it },
                            label = { Text(strings.dosageLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("med_dosage_input")
                        )

                        Text(
                            text = strings.typeLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MedicineType.entries.forEach { itemType ->
                                FilterChip(
                                    selected = type == itemType,
                                    onClick = { type = itemType },
                                    label = { Text(L10n.medicineTypeLabel(itemType, language)) },
                                    modifier = Modifier.testTag("med_type_${itemType.code.lowercase()}")
                                )
                            }
                        }

                        Text(
                            text = strings.colorLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PillPalette.colors.forEach { hex ->
                                val selected = colorHex == hex
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(hex))
                                        .border(
                                            width = if (selected) 3.dp else 1.dp,
                                            color = if (selected) ext.primaryText else Color.White,
                                            shape = CircleShape
                                        )
                                        .clickable { colorHex = hex }
                                )
                            }
                        }

                        Text(
                            text = strings.photoOptionalLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("med_pick_photo_button")
                            ) {
                                Icon(Icons.Filled.PhotoLibrary, contentDescription = strings.pickPhotoBtn)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.pickPhotoBtn)
                            }
                            if (!photoUri.isNullOrBlank()) {
                                Spacer(modifier = Modifier.width(12.dp))
                                AsyncImage(
                                    model = photoUri,
                                    contentDescription = name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                                TextButton(onClick = { photoUri = null }) {
                                    Text(strings.removePhotoBtn)
                                }
                            }
                        }
                    }
                }
            }

            item {
                AgasMoCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = strings.timesLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            times.forEach { t ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.AccessTime,
                                            contentDescription = t,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = formatTime12Hour(t),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        if (times.size > 1) {
                                            IconButton(
                                                onClick = { times.remove(t) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    Icons.Filled.Close,
                                                    contentDescription = "Remove time",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            OutlinedButton(
                                onClick = { showTimePicker = true },
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.testTag("add_time_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = strings.addTimeBtn)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.addTimeBtn)
                            }
                        }

                        Text(
                            text = strings.frequencyLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MedicineFrequency.entries.forEach { freq ->
                                FilterChip(
                                    selected = frequency == freq,
                                    onClick = { frequency = freq },
                                    label = { Text(L10n.frequencyLabel(freq, language)) }
                                )
                            }
                        }

                        if (frequency == MedicineFrequency.SPECIFIC_DAYS) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                (1..7).forEach { isoDay ->
                                    val picked = selectedDays.contains(isoDay)
                                    FilterChip(
                                        selected = picked,
                                        onClick = {
                                            if (picked && selectedDays.size > 1) selectedDays.remove(isoDay)
                                            else if (!picked) selectedDays.add(isoDay)
                                        },
                                        label = { Text(L10n.dayShortLabel(isoDay, language)) }
                                    )
                                }
                            }
                        }

                        Text(
                            text = strings.durationLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                7 to strings.duration7Days,
                                30 to strings.duration30Days,
                                -1 to strings.durationForever
                            ).forEach { (daysVal, label) ->
                                FilterChip(
                                    selected = durationDays == daysVal,
                                    onClick = { durationDays = daysVal },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                AgasMoCard {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = strings.reminderLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                30 to strings.rem30Before,
                                10 to strings.rem10Before,
                                0 to strings.remOnTime
                            ).forEach { (mins, label) ->
                                FilterChip(
                                    selected = reminderOffset == mins,
                                    onClick = { reminderOffset = mins },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = strings.maxShoutLabel,
                                style = MaterialTheme.typography.bodyLarge,
                                color = ext.primaryText,
                                modifier = Modifier.weight(1f)
                            )
                            Switch(
                                checked = maxShout,
                                onCheckedChange = { maxShout = it },
                                modifier = Modifier.testTag("max_shout_switch")
                            )
                        }

                        Text(
                            text = strings.soundStyleLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.primaryText
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SoundStyle.entries.forEach { style ->
                                FilterChip(
                                    selected = soundStyle == style,
                                    onClick = { soundStyle = style },
                                    label = { Text(L10n.soundStyleLabel(style, language)) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            showNameError = true
                            return@Button
                        }
                        val entity = MedicineEntity(
                            id = editingMedicine?.id ?: 0L,
                            name = name.trim(),
                            dosage = dosage.trim().ifEmpty { "1 dose" },
                            type = type.code,
                            colorHex = colorHex,
                            photoUri = photoUri,
                            timesCsv = times.distinct().sorted().joinToString(","),
                            frequency = frequency.code,
                            specificDaysCsv = selectedDays.distinct().sorted().joinToString(","),
                            durationDays = durationDays,
                            startDateEpochDay = editingMedicine?.startDateEpochDay
                                ?: AgasMoRepository.todayEpochDay(),
                            reminderOffsetMinutes = reminderOffset,
                            maxShoutEnabled = maxShout,
                            soundStyle = soundStyle.code,
                            voiceAlertEnabled = editingMedicine?.voiceAlertEnabled ?: true,
                            isActive = true
                        )
                        onSave(entity)
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("save_medicine_button")
                ) {
                    Text(
                        text = strings.saveMedBtn,
                        style = MaterialTheme.typography.titleLarge
                    )
                }

                if (editingMedicine != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { onDelete(editingMedicine.id) },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ext.lateRed),
                        border = BorderStroke(1.5.dp, ext.lateRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("delete_medicine_button")
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = strings.deleteMedBtn)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.deleteMedBtn)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showTimePicker) {
        val nowCal = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
        val pickerState = rememberTimePickerState(
            initialHour = nowCal.get(Calendar.HOUR_OF_DAY),
            initialMinute = nowCal.get(Calendar.MINUTE),
            is24Hour = false
        )
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val formatted = String.format(
                            Locale.US,
                            "%02d:%02d",
                            pickerState.hour,
                            pickerState.minute
                        )
                        if (!times.contains(formatted)) {
                            times.add(formatted)
                        }
                        showTimePicker = false
                    },
                    modifier = Modifier.testTag("confirm_time_picker_button")
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text(strings.cancelBtn)
                }
            },
            text = {
                TimePicker(state = pickerState)
            }
        )
    }
}
