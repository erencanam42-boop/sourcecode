package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PeachCream = Color(0xFFFFF1E6)
val SoftPinkBg = Color(0xFFFFE4E1)
val WarmWhiteCard = Color(0xFFFFFBF8)
val DarkBrownText = Color(0xFF4A2C2A)
val WarmCocoaText = Color(0xFF7A524F)
val SoftRoseBorder = Color(0xFFF3C6C1)

val NeonRedLate = Color(0xFFFF3B30)
val TakenGreen = Color(0xFF34C759)
val SoonYellow = Color(0xFFFFCC00)
val LumiPurple = Color(0xFF8B5CF6)
val BramBrown = Color(0xFF8B4513)
val MimiPink = Color(0xFFFF69B4)
val KikoOrange = Color(0xFFFF8C00)
val TalaTeal = Color(0xFF00BFBF)

val DarkPlumBg = Color(0xFF1E1315)
val DarkRoseCard = Color(0xFF2B1C20)
val DarkRoseElevated = Color(0xFF38242A)
val CreamOnDark = Color(0xFFFFEFEA)
val MutedRoseOnDark = Color(0xFFD7B6B2)
