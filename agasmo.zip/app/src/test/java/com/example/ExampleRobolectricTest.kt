package com.example

import android.app.NotificationManager
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.alarm.MedicineAlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.data.AgasMoDatabase
import com.example.data.AgasMoRepository
import com.example.data.MedicineEntity
import com.example.data.UserPrefsStore
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionType
import com.example.model.DoseStatus
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AgasMoDatabase
    private lateinit var repository: AgasMoRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AgasMoDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = AgasMoRepository(db, UserPrefsStore(context))
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name is AgasMo`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("AgasMo", appName)
    }

    @Test
    fun `all 5 languages and 5 companions produce valid translations and voices`() {
        for (lang in AppLanguage.entries) {
            val strings = L10n.strings(lang)
            assertTrue(strings.homeGreeting("Juan").contains("Juan"))
            assertTrue(strings.takeNow.isNotBlank())
            assertTrue(strings.snooze10m.isNotBlank())
            for (comp in CompanionType.entries) {
                val preview = L10n.companionPreviewVoice(comp, lang)
                val body = L10n.notificationBody(comp, lang, "Vitamin B 500", "500mg", false, 0)
                val shout = L10n.notificationBody(comp, lang, "Vitamin B 500", "500mg", true, 30)
                assertTrue(preview.isNotBlank())
                assertTrue(body.contains("Vitamin B 500"))
                assertTrue(shout.contains("30"))
            }
        }
    }

    @Test
    fun `save medicine, mark taken, and compute streak in offline Room`() = runBlocking {
        repository.ensureSeeded()
        val today = AgasMoRepository.todayEpochDay()
        val medId = repository.saveMedicine(
            MedicineEntity(
                name = "Vitamin B 500",
                dosage = "500mg",
                type = "TABLET",
                colorHex = 0xFF8B5CF6,
                timesCsv = "08:00,20:00",
                frequency = "EVERYDAY",
                startDateEpochDay = today
            )
        )
        assertTrue(medId > 0L)

        val meds = repository.getActiveMedicinesSync()
        assertEquals(1, meds.size)

        repository.markDoseTaken(medId, "Vitamin B 500", "500mg", "08:00", today)
        val log = repository.getLogForDose(medId, "08:00", today)
        assertNotNull(log)
        assertEquals("TAKEN", log?.status)

        val doses = repository.buildDosesForDay(
            medicines = meds,
            logs = listOfNotNull(log),
            epochDay = today,
            nowMillis = AgasMoRepository.epochDayAndTimeToMillis(today, "09:00")
        )
        val morningDose = doses.first { it.scheduledTime == "08:00" }
        assertEquals(DoseStatus.TAKEN, morningDose.status)
        assertEquals(1, repository.computeStreakDays(listOfNotNull(log), today))
    }

    @Test
    fun `notification channel is created and alarm requestCodes are unique`() {
        NotificationHelper.ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = nm.getNotificationChannel(NotificationHelper.CHANNEL_ID)
        assertNotNull(channel)
        assertEquals(NotificationManager.IMPORTANCE_HIGH, channel.importance)

        val code1 = MedicineAlarmScheduler.requestCodeFor(1L, "08:00", isMaxShout = false)
        val code2 = MedicineAlarmScheduler.requestCodeFor(1L, "20:00", isMaxShout = false)
        val code3 = MedicineAlarmScheduler.requestCodeFor(1L, "08:00", isMaxShout = true)
        assertNotEquals(code1, code2)
        assertNotEquals(code1, code3)
    }
}
