package com.example

import com.example.alarm.MedicineAlarmScheduler
import com.example.data.AgasMoRepository
import com.example.data.MedicineEntity
import com.example.data.MedicineLogEntity
import com.example.i18n.L10n
import com.example.model.AppLanguage
import com.example.model.CompanionMood
import com.example.model.CompanionType
import com.example.model.DoseStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun allLanguagesAndCompanionsProduceValidTranslations() {
        for (lang in AppLanguage.entries) {
            val strings = L10n.strings(lang)
            assertTrue(strings.homeGreeting("Juan").contains("Juan"))
            assertTrue(strings.takeNow.isNotBlank())
            assertTrue(strings.snooze10m.isNotBlank())
            assertTrue(strings.notifOffBanner("Lumi").contains("Lumi"))
            for (comp in CompanionType.entries) {
                val preview = L10n.companionPreviewVoice(comp, lang)
                val body = L10n.notificationBody(comp, lang, "Vitamin B 500", "500mg", false, 0)
                val shout = L10n.notificationBody(comp, lang, "Vitamin B 500", "500mg", true, 30)
                assertTrue(preview.isNotBlank())
                assertTrue(body.contains("Vitamin B 500"))
                assertTrue(shout.contains("30"))
                assertTrue(L10n.companionMoodMessage(comp, CompanionMood.HAPPY, lang, 0).isNotBlank())
                assertTrue(L10n.companionMoodMessage(comp, CompanionMood.ANGRY, lang, 45).isNotBlank())
                assertTrue(L10n.companionMoodMessage(comp, CompanionMood.SLEEPY, lang, 0).isNotBlank())
            }
        }
    }

    @Test
    fun alarmRequestCodesAreUniquePerMedicineTimeAndMaxShout() {
        val code1 = MedicineAlarmScheduler.requestCodeFor(1L, "08:00", isMaxShout = false)
        val code2 = MedicineAlarmScheduler.requestCodeFor(1L, "20:00", isMaxShout = false)
        val code3 = MedicineAlarmScheduler.requestCodeFor(1L, "08:00", isMaxShout = true)
        val code4 = MedicineAlarmScheduler.requestCodeFor(2L, "08:00", isMaxShout = false)

        assertNotEquals(code1, code2)
        assertNotEquals(code1, code3)
        assertNotEquals(code1, code4)
        assertTrue(code1 > 0 && code2 > 0 && code3 > 0 && code4 > 0)
    }

    @Test
    fun scheduleDayAndFrequencyFilteringWorksCorrectly() {
        val startDay = 20_000L
        val everyOtherDayMed = MedicineEntity(
            id = 1L,
            name = "Vitamin B 500",
            dosage = "500mg",
            type = "TABLET",
            colorHex = 0xFF8B5CF6,
            timesCsv = "08:00",
            frequency = "EVERY_OTHER_DAY",
            durationDays = 7,
            startDateEpochDay = startDay
        )
        assertTrue(AgasMoRepository.isMedicineScheduledOnDay(everyOtherDayMed, startDay))
        assertFalse(AgasMoRepository.isMedicineScheduledOnDay(everyOtherDayMed, startDay + 1))
        assertTrue(AgasMoRepository.isMedicineScheduledOnDay(everyOtherDayMed, startDay + 2))
        assertFalse(AgasMoRepository.isMedicineScheduledOnDay(everyOtherDayMed, startDay + 7))
    }

    @Test
    fun streakAndDoseStatusCalculationsAreAccurate() {
        val today = AgasMoRepository.todayEpochDay()
        val logs = listOf(
            MedicineLogEntity(1L, 1L, "Vitamin B", "500mg", today, "08:00", 100L, "TAKEN"),
            MedicineLogEntity(2L, 1L, "Vitamin B", "500mg", today - 1, "08:00", 100L, "TAKEN"),
            MedicineLogEntity(3L, 1L, "Vitamin B", "500mg", today - 2, "08:00", 100L, "TAKEN")
        )
        assertEquals(3, computeStreakStandalone(logs, today))
    }

    private fun computeStreakStandalone(logs: List<MedicineLogEntity>, today: Long): Int {
        val takenDays = logs.filter { it.status == "TAKEN" }.map { it.dateEpochDay }.toSet()
        var streak = 0
        var cursor = today
        while (takenDays.contains(cursor)) {
            streak++
            cursor--
        }
        return streak
    }
}
